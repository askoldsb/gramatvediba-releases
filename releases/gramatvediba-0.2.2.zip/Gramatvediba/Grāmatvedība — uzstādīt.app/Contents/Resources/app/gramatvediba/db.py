"""SQLite datubāze: shēma, savienojums, pamata palīgfunkcijas."""
import sqlite3
from pathlib import Path


SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (
    key     TEXT PRIMARY KEY,
    value   TEXT
);

CREATE TABLE IF NOT EXISTS books (
    id      INTEGER PRIMARY KEY,
    name    TEXT NOT NULL UNIQUE,
    sources TEXT NOT NULL DEFAULT ''   -- avoti, kuru jaunie konti nonāk šajā grāmatā (komats)
);

CREATE TABLE IF NOT EXISTS accounts (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE,
    source      TEXT NOT NULL,          -- swedbank / revolut / paypal / nexo / manual
    currency    TEXT NOT NULL,
    iban        TEXT,
    active      INTEGER NOT NULL DEFAULT 1,
    book_id     INTEGER REFERENCES books(id)
);

CREATE TABLE IF NOT EXISTS categories (
    id      INTEGER PRIMARY KEY,
    name    TEXT NOT NULL UNIQUE,
    kind    TEXT NOT NULL CHECK (kind IN ('ienakumi','izdevumi','parskaitijums'))
);

CREATE TABLE IF NOT EXISTS rules (
    id          INTEGER PRIMARY KEY,
    pattern     TEXT NOT NULL,          -- teksts, ko meklēt (bez reģistra)
    category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    priority    INTEGER NOT NULL DEFAULT 100,
    direction   TEXT NOT NULL DEFAULT 'abi'   -- abi / ienakums / izdevums
);

CREATE TABLE IF NOT EXISTS transactions (
    id              INTEGER PRIMARY KEY,
    account_id      INTEGER NOT NULL REFERENCES accounts(id),
    date            TEXT NOT NULL,      -- YYYY-MM-DD
    amount          REAL NOT NULL,      -- + ienākums, - izdevums (konta valūtā)
    currency        TEXT NOT NULL,
    counterparty    TEXT,
    description     TEXT,
    kind_raw        TEXT,               -- avota darījuma tips
    external_id     TEXT,
    category_id     INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    category_manual INTEGER NOT NULL DEFAULT 0,
    note            TEXT,
    hash            TEXT NOT NULL UNIQUE,
    import_id       INTEGER REFERENCES imports(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_tx_date ON transactions(date);
CREATE INDEX IF NOT EXISTS ix_tx_acc ON transactions(account_id);

CREATE TABLE IF NOT EXISTS transfer_links (
    id          INTEGER PRIMARY KEY,
    out_tx      INTEGER NOT NULL UNIQUE REFERENCES transactions(id) ON DELETE CASCADE,
    in_tx       INTEGER NOT NULL UNIQUE REFERENCES transactions(id) ON DELETE CASCADE,
    kind        TEXT NOT NULL DEFAULT 'parskaitijums',   -- parskaitijums / maina
    rate        REAL,                                    -- maiņai: cik ienākošās valūtas par 1 izejošās
    auto        INTEGER NOT NULL DEFAULT 1,              -- 1 = atrada programma, 0 = sasaistīja lietotājs
    created_at  TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS transfer_ignore (                  -- lietotājs atsaistīja: neveidot šo pāri atkal
    out_tx      INTEGER NOT NULL,
    in_tx       INTEGER NOT NULL,
    PRIMARY KEY (out_tx, in_tx)
);

CREATE TABLE IF NOT EXISTS balances (
    id          INTEGER PRIMARY KEY,
    account_id  INTEGER NOT NULL REFERENCES accounts(id),
    date        TEXT NOT NULL,
    balance     REAL NOT NULL,
    kind        TEXT NOT NULL DEFAULT 'beigu',   -- sakuma / beigu / manuals
    UNIQUE (account_id, date, kind)
);

CREATE TABLE IF NOT EXISTS imports (
    id          INTEGER PRIMARY KEY,
    filename    TEXT,
    source      TEXT,
    imported_at TEXT DEFAULT (datetime('now','localtime')),
    rows_new    INTEGER,
    rows_dup    INTEGER
);

CREATE TABLE IF NOT EXISTS fx_rates (
    currency    TEXT PRIMARY KEY,
    eur_per_unit REAL NOT NULL           -- cik EUR ir 1 vienība
);

CREATE TABLE IF NOT EXISTS invoices (
    id          INTEGER PRIMARY KEY,
    direction   TEXT NOT NULL CHECK (direction IN ('sanemts','izrakstits')),
    counterparty TEXT NOT NULL,
    number      TEXT,
    issue_date  TEXT,
    due_date    TEXT,
    amount      REAL NOT NULL,
    currency    TEXT NOT NULL DEFAULT 'EUR',
    category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
    match_text  TEXT,                   -- teksts automātiskai piesaistei
    note        TEXT,
    book_id     INTEGER REFERENCES books(id)
);

CREATE TABLE IF NOT EXISTS invoice_payments (
    invoice_id      INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    transaction_id  INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    amount          REAL NOT NULL,
    PRIMARY KEY (invoice_id, transaction_id)
);

CREATE TABLE IF NOT EXISTS obligations (
    id              INTEGER PRIMARY KEY,
    name            TEXT NOT NULL,
    kind            TEXT NOT NULL,      -- lizings / nomaksa / kredits / uzturlidzekli / ire / cits
    direction       TEXT NOT NULL DEFAULT 'maksaju' CHECK (direction IN ('maksaju','sanemu')),
    counterparty    TEXT,
    start_date      TEXT NOT NULL,      -- pirmā maksājuma datums
    frequency       TEXT NOT NULL DEFAULT 'menesis',  -- menesis / ceturksnis / gads
    n_payments      INTEGER,            -- NULL = beztermiņa
    payment_amount  REAL,               -- NULL => aprēķina no pamatsummas un %
    principal       REAL,               -- pamatsumma (līzingam/kredītam)
    interest_rate   REAL,               -- gada % (piem. 6.5)
    residual        REAL DEFAULT 0,     -- izpirkuma maksa līzinga beigās
    currency        TEXT NOT NULL DEFAULT 'EUR',
    match_text      TEXT,               -- teksts maksājumu atpazīšanai bankas datos
    tolerance       REAL NOT NULL DEFAULT 1.0,   -- pieļaujamā summas novirze EUR
    note            TEXT,
    active          INTEGER NOT NULL DEFAULT 1,
    book_id         INTEGER REFERENCES books(id)
);

CREATE TABLE IF NOT EXISTS obligation_schedule (
    id              INTEGER PRIMARY KEY,
    obligation_id   INTEGER NOT NULL REFERENCES obligations(id) ON DELETE CASCADE,
    seq             INTEGER NOT NULL,
    due_date        TEXT NOT NULL,
    amount          REAL NOT NULL,
    principal_part  REAL,
    interest_part   REAL,
    balance_after   REAL,
    transaction_id  INTEGER REFERENCES transactions(id) ON DELETE SET NULL,
    manual_paid     INTEGER NOT NULL DEFAULT 0,
    UNIQUE (obligation_id, seq)
);
"""

DEFAULT_CATEGORIES = [
    ("Alga", "ienakumi"),
    ("Citi ienākumi", "ienakumi"),
    ("Procenti / ienesīgums", "ienakumi"),
    ("Saņemtie uzturlīdzekļi", "ienakumi"),
    ("Pārtika", "izdevumi"),
    ("Kafejnīcas, restorāni", "izdevumi"),
    ("Mājoklis, komunālie", "izdevumi"),
    ("Transports, degviela", "izdevumi"),
    ("Sakari, abonementi", "izdevumi"),
    ("Veselība", "izdevumi"),
    ("Iepirkšanās", "izdevumi"),
    ("Izklaide, ceļojumi", "izdevumi"),
    ("Līzingi, kredīti, nomaksas", "izdevumi"),
    ("Uzturlīdzekļi", "izdevumi"),
    ("Nodokļi, valsts maksājumi", "izdevumi"),
    ("Bankas komisijas", "izdevumi"),
    ("Citi izdevumi", "izdevumi"),
    ("Pārskaitījumi starp saviem kontiem", "parskaitijums"),
    ("Valūtas / kripto maiņa", "parskaitijums"),
] + [
    # blakus ienākumi – fotostoki
    ("Fotobanks: Shutterstock", "ienakumi"),
    ("Fotobanks: Adobe Stock", "ienakumi"),
    ("Fotobanks: Getty / iStock", "ienakumi"),
    ("Fotobanks: Pond5", "ienakumi"),
    ("Fotobanks: citi", "ienakumi"),
    ("Foto: aprīkojums", "izdevumi"),
    ("Foto: programmatūra, abonementi", "izdevumi"),
    ("Foto: platformu un maksājumu komisijas", "izdevumi"),
]

# (teksts, kategorija[, virziens])  virziens: abi / ienakums / izdevums
STOCK_RULES = [
    ("shutterstock", "Fotobanks: Shutterstock", "ienakums"),
    ("adobe", "Fotobanks: Adobe Stock", "ienakums"),
    ("fotolia", "Fotobanks: Adobe Stock", "ienakums"),
    ("getty", "Fotobanks: Getty / iStock", "ienakums"),
    ("istock", "Fotobanks: Getty / iStock", "ienakums"),
    ("pond5", "Fotobanks: Pond5", "ienakums"),
    ("dreamstime", "Fotobanks: citi", "ienakums"),
    ("123rf", "Fotobanks: citi", "ienakums"),
    ("depositphotos", "Fotobanks: citi", "ienakums"),
    ("alamy", "Fotobanks: citi", "ienakums"),
    ("freepik", "Fotobanks: citi", "ienakums"),
    ("envato", "Fotobanks: citi", "ienakums"),
    ("wirestock", "Fotobanks: citi", "ienakums"),
    ("storyblocks", "Fotobanks: citi", "ienakums"),
    ("canva", "Fotobanks: citi", "ienakums"),
    ("eyeem", "Fotobanks: citi", "ienakums"),
    ("adobe", "Foto: programmatūra, abonementi", "izdevums"),
    ("lightroom", "Foto: programmatūra, abonementi", "izdevums"),
    ("capture one", "Foto: programmatūra, abonementi", "izdevums"),
    ("topaz", "Foto: programmatūra, abonementi", "izdevums"),
    ("dropbox", "Foto: programmatūra, abonementi", "izdevums"),
    ("google one", "Foto: programmatūra, abonementi", "izdevums"),
    ("canon", "Foto: aprīkojums", "izdevums"),
    ("nikon", "Foto: aprīkojums", "izdevums"),
    ("sony", "Foto: aprīkojums", "izdevums"),
    ("dji", "Foto: aprīkojums", "izdevums"),
    ("foto.lv", "Foto: aprīkojums", "izdevums"),
    ("1a.lv", "Foto: aprīkojums", "izdevums"),
]

# 0.2.2: biežāk sastopamie tirgotāji (Nexo kartes u.c. pirkumi)
MORE_RULES = [
    ("veikals top", "Pārtika", "izdevums"), ("elvi", "Pārtika", "izdevums"), ("citro", "Pārtika", "izdevums"),
    ("spar", "Pārtika", "izdevums"), ("nelda", "Pārtika", "izdevums"),
    ("dus ", "Transports, degviela", "izdevums"), ("degviel", "Transports, degviela", "izdevums"),
    ("kafejn", "Kafejnīcas, restorāni", "izdevums"), ("restor", "Kafejnīcas, restorāni", "izdevums"),
    ("restaur", "Kafejnīcas, restorāni", "izdevums"), ("bistro", "Kafejnīcas, restorāni", "izdevums"),
    ("pivovar", "Kafejnīcas, restorāni", "izdevums"), ("lido", "Kafejnīcas, restorāni", "izdevums"),
    ("krogs", "Kafejnīcas, restorāni", "izdevums"), ("kafe", "Kafejnīcas, restorāni", "izdevums"),
    ("cafe", "Kafejnīcas, restorāni", "izdevums"), ("pizz", "Kafejnīcas, restorāni", "izdevums"),
    ("drogas", "Iepirkšanās", "izdevums"), ("depo", "Iepirkšanās", "izdevums"), ("senukai", "Iepirkšanās", "izdevums"),
    ("jysk", "Iepirkšanās", "izdevums"), ("pepco", "Iepirkšanās", "izdevums"), ("ikea", "Iepirkšanās", "izdevums"),
    ("apotheka", "Veselība", "izdevums"), ("mēness aptieka", "Veselība", "izdevums"),
    ("midjourney", "Foto: programmatūra, abonementi", "izdevums"), ("anthropic", "Foto: programmatūra, abonementi", "izdevums"),
    ("openai", "Foto: programmatūra, abonementi", "izdevums"), ("chatgpt", "Foto: programmatūra, abonementi", "izdevums"),
]

DEFAULT_BOOKS = [
    ("Darbs", "swedbank"),
    ("Fotobanks", "paypal,revolut,nexo"),
]

DEFAULT_RULES = [
    # (teksts, kategorija)
    ("rimi", "Pārtika"), ("maxima", "Pārtika"), ("lidl", "Pārtika"), ("top!", "Pārtika"),
    ("elvi", "Pārtika"), ("mego", "Pārtika"), ("aibe", "Pārtika"),
    ("wolt", "Kafejnīcas, restorāni"), ("bolt food", "Kafejnīcas, restorāni"),
    ("circle k", "Transports, degviela"), ("neste", "Transports, degviela"),
    ("virši", "Transports, degviela"), ("viada", "Transports, degviela"),
    ("bolt.eu", "Transports, degviela"), ("rigas satiksme", "Transports, degviela"),
    ("tet", "Sakari, abonementi"), ("lmt", "Sakari, abonementi"), ("tele2", "Sakari, abonementi"),
    ("bite", "Sakari, abonementi"), ("spotify", "Sakari, abonementi"), ("netflix", "Sakari, abonementi"),
    ("latvenergo", "Mājoklis, komunālie"), ("elektrum", "Mājoklis, komunālie"),
    ("rigas udens", "Mājoklis, komunālie"), ("gaso", "Mājoklis, komunālie"),
    ("aptieka", "Veselība"), ("benu", "Veselība"),
    ("vid ", "Nodokļi, valsts maksājumi"), ("valsts ieņēmumu", "Nodokļi, valsts maksājumi"),
    ("komisija", "Bankas komisijas"), ("apkalpošanas maksa", "Bankas komisijas"),
    ("uzturlīdzek", "Uzturlīdzekļi"), ("alimenti", "Uzturlīdzekļi"),
    ("līzing", "Līzingi, kredīti, nomaksas"), ("lizing", "Līzingi, kredīti, nomaksas"),
    ("leasing", "Līzingi, kredīti, nomaksas"), ("mogo", "Līzingi, kredīti, nomaksas"),
    ("inbank", "Līzingi, kredīti, nomaksas"),
    ("revolut", "Pārskaitījumi starp saviem kontiem"),
    ("paypal", "Pārskaitījumi starp saviem kontiem"),
    ("nexo", "Pārskaitījumi starp saviem kontiem"),
    ("alga", "Alga"), ("salary", "Alga"),
]


def connect(path=None) -> sqlite3.Connection:
    if path is None:
        from .config import db_path
        path = db_path()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def _add_column(con, table, col, decl):
    cols = {r["name"] for r in con.execute(f"PRAGMA table_info({table})")}
    if col not in cols:
        con.execute(f"ALTER TABLE {table} ADD COLUMN {col} {decl}")


def _version(con) -> int:
    r = con.execute("SELECT value FROM meta WHERE key='version'").fetchone()
    return int(r["value"]) if r else 0


def init_db(con: sqlite3.Connection) -> None:
    con.executescript(SCHEMA)
    # vecākas datubāzes papildināšana
    _add_column(con, "accounts", "book_id", "INTEGER REFERENCES books(id)")
    _add_column(con, "rules", "direction", "TEXT NOT NULL DEFAULT 'abi'")
    _add_column(con, "invoices", "book_id", "INTEGER REFERENCES books(id)")
    _add_column(con, "obligations", "book_id", "INTEGER REFERENCES books(id)")
    _add_column(con, "transactions", "ref", "TEXT")
    _add_column(con, "transactions", "eur_rate", "REAL")        # EUR par 1 vienību šim darījumam (no maiņas)
    _add_column(con, "transactions", "rate_note", "TEXT")       # no kurienes kurss
    _add_column(con, "transactions", "pending", "INTEGER NOT NULL DEFAULT 0")   # gaida apstiprinājumu
    con.execute("CREATE INDEX IF NOT EXISTS ix_tx_ref ON transactions(ref)")
    con.execute("CREATE INDEX IF NOT EXISTS ix_tx_ext ON transactions(external_id)")

    v = _version(con)
    if v < 1:
        if con.execute("SELECT COUNT(*) FROM categories").fetchone()[0] == 0:
            con.executemany("INSERT INTO categories(name, kind) VALUES (?,?)", DEFAULT_CATEGORIES[:19])
            cat = {r["name"]: r["id"] for r in con.execute("SELECT id, name FROM categories")}
            con.executemany("INSERT INTO rules(pattern, category_id) VALUES (?,?)",
                            [(p, cat[c]) for p, c in DEFAULT_RULES])
    if v < 2:
        # grāmatas un fotostoku kategorijas
        con.executemany("INSERT OR IGNORE INTO categories(name, kind) VALUES (?,?)", DEFAULT_CATEGORIES)
        cat = {r["name"]: r["id"] for r in con.execute("SELECT id, name FROM categories")}
        con.executemany("INSERT INTO rules(pattern, category_id, priority, direction) VALUES (?,?,40,?)",
                        [(p, cat[c], d) for p, c, d in STOCK_RULES])
        if con.execute("SELECT COUNT(*) FROM books").fetchone()[0] == 0:
            con.executemany("INSERT INTO books(name, sources) VALUES (?,?)", DEFAULT_BOOKS)
        for a in con.execute("SELECT id, source FROM accounts WHERE book_id IS NULL").fetchall():
            con.execute("UPDATE accounts SET book_id=? WHERE id=?", (book_for_source(con, a["source"]), a["id"]))
        first = con.execute("SELECT MIN(id) FROM books").fetchone()[0]
        con.execute("UPDATE invoices SET book_id=? WHERE book_id IS NULL", (first,))
        con.execute("UPDATE obligations SET book_id=? WHERE book_id IS NULL", (first,))
    if v < 5:
        cat = {r["name"]: r["id"] for r in con.execute("SELECT id, name FROM categories")}
        have = {r[0] for r in con.execute("SELECT pattern FROM rules")}
        con.executemany("INSERT INTO rules(pattern, category_id, priority, direction) VALUES (?,?,90,?)",
                        [(p, cat[c], d) for p, c, d in MORE_RULES if c in cat and p not in have])
    con.execute("INSERT OR REPLACE INTO meta(key, value) VALUES ('version', '5')")
    con.execute("INSERT OR IGNORE INTO fx_rates(currency, eur_per_unit) VALUES ('EUR', 1.0)")
    con.execute("INSERT OR IGNORE INTO fx_rates(currency, eur_per_unit) VALUES ('EURX', 1.0)")
    con.commit()


def books(con) -> dict:
    """{id: nosaukums}"""
    return {r["id"]: r["name"] for r in con.execute("SELECT id, name FROM books ORDER BY id")}


def book_for_source(con, source: str):
    for r in con.execute("SELECT id, sources FROM books ORDER BY id"):
        if source in [s.strip() for s in (r["sources"] or "").split(",")]:
            return r["id"]
    return con.execute("SELECT MIN(id) FROM books").fetchone()[0]


def get_or_create_account(con, name, source, currency, iban=None, book_id=None) -> int:
    row = con.execute("SELECT id FROM accounts WHERE name=?", (name,)).fetchone()
    if row:
        return row["id"]
    cur = con.execute(
        "INSERT INTO accounts(name, source, currency, iban, book_id) VALUES (?,?,?,?,?)",
        (name, source, currency, iban, book_id or book_for_source(con, source)),
    )
    return cur.lastrowid


def book_filter(book_id, alias="a") -> tuple[str, list]:
    """SQL fragments kontu filtrēšanai pēc grāmatas (None = visas)."""
    if book_id is None:
        return "", []
    return f" AND {alias}.book_id = ?", [book_id]


def fx_map(con) -> dict:
    return {r["currency"]: r["eur_per_unit"] for r in con.execute("SELECT * FROM fx_rates")}
