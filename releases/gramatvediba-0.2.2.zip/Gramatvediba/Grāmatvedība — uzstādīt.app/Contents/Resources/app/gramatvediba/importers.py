"""CSV importētāji: Swedbank, Revolut, PayPal, Nexo.

Katrs parseris atgriež ParseResult ar normalizētiem darījumiem un (ja ir) atlikumiem.
Formāts tiek atpazīts pēc kolonnu nosaukumiem, tāpēc nav jānorāda, no kuras bankas fails ir.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
from dataclasses import dataclass, field
from datetime import datetime


# ------------------------------------------------------------------ datu struktūras
@dataclass
class Tx:
    account: str            # konta nosaukums programmā, piem. "Swedbank LV12HABA..."
    currency: str
    date: str               # YYYY-MM-DD
    amount: float           # ar zīmi
    counterparty: str = ""
    description: str = ""
    kind_raw: str = ""
    external_id: str = ""
    hint_category: str = "" # kategorija, ko iesaka pats avots (piem. Revolut TOPUP)
    pending: bool = False   # vēl nav apstiprināts (Revolut PENDING) — nākamajā importā tiek aizstāts
    ref: str = ""           # saistītā darījuma atsauce (PayPal Reference Txn ID, Revolut laiks, Nexo id) – maiņas pāriem
    raw: dict = field(default_factory=dict)


@dataclass
class Balance:
    account: str
    currency: str
    date: str
    balance: float
    kind: str = "beigu"


@dataclass
class ParseResult:
    source: str
    txs: list[Tx] = field(default_factory=list)
    balances: list[Balance] = field(default_factory=list)
    skipped: int = 0
    warnings: list[str] = field(default_factory=list)
    seen_ids: list[str] = field(default_factory=list)   # visi faila darījumu id (arī izlaistie) — aizstāšanai


class FormatError(Exception):
    pass


# ------------------------------------------------------------------ palīgi
def decode(data: bytes) -> str:
    for enc in ("utf-8-sig", "cp1257", "cp1252", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def sniff_rows(text: str) -> list[list[str]]:
    sample = text[:5000]
    first = sample.splitlines()[0] if sample else ""
    delim = max([";", ",", "\t"], key=first.count)
    return [r for r in csv.reader(io.StringIO(text), delimiter=delim) if any(c.strip() for c in r)]


def norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().strip('"').lower())


def parse_amount(s) -> float:
    if s is None:
        return 0.0
    s = str(s).strip().replace("\xa0", "").replace(" ", "")
    s = re.sub(r"[^\d,.\-+]", "", s)          # noņem $, € u.c.
    if not s or s in "-+":
        return 0.0
    if "," in s and "." in s:
        # pēdējais atdalītājs ir decimāldaļa
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    return float(s)


DATE_FORMATS = [
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d",
    "%d.%m.%Y %H:%M:%S", "%d.%m.%Y %H:%M", "%d.%m.%Y",
    "%d/%m/%Y %H:%M:%S", "%d/%m/%Y", "%m/%d/%Y", "%Y/%m/%d",
    "%d-%m-%Y",
]


def parse_date(s: str, prefer_dayfirst=True) -> str:
    s = (s or "").strip()
    fmts = DATE_FORMATS if prefer_dayfirst else [f for f in DATE_FORMATS if f != "%d/%m/%Y"] + ["%d/%m/%Y"]
    for f in fmts:
        try:
            return datetime.strptime(s, f).strftime("%Y-%m-%d")
        except ValueError:
            continue
    # ISO ar laika zonu u.tml.
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).strftime("%Y-%m-%d")
    except ValueError:
        raise FormatError(f"Neatpazīts datums: {s!r}")


def make_hash(*parts) -> str:
    return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()


def col_index(header: list[str], aliases: dict[str, list[str]], required: list[str]) -> dict[str, int]:
    h = [norm(c) for c in header]
    out = {}
    for key, names in aliases.items():
        for n in names:
            if n.endswith("*"):           # prefikss, piem. "komisij*"
                hit = next((i for i, c in enumerate(h) if c.startswith(n[:-1])), None)
                if hit is not None:
                    out[key] = hit
                    break
            elif n in h:
                out[key] = h.index(n)
                break
    missing = [k for k in required if k not in out]
    if missing:
        raise FormatError(f"Trūkst kolonnu: {missing}. Atrastās: {header}")
    return out


def get(row, idx, key, default=""):
    i = idx.get(key)
    if i is None or i >= len(row):
        return default
    return row[i].strip()


# ------------------------------------------------------------------ Swedbank
SWED_ALIASES = {
    "account": ["klienta konts", "account no", "account number", "konto"],
    "rowtype": ["ieraksta tips", "row type", "reatüüp"],
    "date": ["datums", "date", "kuupäev"],
    "party": ["saņēmējs/maksātājs", "beneficiary/payer", "saaja/maksja"],
    "details": ["informācija saņēmējam", "details", "selgitus"],
    "amount": ["summa", "amount"],
    "currency": ["valūta", "currency", "valuuta"],
    "dc": ["debets/kredīts", "debit/credit", "deebet/kreedit (d/c)"],
    "archive": ["arhīva kods", "transfer reference", "archive id", "arhiivitunnus"],
    "ptype": ["maksājuma veids", "transaction type", "tehingu tüüp"],
    "ref": ["refernces numurs", "references numurs", "reference number", "viitenumber"],
    "doc": ["dokumenta numurs", "document number", "dokumendi number"],
}


def parse_swedbank(rows: list[list[str]]) -> ParseResult:
    idx = col_index(rows[0], SWED_ALIASES, ["account", "rowtype", "date", "amount", "dc"])
    res = ParseResult("swedbank")
    seen = {}
    for row in rows[1:]:
        acc_no = get(row, idx, "account")
        if not acc_no:
            res.skipped += 1
            continue
        acc = f"Swedbank {acc_no}"
        cur = get(row, idx, "currency") or "EUR"
        rtype = get(row, idx, "rowtype")
        date = parse_date(get(row, idx, "date"))
        amt = parse_amount(get(row, idx, "amount"))
        dc = get(row, idx, "dc").upper()
        signed = -amt if dc.startswith("D") else amt
        if rtype == "10":       # sākuma atlikums
            res.balances.append(Balance(acc, cur, date, signed, "sakuma"))
            continue
        if rtype == "86":       # beigu atlikums
            res.balances.append(Balance(acc, cur, date, signed, "beigu"))
            continue
        if rtype != "20":       # 82 = apgrozījums, 900 = procenti u.c. kopsavilkumi
            res.skipped += 1
            continue
        archive = get(row, idx, "archive")
        party = get(row, idx, "party")
        details = get(row, idx, "details")
        ptype = get(row, idx, "ptype")
        hint = "Bankas komisijas" if ptype.upper() in ("KOM", "K") or "komisija" in details.lower() and not party else ""
        key = (acc, date, signed, party, details, archive)
        seen[key] = seen.get(key, 0) + 1
        res.txs.append(Tx(
            account=acc, currency=cur, date=date, amount=signed,
            counterparty=party, description=details, kind_raw=ptype,
            external_id=archive, hint_category=hint,
            raw={"row": row, "_n": seen[key]},
        ))
    return res


# ------------------------------------------------------------------ Revolut
REV_ALIASES = {      # angļu un latviešu eksports (Revolut aplikācija valodā LV)
    "type": ["type", "veids", "tips"],
    "product": ["product", "produkts"],
    "started": ["started date", "sākuma datums"],
    "completed": ["completed date", "pabeigšanas datums", "beigu datums"],
    "description": ["description", "apraksts"],
    "amount": ["amount", "summa"],
    "fee": ["fee", "komisij*", "maksa"],
    "currency": ["currency", "valūta"],
    "state": ["state", "statuss", "stāvoklis"],
    "balance": ["balance", "atlikums"],
}

REV_HINTS = {
    "TOPUP": "Pārskaitījumi starp saviem kontiem",
    "EXCHANGE": "Valūtas / kripto maiņa",
    "FEE": "Bankas komisijas",
    "INTEREST": "Procenti / ienesīgums",
    "CASHBACK": "Citi ienākumi",
}

# darījuma veids latviski → Revolut kods (pēc vārda daļas)
REV_KIND_WORDS = [
    ("papildin", "TOPUP"), ("top-up", "TOPUP"), ("topup", "TOPUP"),
    ("apmaiņ", "EXCHANGE"), ("apmain", "EXCHANGE"), ("maiņ", "EXCHANGE"), ("exchange", "EXCHANGE"),
    ("komisij", "FEE"), ("fee", "FEE"),
    ("procent", "INTEREST"), ("interest", "INTEREST"),
    ("naudas atmaks", "CASHBACK"), ("cashback", "CASHBACK"),
    ("pārskait", "TRANSFER"), ("transfer", "TRANSFER"),
    ("kart", "CARD_PAYMENT"), ("card", "CARD_PAYMENT"),
    ("atmaksa", "REFUND"), ("refund", "REFUND"),
]
REV_OK = ("COMPLETED", "PABEIGTS", "PABEIGTA", "IZPILDĪTS", "IZPILDĪTA", "IZPILDITS")
REV_PENDING = ("PENDING", "GAIDA", "GAIDĀMS", "APSTRĀDĒ", "APSTRADE")
REV_BAD = ("REVERT", "ATCEL", "ATGRIEZ", "DECLIN", "NORAID", "FAIL", "NEIZDEV")


def rev_kind(raw: str) -> str:
    u = raw.strip().upper().replace(" ", "_")
    if u in REV_HINTS or u in ("TRANSFER", "CARD_PAYMENT", "REFUND", "ATM"):
        return u
    low = raw.lower()
    return next((code for w, code in REV_KIND_WORDS if w in low), u)


def rev_product(p: str) -> str:
    """Produkta nosaukums vienādi abās valodās, lai konts nedalās divos."""
    low = (p or "").strip().lower()
    if not low or low.startswith(("current", "pašreiz", "norēķin", "tekoš")):
        return "Current"
    if low.startswith(("saving", "krāj", "uzkrāj")):
        return "Savings"
    if low.startswith(("deposit", "depozīt", "noguld")):
        return "Deposit"
    return p.strip()


def parse_revolut(rows: list[list[str]]) -> ParseResult:
    idx = col_index(rows[0], REV_ALIASES, ["type", "started", "amount", "currency", "description"])
    res = ParseResult("revolut")
    last_balance = {}
    seen = {}
    unknown_states = set()
    for row in rows[1:]:
        state = get(row, idx, "state").upper()
        pending = False
        if state and state not in REV_OK:
            if any(state.startswith(p) for p in REV_PENDING):
                pending = True      # ieskaitām (bankā tas jau samazina atlikumu); nākamais imports to aizstās
            elif any(b in state for b in REV_BAD):
                res.skipped += 1
                continue
            else:
                unknown_states.add(state)       # nezināms statuss — ieskaitām, bet brīdinām
        rtype = rev_kind(get(row, idx, "type"))
        product = rev_product(get(row, idx, "product"))
        cur = get(row, idx, "currency") or "EUR"
        acc = f"Revolut {product} {cur}"
        started = get(row, idx, "started")
        date = parse_date(get(row, idx, "completed") or started)
        amount = parse_amount(get(row, idx, "amount"))
        fee = parse_amount(get(row, idx, "fee"))
        desc = get(row, idx, "description")
        hint = REV_HINTS.get(rtype, "")
        if rtype == "TRANSFER" and product != "Current":
            hint = "Pārskaitījumi starp saviem kontiem"
        if any(w in desc.lower() for w in ("savings", "pocket", "vault", "krājkont", "uzkrāj")):
            hint = "Pārskaitījumi starp saviem kontiem"
        key = (acc, started, amount, desc)
        seen[key] = seen.get(key, 0) + 1
        res.txs.append(Tx(
            account=acc, currency=cur, date=date, amount=amount,
            counterparty=desc, description=desc, kind_raw=rtype,
            external_id=(f"pending|{started}" if pending else f"{started}|{get(row, idx, 'balance')}"), ref=started,
            pending=pending,
            hint_category=hint, raw={"row": row, "_n": seen[key]},
        ))
        if fee:
            res.txs.append(Tx(
                account=acc, currency=cur, date=date, amount=-abs(fee),
                counterparty="Revolut", description=f"Komisija: {desc}", kind_raw="FEE",
                external_id=(f"pending|{started}|fee" if pending else f"{started}|fee|{get(row, idx, 'balance')}"),
                ref=started, pending=pending,
                hint_category="Bankas komisijas", raw={"row": row, "_n": seen[key]},
            ))
        bal = get(row, idx, "balance")
        if bal and not pending and (state in REV_OK or not state or state in unknown_states):
            # pēdējais pēc laika kļūst par beigu atlikumu
            k = acc
            ts = get(row, idx, "completed") or started
            if k not in last_balance or ts >= last_balance[k][0]:
                last_balance[k] = (ts, date, parse_amount(bal), cur)
    for acc, (_, date, bal, cur) in last_balance.items():
        res.balances.append(Balance(acc, cur, date, bal, "beigu"))
    if unknown_states:
        res.warnings.append("Nezināms statuss (darījumi iekļauti): " + ", ".join(sorted(unknown_states)))
    return res


# ------------------------------------------------------------------ PayPal
PP_ALIASES = {
    "date": ["date", "datums"],
    "time": ["time", "laiks"],
    "name": ["name", "vārds"],
    "type": ["type", "veids"],
    "status": ["status", "statuss"],
    "currency": ["currency", "valūta"],
    "gross": ["gross", "bruto", "amount", "summa"],
    "fee": ["fee", "fees", "maksa", "komisija", "komisijas maksa"],
    "net": ["net", "neto", "total", "kopā", "kopsumma"],
    "rate": ["exchange rate", "maiņas kurss", "valūtas kurss"],
    "txid": ["transaction id", "darījuma id"],
    "ref": ["reference txn id", "atsauces darījuma id"],
    "balance": ["balance", "atlikums"],
    "subject": ["subject", "item title", "temats"],
    "balance_impact": ["balance impact", "ietekme uz atlikumu"],
}

# PayPal ieraksti, kas ir naudas pārvietošana, nevis tēriņš
PP_TRANSFER_WORDS = [
    "bank deposit", "general card deposit", "general credit card deposit", "user initiated withdrawal",
    "withdraw funds", "transfer to bank", "funding", "card deposit", "bank transfer",
    "general withdrawal", "reversal of general account hold", "account hold",
]


def parse_paypal(rows: list[list[str]]) -> ParseResult:
    """Divi PayPal eksporta veidi: "Activity report" (Gross/Fee/Net, Reference Txn ID) un "Activity download"
    (Amount/Fees/Total, Exchange Rate, bez atsauces — maiņas puses sapāro pēc vienāda laika)."""
    idx = col_index(rows[0], PP_ALIASES, ["date", "currency", "gross", "txid"])
    res = ParseResult("paypal")
    last_balance = {}
    for n, row in enumerate(rows[1:]):
        status = get(row, idx, "status").lower()
        if status and status not in ("completed", "pabeigts", "pabeigta", "pabeigts darījums"):
            res.skipped += 1
            continue
        rtype = get(row, idx, "type")
        tl = rtype.lower()
        cur = get(row, idx, "currency") or "EUR"
        acc = f"PayPal {cur}"
        date = parse_date(get(row, idx, "date"), prefer_dayfirst=True)
        ts = f"{date} {get(row, idx, 'time')}"
        net_s = get(row, idx, "net")
        amount = parse_amount(net_s) if net_s else parse_amount(get(row, idx, "gross"))
        if get(row, idx, "balance_impact").lower() == "memo":
            res.skipped += 1          # informatīvs ieraksts, atlikumu neietekmē
            continue
        name = get(row, idx, "name")
        hint = ""
        conversion = "conversion" in tl or "konvert" in tl or "maiņ" in tl
        if conversion:
            hint = "Valūtas / kripto maiņa"
        elif any(w in tl for w in PP_TRANSFER_WORDS):
            hint = "Pārskaitījumi starp saviem kontiem"
        if amount == 0:
            res.skipped += 1
            continue
        ref = get(row, idx, "ref")
        if conversion and not ref:
            ref = f"t:{ts}"           # abas maiņas puses PayPal ieraksta vienā sekundē
        res.txs.append(Tx(
            account=acc, currency=cur, date=date, amount=amount,
            counterparty=name or rtype, description=get(row, idx, "subject") or rtype,
            kind_raw=rtype if not conversion or "conversion" in tl else "Currency Conversion",
            external_id=get(row, idx, "txid") or f"{ts}|{amount}|{name}", ref=ref,
            hint_category=hint, raw={"row": row, "_n": n},
        ))
        bal = get(row, idx, "balance")
        if bal and (acc not in last_balance or (ts, n) >= last_balance[acc][0]):
            last_balance[acc] = ((ts, n), date, parse_amount(bal), cur)   # jaunākais pēc laika (failā var būt otrādi)
    for acc, (_, date, bal, cur) in last_balance.items():
        res.balances.append(Balance(acc, cur, date, bal, "beigu"))
    return res


# ------------------------------------------------------------------ Nexo
NEXO_ALIASES = {
    "txid": ["transaction"],
    "type": ["type"],
    "in_cur": ["input currency", "currency"],
    "in_amt": ["input amount", "amount"],
    "out_cur": ["output currency"],
    "out_amt": ["output amount"],
    "usd": ["usd equivalent"],
    "details": ["details"],
    "date": ["date / time (utc)", "date / time", "date"],
}

NEXO_SAME = {"EURX": "EUR", "USDX": "USD", "GBPX": "GBP"}
NEXO_INCOME = ("interest", "fixed term interest", "cashback", "exchange cashback", "referral bonus",
               "dividend", "bonus", "airdrop")
NEXO_SKIP = ("locking term deposit", "unlocking term deposit", "transfer in", "transfer out",
             "transfer from pro wallet", "transfer to pro wallet", "exchange collateral")


def _nexo_merchant(details: str) -> str:
    """'approved / JYSK, TUKUMS | TUKUMS | LVA' → 'JYSK, TUKUMS'"""
    d = details.split("/", 1)[1] if "/" in details else details
    return d.split("|")[0].strip() or "Nexo karte"


def parse_nexo(rows: list[list[str]]) -> ParseResult:
    """Nexo eksports. Kartes pirkumam vienā sekundē ir vairāki ieraksti:
      Nexo Card Purchase (veikals, summa EUR; USD = tikai kredītlīnijas ekvivalents),
      Nexo Card Transaction Fee (FX komisija),
      Credit Card Fiatx Exchange To Withdraw (īstā norakstīšana no EUR atlikuma = pirkums + komisija),
    vēlāk Withdraw Exchanged (Nexo iekšējais norēķins). Ieskaitām tikai norakstīšanu: pirkums + komisija."""
    idx = col_index(rows[0], NEXO_ALIASES, ["txid", "type", "in_cur", "in_amt", "date"])
    res = ParseResult("nexo")
    items = []
    for row in rows[1:]:
        details = get(row, idx, "details")
        res.seen_ids.append(get(row, idx, "txid"))
        if "pending" in details.lower() or "rejected" in details.lower():
            res.skipped += 1
            continue
        items.append(row)
    # kartes pirkumi un komisijas pēc laika (sekundes precizitāte)
    card, fees = {}, {}
    for row in items:
        tl = get(row, idx, "type").lower()
        ts = get(row, idx, "date")
        if tl == "nexo card purchase":
            card.setdefault(ts, []).append(row)
        elif tl == "nexo card transaction fee":
            fees.setdefault(ts, []).append(row)
    used = set()

    for row in items:
        t = get(row, idx, "type")
        tl = t.lower()
        txid = get(row, idx, "txid")
        ts = get(row, idx, "date")
        date = parse_date(ts)
        details = get(row, idx, "details")
        usd = get(row, idx, "usd")
        in_cur = get(row, idx, "in_cur").upper()
        in_amt = parse_amount(get(row, idx, "in_amt"))
        out_cur = get(row, idx, "out_cur").upper() or in_cur
        out_amt_s = get(row, idx, "out_amt")
        out_amt = parse_amount(out_amt_s) if out_amt_s else in_amt
        if tl in NEXO_SKIP:
            res.skipped += 1
            continue

        def leg(cur, amt, suffix, hint, cp="Nexo", desc=None):
            cur = NEXO_SAME.get(cur, cur)     # EURX ir tas pats eiro Nexo iekšienē — viens konts "Nexo EUR"
            res.txs.append(Tx(
                account=f"Nexo {cur}", currency=cur, date=date, amount=round(amt, 8),
                counterparty=cp, description=desc or f"{t}: {details}".strip(": "),
                kind_raw=t, external_id=f"{txid}{suffix}", hint_category=hint, ref=txid,
                raw={"row": row, "usd": usd},
            ))

        same = NEXO_SAME.get(in_cur, in_cur) == NEXO_SAME.get(out_cur, out_cur)
        if tl in ("nexo card purchase", "nexo card transaction fee"):
            continue                              # apstrādā kopā ar norakstīšanu (zemāk)
        if tl.startswith("credit card") and "exchange to withdraw" in tl:
            total = abs(in_amt)                   # norakstīts no EUR atlikuma
            buys = [r for r in card.get(ts, []) if id(r) not in used]
            if buys:
                b = buys[0]; used.add(id(b))
                merchant = _nexo_merchant(get(b, idx, "details"))
                price = abs(parse_amount(get(b, idx, "out_amt")))
                leg(in_cur, -min(price, total), "", "", cp=merchant, desc=f"Kartes pirkums: {merchant}")
                fee = round(total - min(price, total), 2)
                for f in fees.get(ts, []):
                    used.add(id(f))
                if fee >= 0.005:
                    leg(in_cur, -fee, ":fee", "Bankas komisijas", desc=f"Kartes FX komisija: {merchant}")
            else:
                leg(in_cur, -total, "", "", cp="Karte", desc="Kartes pirkums")
            continue
        if tl == "deposit to exchange":           # eiro iemaksa no bankas / Revolut
            leg(in_cur, abs(in_amt), "", "Pārskaitījumi starp saviem kontiem")
        elif tl in ("withdraw exchanged", "exchange deposited on", "exchange to withdraw") or ("exchange" in tl and same):
            res.skipped += 1                      # Nexo iekšējais norēķins / EUR ↔ EURX — tā pati nauda
        elif "exchange" in tl and "cashback" not in tl or tl in ("manual sell", "manual buy"):
            leg(in_cur, -abs(in_amt), ":in", "Valūtas / kripto maiņa")
            leg(out_cur, abs(out_amt), ":out", "Valūtas / kripto maiņa")
        elif any(w == tl or w in tl for w in NEXO_INCOME):
            leg(out_cur, abs(out_amt), "", "Procenti / ienesīgums")
        elif "card refund" in tl:
            leg(out_cur, abs(out_amt), "", "", cp=_nexo_merchant(details), desc=f"Kartes atmaksa: {_nexo_merchant(details)}")
        elif "withdraw" in tl or "repayment" in tl or "liquidation" in tl:
            leg(in_cur, -abs(in_amt), "", "Pārskaitījumi starp saviem kontiem")
        elif "deposit" in tl or "top up" in tl:
            leg(out_cur, abs(out_amt), "", "Pārskaitījumi starp saviem kontiem")
        elif "loan" in tl:
            leg(out_cur, abs(out_amt), "", "")
        else:
            res.warnings.append(f"Nezināms Nexo tips '{t}' importēts pēc zīmes")
            leg(in_cur, in_amt, "", "")
    for ts, lst in card.items():
        for b in lst:
            if id(b) not in used:
                res.warnings.append(f"Kartes pirkumam nav norakstīšanas, nav ieskaitīts: {_nexo_merchant(get(b, idx, 'details'))} "
                                    f"{get(b, idx, 'out_amt')} EUR ({ts[:10]})")
                res.skipped += 1
    return res


# ------------------------------------------------------------------ atpazīšana
def detect(header: list[str]) -> str:
    h = {norm(c) for c in header}
    if h & {"ieraksta tips", "row type", "reatüüp"}:
        return "swedbank"
    if {"started date", "product", "state"} <= h or {"started date", "completed date"} <= h:
        return "revolut"
    if "sākuma datums" in h and ({"produkts", "pabeigšanas datums", "veids"} & h):
        return "revolut"
    if "transaction id" in h and ({"gross", "net", "total", "amount"} & h) or "darījuma id" in h:
        return "paypal"
    if "transaction" in h and ("usd equivalent" in h or "input currency" in h):
        return "nexo"
    raise FormatError(f"Nevarēju atpazīt faila formātu. Kolonnas: {header}")


PARSERS = {"swedbank": parse_swedbank, "revolut": parse_revolut, "paypal": parse_paypal, "nexo": parse_nexo}


def parse_file(data: bytes, source: str | None = None) -> ParseResult:
    rows = sniff_rows(decode(data))
    if not rows:
        raise FormatError("Fails ir tukšs")
    # dažiem eksportiem pirms galvenes ir apraksta rindas – meklējam galveni pirmajās 15 rindās
    for i, r in enumerate(rows[:15]):
        try:
            src = source or detect(r)
            return PARSERS[src](rows[i:])
        except FormatError:
            continue
    src = source or detect(rows[0])
    return PARSERS[src](rows)


def tx_hash(tx: Tx) -> str:
    if tx.external_id:
        return make_hash(tx.account, tx.external_id, tx.amount, tx.raw.get("_n", ""))
    return make_hash(tx.account, tx.date, tx.amount, tx.counterparty, tx.description, tx.raw.get("_n", ""))


def tx_raw_json(tx: Tx) -> str:
    return json.dumps(tx.raw, ensure_ascii=False)
