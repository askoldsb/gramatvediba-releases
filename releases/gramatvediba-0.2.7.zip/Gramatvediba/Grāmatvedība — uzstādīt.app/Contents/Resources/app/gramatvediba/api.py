"""API funkcijas: POST /api/<nosaukums> ar JSON → {"ok": true, ...}. Katrai funkcijai nosaukums api_<nosaukums>."""
from __future__ import annotations

import base64
import os
import subprocess
import sys
import time
from datetime import date

from . import NAME, VERSION, backup, config, db, importers, invoices, obligations, store, transfers, updater

con = None


def setup(path=None):
    global con
    con = db.connect(path)
    db.init_db(con)
    try:
        backup.daily(con)
    except Exception as e:
        print("rezerves kopija:", e)
    try:
        transfers.match_all(con, config.get("own_names"))
    except Exception as e:
        print("pārskaitījumi:", e)
    try:
        obligations.regenerate_all(con)       # beztermiņa saistībām grafiks gadu uz priekšu
        obligations.match_payments(con)
    except Exception as e:
        print("saistības:", e)
    return con


def _book(d):
    b = d.get("book")
    return int(b) if b not in (None, "", 0, "0") else None


def _num(v):
    if v in (None, ""):
        return None
    return float(str(v).replace(",", ".").replace(" ", ""))


def _int(v):
    return int(v) if v not in (None, "", 0, "0") else None


# ------------------------------------------------------------------ vispārīgi
def api_init(d):
    return {"name": NAME, "version": VERSION, "books": [{"id": k, "name": v} for k, v in db.books(con).items()],
            "settings": config.load(), "categories": api_categories({})["categories"],
            "data_dir": str(config.app_dir())}


def api_settings_save(d):
    return {"settings": config.update(d.get("values") or {})}


def api_overview(d):
    book = _book(d)
    obligations.match_payments(con)
    tx = store.transactions(con, d.get("from"), d.get("to"), book)
    bal = store.account_balances(con, book)
    return {
        "balances": bal,
        "total_eur": round(sum(b["eur"] for b in bal if b["eur"] is not None), 2),
        "months": store.monthly_summary(tx),
        "expenses": store.category_summary(tx),
        "incomes": store.category_summary(tx, income=True),
        "transfers": store.transfers_total(tx),
        "cross": transfers.cross_book(con, book, d.get("from"), d.get("to")),
        "upcoming": obligations.upcoming(con, 30, book),
        "missing_fx": sorted({b["currency"] for b in bal if b["eur"] is None and abs(b["balance"]) > 1e-9} |
                             {t["currency"] for t in tx if t["eur"] is None}),
        "has_obligations": bool(con.execute(
            "SELECT 1 FROM obligations WHERE active=1" + (" AND book_id=?" if book else ""), [book] if book else []).fetchone()
            or con.execute("SELECT 1 FROM invoices" + (" WHERE book_id=?" if book else ""), [book] if book else []).fetchone()),
        "uncategorized": sum(1 for t in tx if t["category_id"] is None),
    }


# ------------------------------------------------------------------ imports
def api_import(d):
    out = []
    for f in d.get("files") or []:
        name = f.get("name", "")
        try:
            res = importers.parse_file(base64.b64decode(f["data"]))
            r = store.store_result(con, res, name)
            out.append(dict(r, file=name, ok=True))
        except importers.FormatError as e:
            out.append({"file": name, "ok": False, "error": str(e)})
        except Exception as e:  # noqa
            out.append({"file": name, "ok": False, "error": f"{type(e).__name__}: {e}"})
    tr = transfers.match_all(con, config.get("own_names"))
    linked = obligations.match_payments(con)
    inv = invoices.auto_link_all(con)
    return {"results": out, "linked_obligations": linked, "linked_invoices": inv, "transfers": tr}


def api_imports(d):
    return {"imports": store.imports(con)}


def api_import_delete(d):
    store.delete_import(con, int(d["id"]))
    return {}


# ------------------------------------------------------------------ darījumi
def api_transactions(d):
    tx = store.transactions(con, d.get("from"), d.get("to"), _book(d), d.get("account"), d.get("category"),
                            d.get("q"), d.get("direction"))
    inc = sum(t["eur"] for t in tx if t["eur"] and t["eur"] > 0)
    exp = -sum(t["eur"] for t in tx if t["eur"] and t["eur"] < 0)
    limit = int(d.get("limit") or 1000)
    return {"transactions": tx[:limit], "count": len(tx), "income": round(inc, 2), "expense": round(exp, 2),
            "accounts": [{"id": a["id"], "name": a["name"]} for a in store.account_balances(con, _book(d))]}


def api_tx_update(d):
    ids = d.get("ids") or [d["id"]]
    for i in ids:
        if "category_id" in d:
            con.execute("UPDATE transactions SET category_id=?, category_manual=1 WHERE id=?",
                        (_int(d["category_id"]), int(i)))
        if "note" in d:
            con.execute("UPDATE transactions SET note=? WHERE id=?", (d["note"] or None, int(i)))
    con.commit()
    return {"n": len(ids)}


def api_tx_reset_category(d):
    """Atgriež automātisko kategoriju (atceļ roku izvēli)."""
    for i in d.get("ids") or [d["id"]]:
        con.execute("UPDATE transactions SET category_manual=0 WHERE id=?", (int(i),))
    con.commit()
    return {"changed": store.recategorize_all(con)}


def api_tx_add(d):
    """Manuāls darījums (skaidra nauda u.c.)."""
    amt = _num(d.get("amount"))
    if not amt:
        raise ValueError("Norādi summu")
    res = importers.ParseResult("manual", txs=[importers.Tx(
        account=(d.get("account") or "Skaidra nauda").strip(), currency=(d.get("currency") or "EUR").upper(),
        date=d.get("date") or date.today().isoformat(), amount=amt, counterparty=d.get("counterparty") or "",
        description=d.get("description") or "", kind_raw="manual", external_id=f"manual-{time.time_ns()}")])
    return store.store_result(con, res, "manuāli", book_id=_book(d) or db.books(con) and min(db.books(con)))


def api_tx_delete(d):
    """Dzēš tikai manuāli pievienotus darījumus."""
    con.execute("DELETE FROM transactions WHERE id=? AND kind_raw='manual'", (int(d["id"]),))
    con.commit()
    return {}


# ------------------------------------------------------------------ pārskaitījumi starp saviem kontiem
def api_transfers(d):
    b = _book(d)
    return {"pairs": transfers.pairs(con, b, d.get("from"), d.get("to")),
            "unmatched": transfers.unmatched(con, b, d.get("from"), d.get("to")),
            "own_names": config.get("own_names") or ""}


def api_transfers_match(d):
    if "own_names" in d:
        config.update({"own_names": d.get("own_names") or ""})
    return transfers.match_all(con, config.get("own_names"))


def api_transfer_unlink(d):
    transfers.unlink(con, int(d["id"]))
    return {}


def api_transfer_link(d):
    transfers.link_manual(con, int(d["a"]), int(d["b"]), bool(d.get("refund")))
    return {}


def api_transfer_candidates(d):
    return {"candidates": transfers.candidates(con, int(d["id"]))}


# ------------------------------------------------------------------ kategorijas, kārtulas, kursi, konti
def api_categories(d):
    return {"categories": store.rows(con.execute(
        """SELECT c.id, c.name, c.kind, (SELECT COUNT(*) FROM transactions t WHERE t.category_id=c.id) AS n
           FROM categories c ORDER BY c.kind, c.name"""))}


def api_category_save(d):
    name = (d.get("name") or "").strip()
    kind = d.get("kind") if d.get("kind") in ("ienakumi", "izdevumi", "parskaitijums") else "izdevumi"
    if not name:
        raise ValueError("Norādi nosaukumu")
    if d.get("id"):
        con.execute("UPDATE categories SET name=?, kind=? WHERE id=?", (name, kind, int(d["id"])))
    else:
        con.execute("INSERT INTO categories(name, kind) VALUES (?,?)", (name, kind))
    con.commit()
    return api_categories({})


def api_category_delete(d):
    con.execute("DELETE FROM categories WHERE id=?", (int(d["id"]),))
    con.commit()
    return api_categories({})


def api_rules(d):
    return {"rules": store.rows(con.execute(
        """SELECT r.id, r.pattern, r.category_id, c.name AS category, r.direction, r.priority
           FROM rules r JOIN categories c ON c.id=r.category_id ORDER BY r.priority, r.pattern"""))}


def api_rule_save(d):
    pat = (d.get("pattern") or "").strip().lower()
    if not pat or not d.get("category_id"):
        raise ValueError("Norādi tekstu un kategoriju")
    direction = d.get("direction") if d.get("direction") in ("abi", "ienakums", "izdevums") else "abi"
    prio = int(d.get("priority") or 50)
    if d.get("id"):
        con.execute("UPDATE rules SET pattern=?, category_id=?, direction=?, priority=? WHERE id=?",
                    (pat, int(d["category_id"]), direction, prio, int(d["id"])))
    else:
        con.execute("INSERT INTO rules(pattern, category_id, direction, priority) VALUES (?,?,?,?)",
                    (pat, int(d["category_id"]), direction, prio))
    con.commit()
    return {"changed": store.recategorize_all(con)}


def api_rule_delete(d):
    con.execute("DELETE FROM rules WHERE id=?", (int(d["id"]),))
    con.commit()
    return {"changed": store.recategorize_all(con)}


def api_fx(d):
    rates = store.rows(con.execute("SELECT currency, eur_per_unit FROM fx_rates ORDER BY currency"))
    return {"rates": rates, "missing": store.missing_fx(con)}


def api_fx_save(d):
    cur = (d.get("currency") or "").strip().upper()
    rate = _num(d.get("rate"))
    if not cur:
        raise ValueError("Norādi valūtu")
    if rate is None:
        con.execute("DELETE FROM fx_rates WHERE currency=?", (cur,))
    else:
        con.execute("INSERT OR REPLACE INTO fx_rates VALUES (?,?)", (cur, rate))
    con.commit()
    return api_fx({})


def api_accounts(d):
    return {"accounts": store.rows(con.execute(
        """SELECT a.id, a.name, a.source, a.currency, a.active, a.book_id,
                  (SELECT COUNT(*) FROM transactions t WHERE t.account_id=a.id) AS n
           FROM accounts a ORDER BY a.book_id, a.source, a.name"""))}


def api_account_save(d):
    con.execute("UPDATE accounts SET name=?, active=?, book_id=? WHERE id=?",
                ((d.get("name") or "").strip(), int(bool(d.get("active", True))), _int(d.get("book_id")), int(d["id"])))
    con.commit()
    return api_accounts({})


def api_balance_set(d):
    con.execute("INSERT OR REPLACE INTO balances(account_id, date, balance, kind) VALUES (?,?,?, 'manuals')",
                (int(d["account_id"]), d.get("date") or date.today().isoformat(), _num(d.get("balance")) or 0.0))
    con.commit()
    return {}


def api_books(d):
    return {"books": store.rows(con.execute("SELECT id, name, sources FROM books ORDER BY id"))}


def api_book_save(d):
    name = (d.get("name") or "").strip()
    if not name:
        raise ValueError("Norādi nosaukumu")
    srcs = ",".join(s.strip().lower() for s in (d.get("sources") or "").split(",") if s.strip())
    if d.get("id"):
        con.execute("UPDATE books SET name=?, sources=? WHERE id=?", (name, srcs, int(d["id"])))
    else:
        con.execute("INSERT INTO books(name, sources) VALUES (?,?)", (name, srcs))
    con.commit()
    return api_books({})


def api_book_delete(d):
    bid = int(d["id"])
    if con.execute("SELECT COUNT(*) FROM accounts WHERE book_id=?", (bid,)).fetchone()[0]:
        raise ValueError("Šajā grāmatvedībā ir konti — vispirms pārvieto tos uz citu")
    con.execute("DELETE FROM books WHERE id=?", (bid,))
    con.commit()
    return api_books({})


# ------------------------------------------------------------------ rēķini
def api_invoices(d):
    return {"invoices": invoices.list_invoices(con, _book(d))}


def api_invoice_save(d):
    data = {
        "direction": "izrakstits" if d.get("direction") == "izrakstits" else "sanemts",
        "counterparty": (d.get("counterparty") or "").strip(), "number": d.get("number") or None,
        "issue_date": d.get("issue_date") or None, "due_date": d.get("due_date") or None,
        "amount": _num(d.get("amount")), "currency": (d.get("currency") or "EUR").upper(),
        "category_id": _int(d.get("category_id")), "match_text": d.get("match_text") or None,
        "note": d.get("note") or None, "book_id": _int(d.get("book_id")) or _book(d),
    }
    if not data["counterparty"] or not data["amount"]:
        raise ValueError("Norādi partneri un summu")
    iid = invoices.save_invoice(con, data, _int(d.get("id")))
    invoices.auto_link_all(con)
    return {"id": iid}


def api_invoice_delete(d):
    invoices.delete_invoice(con, int(d["id"]))
    return {}


def api_invoice_detail(d):
    i = int(d["id"])
    return {"payments": invoices.payments(con, i), "suggestions": invoices.suggest_payments(con, i)}


def api_invoice_link(d):
    i, t = int(d["id"]), int(d["tx"])
    inv = next(x for x in invoices.list_invoices(con) if x["id"] == i)
    amt = abs(con.execute("SELECT amount FROM transactions WHERE id=?", (t,)).fetchone()[0])
    invoices.link_payment(con, i, t, min(amt, inv["left"]) if inv["left"] > 0 else amt)
    return api_invoice_detail(d)


def api_invoice_unlink(d):
    invoices.unlink_payment(con, int(d["id"]), int(d["tx"]))
    return api_invoice_detail(d)


# ------------------------------------------------------------------ saistības
def api_obligations(d):
    return {"obligations": obligations.summary(con, _book(d)), "kinds": obligations.KINDS,
            "freq": obligations.FREQ_LABEL}


def api_obligation_get(d):
    i = int(d["id"])
    return {"obligation": obligations.get_obligation(con, i), "schedule": obligations.schedule(con, i)}


def api_obligation_save(d):
    data = {
        "name": (d.get("name") or "").strip(), "kind": d.get("kind") or "cits",
        "direction": "sanemu" if d.get("direction") == "sanemu" else "maksaju",
        "counterparty": d.get("counterparty") or None, "start_date": d.get("start_date"),
        "frequency": d.get("frequency") if d.get("frequency") in obligations.FREQ else "menesis",
        "n_payments": _int(d.get("n_payments")), "payment_amount": _num(d.get("payment_amount")) or None,
        "end_date": (d.get("end_date") or None) if not _int(d.get("n_payments")) else None,
        "principal": _num(d.get("principal")) or None, "interest_rate": _num(d.get("interest_rate")) or None,
        "residual": _num(d.get("residual")) or 0, "currency": (d.get("currency") or "EUR").upper(),
        "match_text": d.get("match_text") or None, "tolerance": _num(d.get("tolerance")) or 1.0,
        "note": d.get("note") or None, "active": int(bool(d.get("active", True))),
        "book_id": _int(d.get("book_id")) or _book(d),
    }
    if not data["name"] or not data["start_date"]:
        raise ValueError("Norādi nosaukumu un pirmā maksājuma datumu")
    oid = obligations.save_obligation(con, data, _int(d.get("id")))
    n = obligations.match_payments(con)
    return {"id": oid, "linked": n}


def api_obligation_delete(d):
    obligations.delete_obligation(con, int(d["id"]))
    return {}


def api_schedule_mark(d):
    obligations.set_manual_paid(con, int(d["sid"]), bool(d.get("paid")))
    if not d.get("paid") and d.get("unlink"):
        obligations.unlink(con, int(d["sid"]))
    return api_obligation_get(d)


def api_obligations_match(d):
    obligations.regenerate_all(con)
    return {"linked": obligations.match_payments(con)}


# ------------------------------------------------------------------ rezerves kopijas, atjaunināšana
def api_backups(d):
    return {"backups": backup.list_backups(), "dir": str(backup.backup_dir())}


def api_backup_now(d):
    backup.make(con, "manuali")
    return api_backups(d)


def api_backup_restore(d):
    backup.restore(d["name"])
    return {}


def api_reveal(d):
    p = str(backup.backup_dir() if d.get("what") == "backups" else config.app_dir())
    if config.IS_MAC:
        subprocess.Popen(["open", p])
    elif config.IS_WIN:
        os.startfile(p)  # noqa
    else:
        subprocess.Popen(["xdg-open", p])
    return {}


def api_update_check(d):
    return updater.check(force=bool(d.get("force")))


def api_update_install(d):
    r = updater.install()
    if not r.get("ok"):
        raise ValueError({"dev": "Šī ir izstrādes kopija (git) — atjauno ar git pull",
                          "readonly": "Programmas mapē nevar rakstīt",
                          "no_update": "Jaunākas versijas nav"}.get(r.get("error"), r.get("error")))
    return {}


def api_update_status(d):
    return updater.status()


def api_whats_new(d):
    return updater.whats_new()


def api_whats_new_seen(d):
    updater.mark_seen()
    return {}


def handlers() -> dict:
    g = globals()
    return {k[4:]: v for k, v in g.items() if k.startswith("api_") and callable(v)}


if __name__ == "__main__":
    print(sorted(handlers()), file=sys.stderr)
