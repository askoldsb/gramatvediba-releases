"""Viena un tā pati nauda starp taviem kontiem.

1. Valūtas maiņa (PayPal "Currency Conversion", Revolut EXCHANGE, Nexo Exchange): abas puses sasaista pēc atsauces
   (ref), no tām aprēķina faktisko kursu un ar to novērtē arī ienākumu, kas tika samainīts (PayPal — pēc
   Reference Txn ID, citādi — tuvākā maiņa tajā pašā kontā).
2. Pārskaitījumi starp kontiem (PayPal → Revolut, Revolut → Nexo, Swedbank ↔ Swedbank, Nexo → banka …): izejošo un
   ienākošo darījumu sapāro pēc summas, datuma un pazīmēm tekstā. Abas puses kļūst par pārskaitījumu, tās
   neskaitās ne ienākumos, ne izdevumos.
"""
from __future__ import annotations

import re
from datetime import date

from .store import rows

CCY_CLASS = {"EURX": "EUR", "USDX": "USD", "GBPX": "GBP"}
TRANSFER_CAT = "Pārskaitījumi starp saviem kontiem"
CONV_CAT = "Valūtas / kripto maiņa"
REFUND_CAT = "Atmaksas un atcelti pirkumi"
TRANSFER_WORDS = ("top-up", "topup", "top up", "papildin", "withdraw", "izmaks", "izņem", "pārskaitījums sev",
                  "transfer to", "transfer from", "to eur", "from eur", "payment from", "own account", "savs konts",
                  "starp kontiem", "deposit", "iemaks", "pocket", "savings", "vault", "krājkont")
SOURCE_WORDS = {"paypal": ("paypal",), "revolut": ("revolut",), "nexo": ("nexo",),
                "swedbank": ("swedbank", "hababank", "habalv22", "haba")}
IBAN_RX = re.compile(r"[A-Z]{2}\d{2}[A-Z0-9]{11,30}")


def ccy(c: str) -> str:
    c = (c or "").upper()
    return CCY_CLASS.get(c, c)


def is_conversion(kind_raw: str) -> bool:
    k = (kind_raw or "").lower()
    if "cashback" in k or "deposit" in k or "withdraw" in k:     # Nexo "Deposit To Exchange" u.c. = iemaksa/izmaksa
        return False
    return any(w in k for w in ("currency conversion", "valūtas konvert", "konvertēšana", "exchange", "maiņ"))


def _d(s: str) -> date:
    return date.fromisoformat(s[:10])


def _txs(con, where="1=1", params=()):
    return rows(con.execute(
        f"""SELECT t.id, t.date, t.amount, t.currency, t.counterparty, t.description, t.kind_raw, t.external_id,
                   t.ref, t.category_id, t.category_manual, t.eur_rate, t.rate_note, c.kind AS cat_kind,
                   a.id AS account_id, a.name AS account, a.source, a.book_id
            FROM transactions t JOIN accounts a ON a.id=t.account_id LEFT JOIN categories c ON c.id=t.category_id
            WHERE {where}""", params))


def _linked_ids(con) -> set:
    s = set()
    for r in con.execute("SELECT out_tx, in_tx FROM transfer_links"):
        s.update((r[0], r[1]))
    return s


def _cat_id(con, name):
    r = con.execute("SELECT id FROM categories WHERE name=?", (name,)).fetchone()
    return r[0] if r else None


def _mark(con, tx: dict, cat_name: str):
    """Pārskaitījuma kategorija abām pusēm (ja lietotājs nav izvēlējies citu pārskaitījuma kategoriju)."""
    if tx["cat_kind"] == "parskaitijums":
        return
    if tx["category_manual"] == 1:
        return
    cid = _cat_id(con, cat_name)
    if cid:
        con.execute("UPDATE transactions SET category_id=?, category_manual=3 WHERE id=?", (cid, tx["id"]))


def _link(con, o: dict, i: dict, kind: str, rate=None, auto=1):
    con.execute("INSERT INTO transfer_links(out_tx, in_tx, kind, rate, auto) VALUES (?,?,?,?,?)",
                (o["id"], i["id"], kind, rate, auto))
    cat = {"maina": CONV_CAT, "atmaksa": REFUND_CAT}.get(kind, TRANSFER_CAT)
    _mark(con, o, cat)
    _mark(con, i, cat)


# ------------------------------------------------------------------ 1. valūtas maiņa
def _set_rate(con, t, rate, note):
    con.execute("UPDATE transactions SET eur_rate=?, rate_note=? WHERE id=?", (rate, note, t["id"]))
    t["eur_rate"], t["rate_note"] = rate, note


def _conv_rates(con, o, i):
    """Kursi abām maiņas pusēm (EUR par 1 vienību), ja viena puse ir EUR."""
    src = {"paypal": "PayPal", "revolut": "Revolut", "nexo": "Nexo"}.get(o["source"], o["source"].capitalize())
    note = f"{src} maiņa {o['date'][8:10]}.{o['date'][5:7]}.{o['date'][:4]}"
    if ccy(i["currency"]) == "EUR" and abs(o["amount"]) > 0:
        _set_rate(con, o, i["amount"] / abs(o["amount"]), note)
        _set_rate(con, i, 1.0, note)
    elif ccy(o["currency"]) == "EUR" and i["amount"] > 0:
        _set_rate(con, i, abs(o["amount"]) / i["amount"], note)
        _set_rate(con, o, 1.0, note)


def match_conversions(con) -> int:
    linked = _linked_ids(con)
    groups = {}
    for t in _txs(con, "t.ref IS NOT NULL AND t.ref <> ''"):
        if t["id"] in linked or not is_conversion(t["kind_raw"]):
            continue
        groups.setdefault((t["source"], t["ref"]), []).append(t)
    n = 0
    for g in groups.values():
        outs = sorted([t for t in g if t["amount"] < 0], key=lambda t: t["id"])
        ins = sorted([t for t in g if t["amount"] > 0], key=lambda t: t["id"])
        for o in outs:
            i = next((x for x in ins if ccy(x["currency"]) != ccy(o["currency"])), None)
            if not i:
                continue
            ins.remove(i)
            _link(con, o, i, "maina", round(i["amount"] / abs(o["amount"]), 8) if o["amount"] else None)
            _conv_rates(con, o, i)
            n += 1
    con.commit()
    return n


def propagate_rates(con) -> int:
    """Ārvalstu valūtas darījumiem (piem. Shutterstock USD izmaksa PayPal) — kurss no tās maiņas, ar kuru šī nauda
    tika samainīta uz EUR. PayPal: maiņas Reference Txn ID = maksājuma Transaction ID. Citādi — tuvākā maiņa
    tajā pašā kontā (vispirms nākamā, tad iepriekšējā, ≤ 31 diena)."""
    conv = {}
    for r in con.execute("SELECT out_tx, in_tx FROM transfer_links WHERE kind='maina'"):
        conv[r[0]] = conv[r[1]] = True
    con.execute("UPDATE transactions SET eur_rate=NULL, rate_note=NULL WHERE rate_note LIKE 'auto:%'")
    legs = [t for t in _txs(con, "t.eur_rate IS NOT NULL") if t["id"] in conv and ccy(t["currency"]) != "EUR"]
    by_ref = {(t["source"], t["ref"], t["currency"]): t for t in legs if t["ref"]}
    by_acc = {}
    for t in legs:
        by_acc.setdefault(t["account_id"], []).append(t)
    n = 0
    for t in _txs(con, "t.eur_rate IS NULL"):
        if t["id"] in conv or ccy(t["currency"]) == "EUR":
            continue
        leg = by_ref.get((t["source"], t["external_id"], t["currency"]))
        how = "šī maksājuma maiņa"
        if not leg:
            cands = by_acc.get(t["account_id"], [])
            td = _d(t["date"])
            after = [c for c in cands if 0 <= (_d(c["date"]) - td).days <= 31]
            before = [c for c in cands if 0 < (td - _d(c["date"])).days <= 31]
            exact = [c for c in after if abs(abs(c["amount"]) - abs(t["amount"])) < 0.005]
            leg = (min(exact, key=lambda c: (_d(c["date"]) - td).days) if exact else
                   min(after, key=lambda c: (_d(c["date"]) - td).days) if after else
                   min(before, key=lambda c: (td - _d(c["date"])).days) if before else None)
            how = "šīs summas maiņa" if exact else "tuvākā maiņa"
        if leg:
            _set_rate(con, t, leg["eur_rate"], f"auto:{how} — {leg['rate_note']}")
            n += 1
    con.commit()
    return n


# ------------------------------------------------------------------ 2. pārskaitījumi starp kontiem
def _own_ids(con) -> list[str]:
    """Tavu kontu identifikatori tekstā (IBAN no Swedbank konta nosaukuma u.tml.)."""
    out = []
    for (name,) in con.execute("SELECT name FROM accounts"):
        out += [m.lower() for m in IBAN_RX.findall(name.replace(" ", ""))]
    return out


def _text(t):
    return f"{t['counterparty'] or ''} {t['description'] or ''} {t['kind_raw'] or ''}".lower()


def _hint(a: dict, b: dict, own: list[str]) -> int:
    """Pazīmes tekstā: 3 — minēts otra konta avots, tavs IBAN vai vārds; 2/1 — vispārīgi pārskaitījuma vārdi
    abās / vienā pusē; 0 — nekā."""
    ta, tb = _text(a), _text(b)
    for x, other in ((ta, b), (tb, a)):
        if any(w in x for w in SOURCE_WORDS.get(other["source"], (other["source"],))):
            return 3
        if any(i in x.replace(" ", "") for i in own):
            return 3
    wa, wb = any(w in ta for w in TRANSFER_WORDS), any(w in tb for w in TRANSFER_WORDS)
    return 2 if wa and wb else 1 if wa or wb else 0


THRESHOLD = 7


def score(o: dict, i: dict, own: list[str]) -> float:
    out_amt, in_amt = abs(o["amount"]), i["amount"]
    diff = out_amt - in_amt
    if diff < -0.005 or diff > max(0.5, out_amt * 0.02):
        return 0
    days = (_d(i["date"]) - _d(o["date"])).days
    if days < -1 or days > 7:
        return 0
    s = 3 if abs(diff) < 0.005 else 1
    s += 2 if days <= 1 else 1 if days <= 3 else 0
    s += _hint(o, i, own)
    if o["cat_kind"] == "parskaitijums" or i["cat_kind"] == "parskaitijums":
        s += 2
    for t in (o, i):     # kārtula jau atpazina pirkumu vai ienākumu (Rimi, Alga …) — maz ticams pārskaitījums
        if t["cat_kind"] in ("izdevumi", "ienakumi") and t["category_manual"] == 0:
            s -= 2
    return s


def match_transfers(con, own_names: str = "") -> int:
    own = _own_ids(con) + [w.strip().lower() for w in (own_names or "").split(",") if len(w.strip()) > 3]
    linked = _linked_ids(con)
    ignore = {(r[0], r[1]) for r in con.execute("SELECT out_tx, in_tx FROM transfer_ignore")}
    all_tx = [t for t in _txs(con) if t["id"] not in linked and not is_conversion(t["kind_raw"])
              and not (t["category_manual"] == 1 and t["cat_kind"] != "parskaitijums")]
    outs = sorted([t for t in all_tx if t["amount"] < 0], key=lambda t: (t["date"], t["id"]))
    ins = {}
    for t in all_tx:
        if t["amount"] > 0:
            ins.setdefault(ccy(t["currency"]), []).append(t)
    used = set()
    n = 0
    for o in outs:
        cands = []
        for i in ins.get(ccy(o["currency"]), []):
            if i["id"] in used or i["account_id"] == o["account_id"] or (o["id"], i["id"]) in ignore:
                continue
            sc = score(o, i, own)
            if sc >= THRESHOLD:
                cands.append((sc, -abs((_d(i["date"]) - _d(o["date"])).days), i))
        if not cands:
            continue
        cands.sort(key=lambda c: (c[0], c[1]), reverse=True)
        if len(cands) > 1 and cands[0][:2] == cands[1][:2]:
            continue            # divi vienlīdz labi kandidāti — neminam, lietotājs sasaistīs pats
        i = cands[0][2]
        _link(con, o, i, "parskaitijums")
        used.add(i["id"])
        n += 1
    con.commit()
    return n


def match_all(con, own_names: str = "") -> dict:
    c = match_conversions(con)
    r = propagate_rates(con)
    t = match_transfers(con, own_names)
    return {"conversions": c, "rates": r, "transfers": t}


# ------------------------------------------------------------------ lietotāja darbības
def unlink(con, link_id: int):
    ln = con.execute("SELECT * FROM transfer_links WHERE id=?", (link_id,)).fetchone()
    if not ln:
        return
    con.execute("INSERT OR IGNORE INTO transfer_ignore(out_tx, in_tx) VALUES (?,?)", (ln["out_tx"], ln["in_tx"]))
    con.execute("DELETE FROM transfer_links WHERE id=?", (link_id,))
    con.execute("UPDATE transactions SET category_manual=0 WHERE id IN (?,?) AND category_manual=3",
                (ln["out_tx"], ln["in_tx"]))
    if ln["kind"] == "maina":
        con.execute("UPDATE transactions SET eur_rate=NULL, rate_note=NULL WHERE id IN (?,?)", (ln["out_tx"], ln["in_tx"]))
    con.commit()
    from .store import recategorize_all
    recategorize_all(con)
    propagate_rates(con)


def link_manual(con, a: int, b: int, refund: bool = False):
    """Sasaista divus darījumus: pārskaitījums starp kontiem, valūtas maiņa vai atmaksa (pirkums + tā atmaksa,
    arī vienā kontā). Atmaksas abas puses neskaitās ne izdevumos, ne ienākumos."""
    ta, tb = _txs(con, "t.id IN (?,?)", (a, b))
    o, i = (ta, tb) if ta["amount"] < 0 else (tb, ta)
    if not (o["amount"] < 0 < i["amount"]):
        raise ValueError("Vienam darījumam jābūt izejošam, otram ienākošam")
    same_acc = o["account_id"] == i["account_id"] and ccy(o["currency"]) == ccy(i["currency"])
    linked = _linked_ids(con)
    if o["id"] in linked or i["id"] in linked:
        raise ValueError("Kāds no darījumiem jau ir sasaistīts")
    con.execute("DELETE FROM transfer_ignore WHERE out_tx=? AND in_tx=?", (o["id"], i["id"]))
    conv = ccy(o["currency"]) != ccy(i["currency"])
    kind = "maina" if conv else ("atmaksa" if same_acc or refund else "parskaitijums")
    _link(con, o, i, kind, round(i["amount"] / abs(o["amount"]), 8) if conv else None, auto=0)
    if conv:
        _conv_rates(con, o, i)
    con.commit()
    propagate_rates(con)


def pairs(con, book_id=None, date_from=None, date_to=None) -> list[dict]:
    sql = """SELECT l.id, l.kind, l.rate, l.auto,
                    o.id AS out_id, o.date AS out_date, o.amount AS out_amount, o.currency AS out_currency,
                    o.counterparty AS out_cp, o.description AS out_desc, ao.name AS out_account, ao.book_id AS out_book,
                    i.id AS in_id, i.date AS in_date, i.amount AS in_amount, i.currency AS in_currency,
                    i.counterparty AS in_cp, i.description AS in_desc, ai.name AS in_account, ai.book_id AS in_book,
                    o.rate_note AS note
             FROM transfer_links l
             JOIN transactions o ON o.id=l.out_tx JOIN accounts ao ON ao.id=o.account_id
             JOIN transactions i ON i.id=l.in_tx JOIN accounts ai ON ai.id=i.account_id WHERE 1=1"""
    p = []
    if book_id is not None:
        sql += " AND (ao.book_id=? OR ai.book_id=?)"; p += [book_id, book_id]
    if date_from:
        sql += " AND o.date >= ?"; p.append(str(date_from))
    if date_to:
        sql += " AND o.date <= ?"; p.append(str(date_to))
    return rows(con.execute(sql + " ORDER BY o.date DESC, l.id DESC", p))


def unmatched(con, book_id=None, date_from=None, date_to=None) -> list[dict]:
    """Pārskaitījumi (pēc kategorijas) bez otras puses — otrs konts nav importēts vai pāri neizdevās atrast."""
    linked = _linked_ids(con)
    where, p = "c.kind='parskaitijums'", []
    if book_id is not None:
        where += " AND a.book_id=?"; p.append(book_id)
    if date_from:
        where += " AND t.date >= ?"; p.append(str(date_from))
    if date_to:
        where += " AND t.date <= ?"; p.append(str(date_to))
    out = [t for t in _txs(con, where, p) if t["id"] not in linked]
    return sorted(out, key=lambda t: t["date"], reverse=True)


def candidates(con, tx_id: int) -> list[dict]:
    """Iespējamie pāri manuālai sasaistei: pretēja zīme. Ar tādu pašu summu — ±120 dienas (arī tajā pašā kontā:
    atmaksa), ar citu summu vai valūtu — ±10 dienas citos kontos. Vispirms līdzīgākā summa un tuvākais datums."""
    t = _txs(con, "t.id=?", (tx_id,))[0]
    linked = _linked_ids(con)
    td = _d(t["date"])
    out = []
    for c in _txs(con, "t.date BETWEEN date(?, '-120 day') AND date(?, '+120 day')", (t["date"], t["date"])):
        if c["id"] in linked or c["id"] == t["id"] or (c["amount"] > 0) == (t["amount"] > 0):
            continue
        days = abs((_d(c["date"]) - td).days)
        same_ccy = ccy(c["currency"]) == ccy(t["currency"])
        diff = abs(abs(c["amount"]) - abs(t["amount"])) / max(abs(t["amount"]), 0.01) if same_ccy else 1.0
        same_acc = c["account_id"] == t["account_id"] and same_ccy
        if diff > 0.02 and (days > 10 or same_acc):
            continue
        c["rank"] = round(diff * 10 + days / 30, 4)
        c["same_account"] = same_acc
        out.append(c)
    return sorted(out, key=lambda c: c["rank"])[:20]


def cross_book(con, book_id, date_from=None, date_to=None) -> list[dict]:
    """Nauda, kas aizgāja uz / atnāca no citas grāmatvedības (EUR, pēc darījuma kursa)."""
    if book_id is None:
        return []
    from .db import fx_map
    fx = fx_map(con)
    agg = {}
    for p in pairs(con, book_id, date_from, date_to):
        if p["kind"] != "parskaitijums" or p["out_book"] == p["in_book"]:
            continue
        if p["out_book"] == book_id:
            k, other, amt, cur = "uz", p["in_book"], abs(p["out_amount"]), p["out_currency"]
        else:
            k, other, amt, cur = "no", p["out_book"], p["in_amount"], p["in_currency"]
        rate = fx.get(cur)
        if rate is None:
            continue
        key = (k, other)
        agg[key] = agg.get(key, 0) + amt * rate
    names = {r[0]: r[1] for r in con.execute("SELECT id, name FROM books")}
    return [{"dir": k, "book_id": b, "book": names.get(b, "?"), "eur": round(v, 2)} for (k, b), v in sorted(agg.items())]
