#!/bin/bash
# Mac uzstādītājs bez Terminal: izlaiduma mapē izveido "<Nosaukums> — uzstādīt.app".
# Dubultklikšķis → tas klusi palaiž mac/install_app.sh (tā pati uzstādīšana kā Uzstadit_Mac.command), rāda
# paziņojumus macOS valodā un beigās atver programmu. Žurnāls: ~/Library/Application Support/<Slug>/install.log.
#   bash mac/make_installer_app.sh <izlaiduma mape> <Slug> "<Nosaukums>" <bundle id> [ikona.icns]
set -e
DIR="$1"; SLUG="$2"; NAME="$3"; BID="$4"; ICNS="$5"
APP="$DIR/$NAME — uzstādīt.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
[ -n "$ICNS" ] && [ -f "$DIR/$ICNS" ] && cp "$DIR/$ICNS" "$APP/Contents/Resources/AppIcon.icns"
# programma — lietotnes iekšā: macOS lejupielādētu lietotni palaiž no nejaušas vietas ("App Translocation"),
# tāpēc blakus esošās mapes tā neredz; ar iebūvētu kopiju uzstādītājs strādā vienmēr
mkdir -p "$APP/Contents/Resources/app"
( cd "$DIR" && find . -mindepth 1 -maxdepth 1 ! -name '*.app' ! -name 'Uzstadit_*.command' ! -name '*.docx' ! -name '*.bat' -exec cp -R {} "$APP/Contents/Resources/app/" \; )
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>$NAME — uzstādīt</string>
  <key>CFBundleIdentifier</key><string>$BID.installer</string>
  <key>CFBundleExecutable</key><string>install</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>LSArchitecturePriority</key><array><string>arm64</string><string>x86_64</string></array>
  <key>LSRequiresNativeExecution</key><true/>
</dict></plist>
PLIST
cat > "$APP/Contents/MacOS/install" <<SH
#!/bin/bash
# "$NAME" uzstādītājs (izveidoja mac/make_installer_app.sh)
SRC="\$(cd "\$(dirname "\$0")/../Resources/app" && pwd)"   # iebūvētā programmas kopija
LOGDIR="\$HOME/Library/Application Support/$SLUG"; mkdir -p "\$LOGDIR"; LOG="\$LOGDIR/install.log"
L=\$(defaults read -g AppleLanguages 2>/dev/null | tr -d ' "(),' | grep -m1 . | cut -c1-2)
case "\$L" in
  lv) T_START="Uzstādu — tas aizņem dažas minūtes. Kad būs gatavs, programma atvērsies pati."; T_FAIL="Uzstādīt neizdevās."; T_PY="Vajag Python 3.10 vai jaunāku. Uzstādi to no python.org (macOS 64-bit universal2) un atver šo uzstādītāju vēlreiz."; T_LOG="Sīkāk: \$LOG"; T_OPEN="Atvērt python.org"; T_OK="Labi"; T_DONE="Gatavs! $NAME ir uzstādīts mapē Programmas."; T_RUN="Atvērt $NAME";;
  de) T_START="Installiere — das dauert ein paar Minuten. Wenn alles fertig ist, öffnet sich das Programm selbst."; T_FAIL="Die Installation ist fehlgeschlagen."; T_PY="Python 3.10 oder neuer wird benötigt. Installiere es von python.org (macOS 64-bit universal2) und öffne dieses Installationsprogramm erneut."; T_LOG="Details: \$LOG"; T_OPEN="python.org öffnen"; T_OK="OK"; T_DONE="Fertig! $NAME ist im Ordner Programme installiert."; T_RUN="$NAME öffnen";;
  es) T_START="Instalando — tarda unos minutos. Cuando termine, el programa se abrirá solo."; T_FAIL="La instalación ha fallado."; T_PY="Se necesita Python 3.10 o posterior. Instálalo desde python.org (macOS 64-bit universal2) y vuelve a abrir este instalador."; T_LOG="Detalles: \$LOG"; T_OPEN="Abrir python.org"; T_OK="Aceptar"; T_DONE="¡Listo! $NAME está instalado en Aplicaciones."; T_RUN="Abrir $NAME";;
  uk) T_START="Встановлюю — це займе кілька хвилин. Коли все буде готово, програма відкриється сама."; T_FAIL="Встановити не вдалося."; T_PY="Потрібен Python 3.10 або новіший. Встанови його з python.org (macOS 64-bit universal2) і знову відкрий цей інсталятор."; T_LOG="Детальніше: \$LOG"; T_OPEN="Відкрити python.org"; T_OK="Гаразд"; T_DONE="Готово! $NAME встановлено в папку Програми."; T_RUN="Відкрити $NAME";;
  *)  T_START="Installing — this takes a few minutes. When it is done, the program opens by itself."; T_FAIL="Installation failed."; T_PY="Python 3.10 or newer is needed. Install it from python.org (macOS 64-bit universal2) and open this installer again."; T_LOG="Details: \$LOG"; T_OPEN="Open python.org"; T_OK="OK"; T_DONE="Done! $NAME is installed in Applications."; T_RUN="Open $NAME";;
esac
# redzams logs uzstādīšanas laikā (paziņojumi no neparakstītas lietotnes var netikt rādīti; lietotājs 2026-10-31)
osascript -e "display dialog \"\$T_START\" with title \"$NAME\" buttons {\"\$T_OK\"} default button 1 giving up after 900" >/dev/null 2>&1 &
WAIT=\$!
if NO_OPEN=1 bash "\$SRC/mac/install_app.sh" $SLUG "$NAME" $BID mac/$SLUG.icns > "\$LOG" 2>&1; then
  kill \$WAIT 2>/dev/null
  APPP="/Applications/$NAME.app"; [ -d "\$APPP" ] || APPP="\$HOME/Applications/$NAME.app"
  R=\$(osascript -e "button returned of (display dialog \"\$T_DONE\" with title \"$NAME\" buttons {\"\$T_OK\", \"\$T_RUN\"} default button 2)" 2>/dev/null)
  [ "\$R" = "\$T_RUN" ] && open "\$APPP"
  exit 0
fi
kill \$WAIT 2>/dev/null
if grep -q "Python 3.10+ nav atrasts" "\$LOG"; then
  R=\$(osascript -e "button returned of (display dialog \"\$T_PY\" with title \"$NAME\" buttons {\"\$T_OK\", \"\$T_OPEN\"} default button 2 with icon caution)" 2>/dev/null)
  [ "\$R" = "\$T_OPEN" ] && open "https://www.python.org/downloads/macos/"
else
  osascript -e "display dialog \"\$T_FAIL\" & return & return & \"\$T_LOG\" with title \"$NAME\" buttons {\"\$T_OK\"} default button 1 with icon stop" >/dev/null 2>&1
  open -R "\$LOG" 2>/dev/null
fi
exit 1
SH
chmod +x "$APP/Contents/MacOS/install"
echo "Mac uzstādītājs: $APP"
