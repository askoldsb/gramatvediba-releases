#!/bin/bash
# Grāmatvedība — palaišana uz Mac bez uzstādīšanas. Pirmajā reizē: labais klikšķis -> Open.
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 nav atrasts. Uzstādi to no https://www.python.org/downloads/"
  read -r -p "Spied Enter, lai aizvērtu..."
  exit 1
fi
if [ ! -x .venv/bin/python ]; then
  echo "Pirmā palaišana: sagatavoju vidi, tas aizņems minūti..."
  python3 -m venv .venv || { read -r -p "Kļūda. Spied Enter..."; exit 1; }
fi
if ! cmp -s requirements.txt .venv/req.txt; then
  echo "Uzstādu nepieciešamās bibliotēkas (pywebview)..."
  .venv/bin/python -m pip install --upgrade pip >/dev/null
  if .venv/bin/python -m pip install -r requirements.txt; then
    cp requirements.txt .venv/req.txt
  else
    echo "Neizdevās uzstādīt pywebview — programma atvērsies pārlūkā."
    sleep 3
  fi
fi
LOGDIR="$HOME/Library/Application Support/Gramatvediba"
mkdir -p "$LOGDIR"
GRAMATVEDIBA_LOG=1 nohup .venv/bin/python -u Gramatvediba.py > "$LOGDIR/log-start.txt" 2>&1 &
echo "Grāmatvedība palaista. Šo termināļa logu var aizvērt."
