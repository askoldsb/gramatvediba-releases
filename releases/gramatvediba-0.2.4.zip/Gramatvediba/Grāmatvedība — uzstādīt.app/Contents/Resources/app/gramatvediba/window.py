"""Logs: pywebview (ja uzstādīts), citādi Chrome/Edge "lietotnes" logs, citādi parasts pārlūks."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import webbrowser
from pathlib import Path

from . import NAME, SLUG, config, server


def mac_icon():
    if not config.IS_MAC:
        return
    try:
        p = Path(__file__).resolve().parent.parent / "mac" / f"{SLUG}.icns"
        from AppKit import NSApplication, NSImage   # type: ignore
        try:
            from Foundation import NSBundle          # type: ignore
            info = NSBundle.mainBundle().localizedInfoDictionary() or NSBundle.mainBundle().infoDictionary()
            if info is not None:
                info["CFBundleName"] = NAME
        except Exception:
            pass
        if p.exists():
            img = NSImage.alloc().initWithContentsOfFile_(str(p))
            if img is not None:
                NSApplication.sharedApplication().setApplicationIconImage_(img)
    except Exception as e:
        print("Dock ikona:", e)


def app_mode_browser(url: str) -> bool:
    cands = []
    if config.IS_WIN:
        for base in (os.environ.get("PROGRAMFILES(X86)", ""), os.environ.get("PROGRAMFILES", ""),
                     os.environ.get("LOCALAPPDATA", "")):
            if base:
                cands += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                          os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
    elif config.IS_MAC:
        cands += ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                  "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"]
    else:
        cands += [shutil.which(n) for n in ("google-chrome", "chromium", "chromium-browser", "microsoft-edge")]
    profile = config.app_dir() / "browser"
    for c in cands:
        if c and os.path.isfile(c):
            try:
                subprocess.Popen([c, f"--app={url}{SLUG.lower()}", f"--user-data-dir={profile}", "--start-maximized",
                                  "--no-first-run", "--no-default-browser-check"])
                return True
            except OSError:
                continue
    return False


def run(url: str, args: list[str]):
    if "--no-window" in args:
        print("adrese:", url)
        server.idle_watch(60 * 24 * 365)
        return _forever()
    if "--browser" not in args:
        try:
            import webview  # type: ignore
            mac_icon()
            webview.create_window(NAME, url, width=1360, height=880, min_size=(980, 640), maximized=True)
            webview.start()
            return server.shutdown()          # logs aizvērts
        except ImportError:
            pass
        except Exception as e:
            print("pywebview:", e)
        if app_mode_browser(url):
            server.idle_watch()
            return _forever()
    webbrowser.open(url)
    server.idle_watch()
    _forever()


def _forever():
    import time
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        server.shutdown()
        sys.exit(0)
