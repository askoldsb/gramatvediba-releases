"""Datubāzes rezerves kopijas: <datu mape>/rezerves kopijas/gramatvediba-YYYY-MM-DD_HHMMSS[-atzīme].db"""
from __future__ import annotations

import sqlite3
import time
from pathlib import Path

from . import config


def backup_dir() -> Path:
    d = config.app_dir() / "rezerves kopijas"
    d.mkdir(parents=True, exist_ok=True)
    return d


def make(con: sqlite3.Connection | None = None, tag: str = "") -> Path | None:
    src = config.db_path()
    if not src.exists():
        return None
    name = "gramatvediba-" + time.strftime("%Y-%m-%d_%H%M%S") + (f"-{tag}" if tag else "") + ".db"
    dst = backup_dir() / name
    own = con is None
    con = con or sqlite3.connect(src)
    try:
        out = sqlite3.connect(dst)
        con.backup(out)          # droša kopija arī tad, ja datubāze tiek lietota
        out.close()
    finally:
        if own:
            con.close()
    prune()
    print("rezerves kopija:", dst.name)
    return dst


def list_backups() -> list[dict]:
    return [{"name": p.name, "size": p.stat().st_size, "time": time.strftime("%Y-%m-%d %H:%M", time.localtime(p.stat().st_mtime))}
            for p in sorted(backup_dir().glob("gramatvediba-*.db"), reverse=True)]


def prune():
    keep = int(config.get("backup_keep") or 20)
    files = sorted(backup_dir().glob("gramatvediba-*.db"), reverse=True)
    for p in files[keep:]:
        try:
            p.unlink()
        except OSError:
            pass


def daily(con=None):
    """Viena automātiska kopija dienā (palaižot programmu)."""
    today = time.strftime("%Y-%m-%d")
    if not any(p.name.startswith(f"gramatvediba-{today}") for p in backup_dir().glob("*.db")):
        make(con, "dienas")


def restore(name: str) -> None:
    """Atjauno datubāzi no kopijas (pirms tam saglabā pašreizējo)."""
    src = backup_dir() / Path(name).name
    if not src.is_file():
        raise FileNotFoundError(name)
    make(tag="pirms-atjaunosanas")
    a = sqlite3.connect(src)
    b = sqlite3.connect(config.db_path())
    a.backup(b)
    a.close()
    b.close()
