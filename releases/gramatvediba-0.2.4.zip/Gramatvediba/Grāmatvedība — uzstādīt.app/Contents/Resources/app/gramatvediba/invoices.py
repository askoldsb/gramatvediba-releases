"""Rēķini: statuss, apmaksas piesaiste, automātiski ieteikumi."""
from __future__ import annotations

from datetime import date, timedelta

from .store import rows

COLS = ["direction", "counterparty", "number", "issue_date", "due_date", "amount", "currency",
        "category_id", "match_text", "note", "book_id"]


def _status(r, today: str) -> str:
    if r["left"] <= 0.005:
        return "Apmaksāts"
    overdue = bool(r["due_date"]) and r["due_date"] < today
    if r["paid"] > 0:
        return "Daļēji, kavēts" if overdue else "Daļēji apmaksāts"
    return "Kavēts" if overdue else "Neapmaksāts"


def list_invoices(con, book_id=None, today: date | None = None) -> list[dict]:
    today_s = (today or date.today()).isoformat()
    sql = """SELECT i.*, c.name AS category,
                    COALESCE((SELECT SUM(p.amount) FROM invoice_payments p WHERE p.invoice_id=i.id),0) AS paid
             FROM invoices i LEFT JOIN categories c ON c.id=i.category_id"""
    params = []
    if book_id is not None:
        sql += " WHERE i.book_id=?"; params.append(book_id)
    sql += " ORDER BY COALESCE(i.due_date, i.issue_date) DESC"
    out = rows(con.execute(sql, params))
    for r in out:
        r["left"] = round(r["amount"] - r["paid"], 2)
        r["status"] = _status(r, today_s)
    return out


def save_invoice(con, data: dict, inv_id: int | None = None) -> int:
    vals = [data.get(c) for c in COLS]
    if inv_id:
        con.execute(f"UPDATE invoices SET {','.join(c + '=?' for c in COLS)} WHERE id=?", vals + [inv_id])
    else:
        inv_id = con.execute(f"INSERT INTO invoices({','.join(COLS)}) VALUES ({','.join('?' * len(COLS))})",
                             vals).lastrowid
    con.commit()
    return inv_id


add_invoice = save_invoice


def delete_invoice(con, inv_id: int):
    con.execute("DELETE FROM invoices WHERE id=?", (inv_id,))
    con.commit()


def link_payment(con, invoice_id: int, transaction_id: int, amount: float | None = None):
    if amount is None:
        amount = abs(con.execute("SELECT amount FROM transactions WHERE id=?", (transaction_id,)).fetchone()[0])
    con.execute("INSERT OR REPLACE INTO invoice_payments(invoice_id, transaction_id, amount) VALUES (?,?,?)",
                (invoice_id, transaction_id, amount))
    con.commit()


def unlink_payment(con, invoice_id: int, transaction_id: int):
    con.execute("DELETE FROM invoice_payments WHERE invoice_id=? AND transaction_id=?", (invoice_id, transaction_id))
    con.commit()


def payments(con, invoice_id: int) -> list[dict]:
    return rows(con.execute(
        """SELECT t.id, t.date, a.name AS account, t.amount, t.counterparty, t.description, p.amount AS linked
           FROM invoice_payments p JOIN transactions t ON t.id=p.transaction_id
           JOIN accounts a ON a.id=t.account_id WHERE p.invoice_id=? ORDER BY t.date""", (invoice_id,)))


def suggest_payments(con, invoice_id: int, window_days: int = 60) -> list[dict]:
    """Darījumi tās pašas grāmatas kontos, kas varētu būt šī rēķina apmaksa."""
    inv = con.execute("SELECT * FROM invoices WHERE id=?", (invoice_id,)).fetchone()
    anchor = date.fromisoformat(inv["due_date"] or inv["issue_date"] or date.today().isoformat())
    sign = "<" if inv["direction"] == "sanemts" else ">"
    sql = f"""SELECT t.id, t.date, a.name AS account, t.amount, t.counterparty, t.description
              FROM transactions t JOIN accounts a ON a.id=t.account_id
              WHERE t.amount {sign} 0 AND t.date BETWEEN ? AND ?
                AND t.id NOT IN (SELECT transaction_id FROM invoice_payments)"""
    params = [(anchor - timedelta(days=window_days)).isoformat(), (anchor + timedelta(days=window_days)).isoformat()]
    if inv["book_id"] is not None:
        sql += " AND a.book_id=?"; params.append(inv["book_id"])
    text = (inv["match_text"] or inv["counterparty"] or "").lower()
    words = [w for w in text.replace(";", " ").split() if len(w) > 2]
    number = (inv["number"] or "").lower()
    out = []
    for r in rows(con.execute(sql, params)):
        blob = f"{r['counterparty']} {r['description']}".lower()
        s = 0.0
        if abs(abs(r["amount"]) - inv["amount"]) < 0.01:
            s += 3
        if words and any(w in blob for w in words):
            s += 2
        if number and number in blob:
            s += 4
        s -= abs((date.fromisoformat(r["date"]) - anchor).days) / 60
        if s > 1:
            r["score"] = round(s, 2)
            out.append(r)
    return sorted(out, key=lambda r: -r["score"])[:10]


def auto_link_all(con) -> int:
    """Piesaista neapmaksātiem rēķiniem darījumus ar ļoti augstu atbilstību (summa + teksts vai numurs)."""
    n = 0
    for inv in list_invoices(con):
        if inv["status"] == "Apmaksāts":
            continue
        sug = suggest_payments(con, inv["id"])
        if sug and sug[0]["score"] >= 4.5:
            link_payment(con, inv["id"], sug[0]["id"], min(abs(sug[0]["amount"]), inv["left"]))
            n += 1
    return n
