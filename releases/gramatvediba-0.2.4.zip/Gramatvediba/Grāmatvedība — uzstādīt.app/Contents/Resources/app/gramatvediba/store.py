"""Datu ielāde datubāzē, kategorizēšana, atlikumi, kopsavilkumi."""
from __future__ import annotations

import re
import sqlite3
from collections import defaultdict

from .db import book_filter, fx_map, get_or_create_account
from .importers import ParseResult, Tx, tx_hash

UNCAT = "— bez kategorijas —"


def rows(cur) -> list[dict]:
    return [dict(r) for r in cur.fetchall()]


# ------------------------------------------------------------------ kategorizēšana
def load_rules(con):
    rs = con.execute(
        "SELECT pattern, category_id, direction FROM rules ORDER BY priority, length(pattern) DESC").fetchall()
    return [(re.compile(r"(?<!\w)" + re.escape(r["pattern"].lower())), r["category_id"], r["direction"] or "abi")
            for r in rs]


def categorize_text(rules, text: str, amount: float = 0.0):
    t = (text or "").lower()
    for rx, cid, direction in rules:
        if direction == "ienakums" and amount <= 0 or direction == "izdevums" and amount >= 0:
            continue
        if rx.search(t):
            return cid
    return None


def category_ids(con) -> dict:
    return {r["name"]: r["id"] for r in con.execute("SELECT id, name FROM categories")}


def pick_category(rules, cats, tx: Tx):
    if tx.hint_category and tx.hint_category in cats:
        return cats[tx.hint_category]
    return categorize_text(rules, f"{tx.counterparty} {tx.description}", tx.amount)


def recategorize_all(con) -> int:
    """Pārkategorizē darījumus, kam kategoriju nav likusi ne pati banka, ne lietotājs (category_manual=0)."""
    rules = load_rules(con)
    n = 0
    for r in con.execute("SELECT id, counterparty, description, amount, category_id FROM transactions "
                         "WHERE category_manual=0").fetchall():
        cid = categorize_text(rules, f"{r['counterparty']} {r['description']}", r["amount"])
        if cid != r["category_id"]:
            con.execute("UPDATE transactions SET category_id=? WHERE id=?", (cid, r["id"]))
            n += 1
    con.commit()
    return n


# ------------------------------------------------------------------ imports
def store_result(con: sqlite3.Connection, res: ParseResult, filename: str = "", book_id=None) -> dict:
    import_id = con.execute("INSERT INTO imports(filename, source) VALUES (?,?)", (filename, res.source)).lastrowid
    rules = load_rules(con)
    cats = category_ids(con)
    acc_ids, new, dup = {}, 0, 0
    if res.source == "nexo":
        # agrākās versijas Nexo failu ielasīja citādi (EUR/EURX/USD konti) — tos pašus darījumus aizstājam
        ids = {t.external_id.split(":")[0] for t in res.txs} | set(res.seen_ids)
        fresh = {tx_hash(t) for t in res.txs}          # tieši tādi paši ieraksti paliek (ar tavām kategorijām)
        old = [r["id"] for r in con.execute(
            "SELECT t.id, t.external_id, t.hash FROM transactions t JOIN accounts a ON a.id=t.account_id "
            "WHERE a.source='nexo' AND t.kind_raw <> 'manual'").fetchall()
            if (r["external_id"] or "").split(":")[0] in ids and r["hash"] not in fresh]
        for i in old:
            con.execute("DELETE FROM transactions WHERE id=?", (i,))
        con.execute("DELETE FROM accounts WHERE source='nexo' AND id NOT IN (SELECT account_id FROM transactions) "
                    "AND id NOT IN (SELECT account_id FROM balances)")
    # iepriekšējie gaidošie darījumi šiem kontiem — tos aizstāj šī faila dati (apstiprināti vai joprojām gaidoši)
    for name in {t.account for t in res.txs}:
        row = con.execute("SELECT id FROM accounts WHERE name=?", (name,)).fetchone()
        if row:
            con.execute("DELETE FROM transactions WHERE account_id=? AND pending=1", (row["id"],))
    for tx in res.txs:
        if tx.account not in acc_ids:
            acc_ids[tx.account] = get_or_create_account(con, tx.account, res.source, tx.currency, book_id=book_id)
        # 2 = kategoriju noteica pats avots (piem. Revolut TOPUP) – kārtulas to nepārraksta
        from_source = 2 if tx.hint_category in cats else 0
        try:
            con.execute(
                """INSERT INTO transactions(account_id, date, amount, currency, counterparty, description, kind_raw,
                   external_id, category_id, category_manual, hash, import_id, ref, pending)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (acc_ids[tx.account], tx.date, round(tx.amount, 8), tx.currency, tx.counterparty, tx.description,
                 tx.kind_raw, tx.external_id, pick_category(rules, cats, tx), from_source, tx_hash(tx), import_id,
                 tx.ref or None, int(tx.pending)))
            new += 1
        except sqlite3.IntegrityError:
            dup += 1
            if tx.ref:      # 0.1.x importos atsauces nebija — atkārtots imports tās papildina
                con.execute("UPDATE transactions SET ref=? WHERE hash=? AND ref IS NULL", (tx.ref, tx_hash(tx)))
    for b in res.balances:
        aid = acc_ids.get(b.account) or get_or_create_account(con, b.account, res.source, b.currency, book_id=book_id)
        con.execute("INSERT OR REPLACE INTO balances(account_id, date, balance, kind) VALUES (?,?,?,?)",
                    (aid, b.date, b.balance, b.kind))
    con.execute("UPDATE imports SET rows_new=?, rows_dup=? WHERE id=?", (new, dup, import_id))
    con.commit()
    return {"source": res.source, "new": new, "dup": dup, "skipped": res.skipped,
            "warnings": res.warnings[:20], "accounts": sorted(acc_ids)}


def delete_import(con, import_id: int):
    con.execute("DELETE FROM transactions WHERE import_id=?", (import_id,))
    con.execute("DELETE FROM imports WHERE id=?", (import_id,))
    con.commit()


def imports(con) -> list[dict]:
    return rows(con.execute("SELECT id, imported_at, filename, source, rows_new, rows_dup FROM imports ORDER BY id DESC"))


# ------------------------------------------------------------------ vaicājumi
def transactions(con, date_from=None, date_to=None, book_id=None, account_id=None, category=None, q=None,
                 direction=None) -> list[dict]:
    sql = """SELECT t.id, t.date, a.name AS account, a.id AS account_id, a.book_id, t.amount, t.currency,
                    t.counterparty, t.description, t.kind_raw, t.category_id, c.name AS category, c.kind AS cat_kind,
                    t.category_manual, t.note, t.eur_rate, t.rate_note, t.pending,
                    (SELECT l.id FROM transfer_links l WHERE l.out_tx=t.id OR l.in_tx=t.id) AS link_id,
                    (SELECT l.kind FROM transfer_links l WHERE l.out_tx=t.id OR l.in_tx=t.id) AS link_kind,
                    (SELECT a2.name || ' · ' || t2.date FROM transfer_links l
                       JOIN transactions t2 ON t2.id = CASE WHEN l.out_tx=t.id THEN l.in_tx ELSE l.out_tx END
                       JOIN accounts a2 ON a2.id=t2.account_id WHERE l.out_tx=t.id OR l.in_tx=t.id) AS link_other
             FROM transactions t JOIN accounts a ON a.id=t.account_id
             LEFT JOIN categories c ON c.id=t.category_id WHERE 1=1"""
    bf, params = book_filter(book_id)
    sql += bf
    if date_from:
        sql += " AND t.date >= ?"; params.append(str(date_from))
    if date_to:
        sql += " AND t.date <= ?"; params.append(str(date_to))
    if account_id:
        sql += " AND a.id = ?"; params.append(int(account_id))
    if category == "none":
        sql += " AND t.category_id IS NULL"
    elif category:
        sql += " AND t.category_id = ?"; params.append(int(category))
    if q:
        sql += " AND lower(coalesce(t.counterparty,'') || ' ' || coalesce(t.description,'') || ' ' || " \
               "coalesce(t.note,'')) LIKE ?"
        params.append(f"%{q.lower()}%")
    if direction == "in":
        sql += " AND t.amount > 0"
    elif direction == "out":
        sql += " AND t.amount < 0"
    sql += " ORDER BY t.date DESC, t.id DESC"
    out = rows(con.execute(sql, params))
    fx = fx_map(con)
    for r in out:
        rate = r["eur_rate"] if r["eur_rate"] is not None else fx.get(r["currency"])
        r["eur"] = round(r["amount"] * rate, 2) if rate is not None else None
        if r["rate_note"]:
            r["rate_note"] = r["rate_note"].removeprefix("auto:")
    return out


def account_balances(con, book_id=None) -> list[dict]:
    """Atlikums = pēdējais zināmais atlikums no izraksta (vai manuāla korekcija) + darījumi pēc tā datuma.
    Ja atlikuma nav (Nexo), atlikums = visu darījumu summa."""
    fx = fx_map(con)
    out = []
    bf, bp = book_filter(book_id)
    for a in con.execute(f"SELECT * FROM accounts a WHERE active=1{bf} ORDER BY book_id, source, name", bp).fetchall():
        snap = con.execute(
            """SELECT date, balance FROM balances WHERE account_id=? ORDER BY date DESC,
               CASE kind WHEN 'manuals' THEN 0 WHEN 'beigu' THEN 1 ELSE 2 END LIMIT 1""", (a["id"],)).fetchone()
        last_tx = con.execute("SELECT MAX(date) FROM transactions WHERE account_id=?", (a["id"],)).fetchone()[0]
        pend = con.execute("SELECT COALESCE(SUM(amount),0), COUNT(*) FROM transactions WHERE account_id=? AND pending=1",
                           (a["id"],)).fetchone()
        if snap:
            after = con.execute("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE account_id=? AND date > ? "
                                "AND pending=0", (a["id"], snap["date"])).fetchone()[0]
            bal, basis = snap["balance"] + after + pend[0], f"izraksts {snap['date']}"
            if pend[1]:
                basis += f", t.sk. gaidoši {pend[1]} ({round(pend[0], 2)})"
        else:
            bal = con.execute("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE account_id=?",
                              (a["id"],)).fetchone()[0]
            basis = "darījumu summa"
        rate = fx.get(a["currency"])
        out.append({"id": a["id"], "name": a["name"], "source": a["source"], "currency": a["currency"],
                    "book_id": a["book_id"], "balance": round(bal, 8),
                    "eur": round(bal * rate, 2) if rate is not None else None,
                    "last_tx": last_tx, "basis": basis})
    return out


def missing_fx(con, book_id=None) -> list[str]:
    fx = fx_map(con)
    bf, bp = book_filter(book_id)
    return sorted(r[0] for r in con.execute(f"SELECT DISTINCT currency FROM accounts a WHERE 1=1{bf}", bp)
                  if r[0] not in fx)


def _counted(t):
    return t["cat_kind"] != "parskaitijums" and t["eur"] is not None


def monthly_summary(txs: list[dict]) -> list[dict]:
    """Ienākumi/izdevumi pa mēnešiem EUR, bez pārskaitījumiem starp saviem kontiem."""
    m = defaultdict(lambda: [0.0, 0.0])
    for t in txs:
        if not _counted(t):
            continue
        k = t["date"][:7]
        if t["eur"] > 0:
            m[k][0] += t["eur"]
        else:
            m[k][1] -= t["eur"]
    return [{"month": k, "income": round(i, 2), "expense": round(e, 2), "diff": round(i - e, 2)}
            for k, (i, e) in sorted(m.items())]


def category_summary(txs: list[dict], income: bool = False) -> list[dict]:
    s = defaultdict(float)
    for t in txs:
        if _counted(t) and (t["eur"] > 0 if income else t["eur"] < 0):
            s[t["category"] or UNCAT] += abs(t["eur"])
    return [{"category": k, "total": round(v, 2)} for k, v in sorted(s.items(), key=lambda x: -x[1])]


def transfers_total(txs: list[dict]) -> dict:
    inn = sum(t["eur"] for t in txs if t["cat_kind"] == "parskaitijums" and t["eur"] and t["eur"] > 0)
    out = -sum(t["eur"] for t in txs if t["cat_kind"] == "parskaitijums" and t["eur"] and t["eur"] < 0)
    return {"in": round(inn, 2), "out": round(out, 2)}
