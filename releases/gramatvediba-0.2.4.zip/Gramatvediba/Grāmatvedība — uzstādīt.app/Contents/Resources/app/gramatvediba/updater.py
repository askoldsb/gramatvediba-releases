"""Automātiska atjaunināšana no publiskā izlaidumu repozitorija.

manifests: https://raw.githubusercontent.com/askoldsb/gramatvediba-releases/main/latest.json
           (atsevišķs publisks repozitorijs tikai Grāmatvedībai: latest.json, releases/*.zip, installers/)
           {"stable": {...}, "test": {...}, "history": [...]}, katrs {version, url, sha256, size, date, notes: {lv}}

Uzstāda tikai pēc lietotāja apstiprinājuma: lejupielāde → SHA-256 → datu rezerves kopija → iepriekšējā versija uz
<datu mape>/updates/previous/ → jaunie faili pāri programmas mapei (.venv un datu mape netiek aiztikti) →
programma palaiž sevi no jauna. Kods privātajā repozitorijā; programma lasa tikai publisko manifestu (bez atslēgām).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import ssl
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

from . import SLUG, VERSION, backup, config

RELEASES_REPO = "askoldsb/gramatvediba-releases"
MOD = "gramatvediba"
MANIFEST_URL = f"https://raw.githubusercontent.com/{RELEASES_REPO}/main/latest.json"
API_URL = f"https://api.github.com/repos/{RELEASES_REPO}/contents/latest.json?ref=main"
CHECK_EVERY_S = 6 * 3600
KEEP = {".venv", "__pycache__", ".git", ".python"}

state = {"status": "idle", "msg": "", "pct": 0, "last": None, "checked_at": 0.0}
_lock = threading.Lock()


def parse_version(v: str) -> tuple:
    """'0.3.0' > '0.3.0-test10' > '0.3.0-test9' > '0.2.1'."""
    m = re.match(r"^\s*v?(\d+)\.(\d+)\.(\d+)(?:-([A-Za-z]+)(\d*))?", str(v or ""))
    if not m:
        return (0, 0, 0, 0, 0)
    a, b, c = int(m.group(1)), int(m.group(2)), int(m.group(3))
    return (a, b, c, 1, 0) if m.group(4) is None else (a, b, c, 0, int(m.group(5) or 0))


def is_test(v: str) -> bool:
    return "-" in str(v or "")


def channel() -> str:
    ch = config.get("update_channel") or "auto"
    if ch == "auto":
        return "test" if is_test(VERSION) else "stable"
    return ch if ch in ("stable", "test", "off") else "stable"


def program_dir() -> Path:
    return Path(__file__).resolve().parent.parent


def can_install() -> tuple[bool, str]:
    root = program_dir()
    if (root / ".git").exists():
        return False, "dev"              # izstrādes kopija (git) — atjauno ar git pull
    if not os.access(root, os.W_OK):
        return False, "readonly"
    return True, ""


def updates_dir() -> Path:
    d = config.app_dir() / "updates"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _ssl_ctx():
    """python.org Python uz Mac nezina sistēmas sertifikātus — tad lietojam /etc/ssl/cert.pem."""
    ctx = ssl.create_default_context()
    if not ctx.get_ca_certs() and os.path.exists("/etc/ssl/cert.pem"):
        ctx = ssl.create_default_context(cafile="/etc/ssl/cert.pem")
    return ctx


def _get(url: str, timeout: int = 20, accept: str | None = None) -> bytes:
    h = {"User-Agent": f"{SLUG}/{VERSION}", "Cache-Control": "no-cache"}
    if accept:
        h["Accept"] = accept
    with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout, context=_ssl_ctx()) as r:
        return r.read()


def check(force: bool = False) -> dict:
    ch = channel()
    out = {"current": VERSION, "channel": ch, "available": False, "latest": None, "error": "",
           "can_install": can_install()[0], "why": can_install()[1]}
    if ch == "off" and not force:
        return out
    with _lock:
        if not force and state["last"] is not None and time.time() - state["checked_at"] < CHECK_EVERY_S:
            man = state["last"]
        else:
            try:
                man = None
                if os.environ.get("GRAMATVEDIBA_UPDATE_MANIFEST"):
                    man = json.loads(_get(os.environ["GRAMATVEDIBA_UPDATE_MANIFEST"]).decode("utf-8"))
                elif force:   # raw.githubusercontent.com kešo ~5 min — API atdod jaunāko uzreiz
                    try:
                        man = json.loads(_get(API_URL, accept="application/vnd.github.raw").decode("utf-8"))
                    except Exception as e:
                        print("atjauninājumi: API:", str(e)[:120])
                if man is None:
                    man = json.loads(_get(f"{MANIFEST_URL}?t={int(time.time())}").decode("utf-8"))
            except Exception as e:
                out["error"] = "Atjauninājumi vēl nav publicēti" if "404" in str(e) else str(e)[:200]
                print("atjauninājumi:", str(e)[:200])
                return out
            state["last"], state["checked_at"] = man, time.time()
    cands = [man.get("stable")] + ([man.get("test")] if ch == "test" else [])
    cands = [c for c in cands if isinstance(c, dict) and c.get("version") and c.get("url") and c.get("sha256")]
    if cands:
        best = max(cands, key=lambda c: parse_version(c["version"]))
        out["latest"] = best
        out["available"] = parse_version(best["version"]) > parse_version(VERSION)
    return out


def whats_new() -> dict:
    """Izmaiņas kopš pēdējās redzētās versijas (arī vairākas izlaistas)."""
    seen = config.get("seen_version") or ""
    if not seen:
        config.update({"seen_version": VERSION})
        return {"show": False}
    if parse_version(VERSION) <= parse_version(seen):
        if seen != VERSION:
            config.update({"seen_version": VERSION})
        return {"show": False}
    entries = {}
    man = state["last"]
    if man is None:
        try:
            check()
            man = state["last"]
        except Exception:
            man = None
    for e in (list((man or {}).get("history") or []) + [(man or {}).get("test"), (man or {}).get("stable")]):
        if isinstance(e, dict) and e.get("version") and e["version"] not in entries:
            if parse_version(seen) < parse_version(e["version"]) <= parse_version(VERSION):
                entries[e["version"]] = {"version": e["version"], "date": e.get("date", ""), "notes": e.get("notes") or {}}
    out = sorted(entries.values(), key=lambda e: parse_version(e["version"]), reverse=True)
    return {"show": True, "from": seen, "to": VERSION, "entries": out}


def mark_seen():
    config.update({"seen_version": VERSION})


def install(info: dict | None = None) -> dict:
    ok, why = can_install()
    if not ok:
        return {"ok": False, "error": why}
    if state["status"] in ("download", "install", "restart"):
        return {"ok": True}
    if not info:
        c = check(force=True)
        if not c["available"]:
            return {"ok": False, "error": c["error"] or "no_update"}
        info = c["latest"]
    state.update(status="download", msg="", pct=0)
    threading.Thread(target=_install, args=(dict(info),), daemon=True).start()
    return {"ok": True}


def _download(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": f"{SLUG}/{VERSION}"})
    with urllib.request.urlopen(req, timeout=60, context=_ssl_ctx()) as r:
        total = int(r.headers.get("Content-Length") or 0)
        buf = bytearray()
        while True:
            chunk = r.read(65536)
            if not chunk:
                break
            buf += chunk
            if total:
                state["pct"] = int(len(buf) * 100 / total)
    return bytes(buf)


def _install(info: dict):
    try:
        ver = info["version"]
        up = updates_dir()
        data = _download(info["url"])
        if hashlib.sha256(data).hexdigest().lower() != str(info["sha256"]).lower():
            raise RuntimeError("sha256 nesakrīt")
        zpath = up / f"{MOD}-{ver}.zip"
        zpath.write_bytes(data)
        state.update(status="install", pct=100)
        tmp = up / "new"
        shutil.rmtree(tmp, ignore_errors=True)
        with zipfile.ZipFile(zpath) as z:
            for n in z.namelist():
                if n.startswith("/") or ".." in Path(n).parts:
                    raise RuntimeError("zip")
            z.extractall(tmp)
        src = next((p.parent for p in tmp.rglob(f"{SLUG}.py") if (p.parent / "gramatvediba").is_dir()), None)
        if not src:
            raise RuntimeError("zip saturs")
        try:
            backup.make(tag="pirms-atjauninasanas")
        except Exception as e:
            print("atjauninājumi: rezerves kopija:", e)
        root = program_dir()
        prev = up / "previous"
        shutil.rmtree(prev, ignore_errors=True)
        _copy_tree(root, prev)
        _copy_tree(src, root)
        shutil.rmtree(tmp, ignore_errors=True)
        zpath.unlink(missing_ok=True)
        print(f"atjauninājumi: {ver} uzstādīta, palaižu no jauna")
        state.update(status="restart", msg=ver)
        threading.Thread(target=_restart, daemon=True).start()
    except Exception as e:
        print("atjauninājumi: kļūda:", e)
        state.update(status="error", msg=str(e)[:200])


def _copy_tree(src: Path, dst: Path):
    for p in src.rglob("*"):
        rel = p.relative_to(src)
        if rel.parts and (rel.parts[0] in KEEP or rel.parts[0].endswith(".app")) or "__pycache__" in rel.parts:
            continue
        t = dst / rel
        if p.is_dir():
            t.mkdir(parents=True, exist_ok=True)
            continue
        t.parent.mkdir(parents=True, exist_ok=True)
        if t.exists() and not os.access(t, os.W_OK):
            try:
                os.chmod(t, 0o644)
            except OSError:
                t.unlink()
        shutil.copy2(p, t)
        try:
            os.chmod(t, (os.stat(t).st_mode | 0o200) & 0o7777)
        except OSError:
            pass


def _restart():
    time.sleep(1.0)
    root = program_dir()
    env = dict(os.environ, GRAMATVEDIBA_RESTARTED="1")
    try:
        app = next((q for q in root.parents if q.suffix == ".app"), None)
        if config.IS_WIN:
            subprocess.Popen(["cmd", "/c", "start", "", "/min", str(root / "run_windows.bat")], cwd=str(root), env=env,
                             creationflags=0x00000008 | 0x00000200)
        elif config.IS_MAC and app:
            subprocess.Popen(["/usr/bin/open", "-n", str(app)], env=env, stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        elif config.IS_MAC:
            subprocess.Popen(["/bin/bash", str(root / "run_mac.command")], cwd=str(root), env=env,
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        else:
            subprocess.Popen([sys.executable, str(root / f"{SLUG}.py")], cwd=str(root), env=env, start_new_session=True)
    except Exception as e:
        print("atjauninājumi: palaišana neizdevās:", e)
        state.update(status="error", msg="restart: " + str(e)[:150])
        return
    time.sleep(90)          # ja jaunā instance mūs neapturēja — beidzam paši
    os._exit(0)


def status() -> dict:
    return {"status": state["status"], "msg": state["msg"], "pct": state["pct"]}
