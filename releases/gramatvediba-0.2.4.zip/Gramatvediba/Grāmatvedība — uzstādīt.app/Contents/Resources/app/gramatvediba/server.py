"""Lokālais serveris 127.0.0.1 (ThreadingHTTPServer): web/ faili + POST /api/<nosaukums> ar galveni X-Token."""
from __future__ import annotations

import json
import mimetypes
import os
import secrets
import threading
import time
import traceback
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import PORTS, SLUG, VERSION, api, config

WEB = Path(__file__).resolve().parent.parent / "web"
TOKEN = secrets.token_urlsafe(24)
state = {"last_ping": time.time(), "server": None, "window": False}
_db_lock = threading.Lock()
MAX_BODY = 60 * 1024 * 1024


class Handler(BaseHTTPRequestHandler):
    server_version = f"{SLUG}/{VERSION}"

    def log_message(self, fmt, *args):      # bez katra pieprasījuma žurnālā
        pass

    def _send(self, code, body: bytes, ctype="application/json; charset=utf-8", extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path in ("/", "/index.html", f"/{SLUG.lower()}"):
            html = (WEB / "index.html").read_text(encoding="utf-8")
            html = html.replace("__TOKEN__", TOKEN).replace("__VERSION__", VERSION)
            return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8",
                              {"Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; "
                                                          "script-src 'self' 'unsafe-inline'; img-src 'self' data:"})
        f = (WEB / path.lstrip("/")).resolve()
        if not str(f).startswith(str(WEB.resolve())) or not f.is_file():
            return self._send(404, b"{}")
        ctype = mimetypes.guess_type(str(f))[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype.endswith("javascript"):
            ctype += "; charset=utf-8"
        self._send(200, f.read_bytes(), ctype)

    def do_POST(self):
        if not self.path.startswith("/api/"):
            return self._send(404, b"{}")
        if self.headers.get("X-Token") != TOKEN:
            return self._send(403, json.dumps({"ok": False, "error": "token"}).encode())
        name = self.path[5:].split("?", 1)[0]
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            return self._send(413, json.dumps({"ok": False, "error": "Fails ir pārāk liels"}).encode())
        try:
            data = json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            return self._send(400, json.dumps({"ok": False, "error": "json"}).encode())
        state["last_ping"] = time.time()
        if name == "ping":
            return self._send(200, b'{"ok": true}')
        if name == "quit":
            self._send(200, b'{"ok": true}')
            threading.Thread(target=shutdown, daemon=True).start()
            return
        fn = api.handlers().get(name)
        if not fn:
            return self._send(404, json.dumps({"ok": False, "error": f"nav API {name}"}).encode())
        try:
            with _db_lock:
                out = fn(data) or {}
            out = {"ok": True, **out}
            code = 200
        except (ValueError, KeyError, FileNotFoundError) as e:
            out, code = {"ok": False, "error": str(e.args[0] if e.args else e)}, 200
        except Exception as e:  # noqa
            traceback.print_exc()
            out, code = {"ok": False, "error": f"{type(e).__name__}: {e}"}, 200
        self._send(code, json.dumps(out, ensure_ascii=False, default=str).encode("utf-8"))


# ------------------------------------------------------------------ vecā instance
def _info_file() -> Path:
    return config.app_dir() / "server.json"


def stop_previous() -> bool:
    """Ja programma jau darbojas (piem. vecā versija pirms atjaunināšanas) — palūdzam tai beigt darbu."""
    try:
        info = json.loads(_info_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{info['port']}/api/quit", data=b"{}", method="POST",
                                     headers={"X-Token": info["token"], "Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=3).read()
    except Exception:
        return False
    for _ in range(30):              # gaidām, kamēr ports atbrīvojas
        time.sleep(0.2)
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{info['port']}/", timeout=0.5)
        except Exception:
            break
    print("vecā instance apturēta")
    return True


def start(port: int = 0, db_path=None) -> tuple[ThreadingHTTPServer, str]:
    stop_previous()
    api.setup(db_path)
    srv = None
    for p in ([port] if port else list(PORTS) + [0]):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", p), Handler)
            break
        except OSError:
            continue
    if srv is None:
        raise RuntimeError("Nav brīva porta")
    srv.daemon_threads = True
    state["server"] = srv
    port = srv.server_address[1]
    try:
        _info_file().write_text(json.dumps({"port": port, "token": TOKEN, "pid": os.getpid(), "version": VERSION}),
                                encoding="utf-8")
    except OSError:
        pass
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{port}/"


def shutdown():
    time.sleep(0.2)
    try:
        if api.con:
            with _db_lock:
                api.con.close()
    except Exception:
        pass
    try:
        info = json.loads(_info_file().read_text(encoding="utf-8"))
        if info.get("pid") == os.getpid():
            _info_file().unlink()
    except Exception:
        pass
    print("darbs beigts")
    os._exit(0)


def idle_watch(minutes: int = 5):
    """Pārlūka režīmā: ja lapa ilgi nesūta 'ping' (logs aizvērts) — beidzam darbu."""
    def loop():
        last_check = time.time()
        while True:
            time.sleep(20)
            now = time.time()
            if now - last_check > 120:      # dators bija aizmidzis — skaitām no jauna
                state["last_ping"] = now
            last_check = now
            if now - state["last_ping"] > minutes * 60:
                print("logs aizvērts — beidzu darbu")
                shutdown()
    threading.Thread(target=loop, daemon=True).start()
