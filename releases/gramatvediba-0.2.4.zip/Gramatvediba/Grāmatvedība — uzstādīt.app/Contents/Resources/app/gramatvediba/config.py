"""Datu mape, iestatījumi (settings.json) un žurnāls (log.txt ar log-1…log-3)."""
from __future__ import annotations

import json
import os
import sys
import threading
import time
from pathlib import Path

from . import SLUG

IS_WIN = sys.platform.startswith("win")
IS_MAC = sys.platform == "darwin"

DEFAULTS = {
    "update_channel": "auto",     # auto | stable | test | off
    "seen_version": "",
    "book": 0,                    # 0 = visas kopā, citādi grāmatas id
    "backup_keep": 20,
    "own_names": "",              # tavs vārds/uzvārds (ar komatu) — pārskaitījumiem starp saviem kontiem
}


def app_dir() -> Path:
    if os.environ.get("GRAMATVEDIBA_DATA"):
        d = Path(os.environ["GRAMATVEDIBA_DATA"])
    elif IS_WIN:
        d = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming") / SLUG
    elif IS_MAC:
        d = Path.home() / "Library" / "Application Support" / SLUG
    else:
        d = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / SLUG.lower()
    d.mkdir(parents=True, exist_ok=True)
    return d


def db_path() -> Path:
    return app_dir() / "gramatvediba.db"


_lock = threading.Lock()


def load() -> dict:
    d = dict(DEFAULTS)
    try:
        d.update(json.loads((app_dir() / "settings.json").read_text(encoding="utf-8")))
    except (OSError, ValueError):
        pass
    return d


def get(key):
    return load().get(key, DEFAULTS.get(key))


def update(values: dict) -> dict:
    with _lock:
        d = load()
        d.update({k: v for k, v in values.items() if k in DEFAULTS})
        p = app_dir() / "settings.json"
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, p)
        return d


# ------------------------------------------------------------------ žurnāls
class LogFile:
    """log.txt: katra rinda ar laiku, vienādas rindas pēc kārtas saspiež, ~2 MB robeža."""
    MAX = 2 * 1024 * 1024

    def __init__(self, path: Path):
        self.path = path
        self.fh = open(path, "a", encoding="utf-8", buffering=1)
        self.last = None
        self.repeat = 0
        self.buf = ""
        self.lock = threading.Lock()

    def write(self, s):
        with self.lock:
            self.buf += s
            while "\n" in self.buf:
                line, self.buf = self.buf.split("\n", 1)
                self._line(line)
        return len(s)

    def _line(self, line):
        if line == self.last:
            self.repeat += 1
            return
        if self.repeat:
            self.fh.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} ↑ atkārtojās vēl {self.repeat} reizes\n")
            self.repeat = 0
        self.last = line
        self.fh.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {line}\n")
        if self.fh.tell() > self.MAX:
            self.fh.close()
            rotate(self.path)
            self.fh = open(self.path, "a", encoding="utf-8", buffering=1)

    def flush(self):
        try:
            self.fh.flush()
        except Exception:
            pass


def rotate(path: Path, keep: int = 3):
    for i in range(keep, 0, -1):
        src = path if i == 1 else path.with_name(f"log-{i-1}.txt")
        dst = path.with_name(f"log-{i}.txt")
        if src.exists():
            try:
                os.replace(src, dst)
            except OSError:
                pass


def setup_log(rotate_now: bool = True):
    p = app_dir() / "log.txt"
    if rotate_now:
        rotate(p)
    lf = LogFile(p)
    sys.stdout = lf
    sys.stderr = lf
