# Grāmatvedība

Privāta personīgo finanšu uzskaite: ienākumi, izdevumi, atlikumi, rēķini un saistības (līzingi, nomaksas,
uzturlīdzekļi). Ir divas atsevišķas grāmatvedības, **Darbs** (Swedbank) un **Fotobanks** (PayPal, Revolut, Nexo),
un skats "Visas kopā". Programma darbojas tikai tavā datorā.

## Uzstādīšana uz Mac

1. Vajag **Python 3.10+** no https://www.python.org/downloads/ (macOS 64-bit universal2).
2. Atarhivē `gramatvediba-X.Y.Z.zip` un dubultklikšķini uz **„Grāmatvedība — uzstādīt.app”**.
   Ja macOS to bloķē: System Settings → Privacy & Security → **Open Anyway** (vai labais klikšķis → Open).
3. Programma tiek uzstādīta mapē **Programmas** (`/Applications/Grāmatvedība.app`) un atveras pati.
   Atarhivēto mapi pēc tam var izdzēst.

Ja ar `.app` neizdodas, izmanto rezerves variantu `Uzstadit_Mac.command` (tas pats, tikai terminālī).

## Atjaunināšana

Programma reizi 6 stundās pārbauda, vai ir jaunāka versija. Ja ir, augšā parādās josla **„Pieejama versija X —
Uzstādīt”**. Uzstāda tikai pēc tava klikšķa: pirms tam tiek saglabāta datu rezerves kopija, un pēc atjaunināšanas
programma palaižas no jauna. Kanālu (gatavās versijas vai arī testa versijas) var izvēlēties sadaļā
Iestatījumi → Atjauninājumi.

## Kur glabājas dati

`~/Library/Application Support/Gramatvediba/` (Windows: `%APPDATA%\Gramatvediba`):
- `gramatvediba.db`: visi dati;
- `rezerves kopijas/`: automātiska kopija katru dienu un pirms katras atjaunināšanas (paturēt 20);
- `log.txt`: žurnāls.

Atjaunināšana un pārinstalēšana datus neaiztiek.

## Lietošana īsumā

1. **📥 Imports:** ievelc CSV failus. Formātu programma atpazīst pati, un dublikātus izlaiž.
2. **⚙️ Iestatījumi → Valūtu kursi:** USD, BTC u.c. kurss eiro.
3. **💳 Darījumi:** pārbaudi kategorijas. Ar ⚙ pogu var izveidot kārtulu, piemēram, "shutterstock" →
   Fotobanks: Shutterstock.
4. **📅 Saistības:** līzingi, nomaksas, uzturlīdzekļi. "Atpazīšanas teksts" ļauj programmai pašai atrast
   samaksātos maksājumus.
5. **🧾 Rēķini:** saņemtie un izrakstītie rēķini ar apmaksas piesaisti.

Pārskaitījumi starp saviem kontiem (Swedbank → Revolut, PayPal → banka, Nexo iemaksas) netiek skaitīti
ne ienākumos, ne izdevumos.

## Izstrāde

```
python3 Gramatvediba.py --browser          # palaist no koda (bez uzstādīšanas)
python3 -m tests.test_core                 # loģika
python3 -m tests.e2e                       # visa saskarne pārlūkā (vajag playwright + Chrome)
python3 -m tests.test_update               # atjaunināšana
bash dev/build_release.sh                  # → dist/gramatvediba-X.Y.Z.zip
bash dev/publish_release.sh 0.1.1 test dev/notes-0.1.1.md   # publicēt atjauninājumu
```
