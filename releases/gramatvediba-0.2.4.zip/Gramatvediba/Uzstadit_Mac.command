#!/bin/bash
# Grāmatvedība — uzstādīšana uz Mac kā parasta lietotne (vienreiz).
# Vienkāršāk: dubultklikšķis uz "Grāmatvedība — uzstādīt.app" (bez termināļa).
# Ja macOS šo failu bloķē: System Settings → Privacy & Security → "Open Anyway" (vai labais klikšķis → Open).
cd "$(dirname "$0")" || exit 1
bash mac/install_app.sh Gramatvediba "Grāmatvedība" com.fotostockworkshop.gramatvediba mac/Gramatvediba.icns
echo
read -r -p "Spied Enter, lai aizvērtu šo logu..."
