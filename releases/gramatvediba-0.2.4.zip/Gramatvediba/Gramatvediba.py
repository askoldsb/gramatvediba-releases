#!/usr/bin/env python3
"""Grāmatvedība — palaišana.

Atver programmu savā logā (pywebview), citādi Chrome/Edge "lietotnes" logā vai parastā pārlūkā.
  --browser    atvērt parastā pārlūkā
  --no-window  tikai serveris (adrese tiek izdrukāta)
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from gramatvediba import NAME, VERSION, config, server, window  # noqa: E402


def main():
    args = sys.argv[1:]
    logged = sys.stdout is None or sys.stderr is None or os.environ.get("GRAMATVEDIBA_LOG") == "1"
    srv, url = server.start()               # aptur veco instanci, tad var sākt jaunu log.txt
    if logged:
        config.setup_log(rotate_now=True)
    print(f"{NAME} {VERSION} darbojas: {url}" + (" (pēc atjaunināšanas)" if os.environ.get("GRAMATVEDIBA_RESTARTED") else ""))
    window.run(url, args)


if __name__ == "__main__":
    main()
