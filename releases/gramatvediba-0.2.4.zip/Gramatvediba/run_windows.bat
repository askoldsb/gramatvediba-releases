@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Pirma palaisana - sagatavoju vidi...
  python -m venv .venv
)
fc /b requirements.txt .venv\req.txt >nul 2>&1
if errorlevel 1 (
  .venv\Scripts\python -m pip install -r requirements.txt && copy /y requirements.txt .venv\req.txt >nul
)
start "" .venv\Scripts\pythonw.exe Gramatvediba.py
