"""Ceļojumi: nosaukums + datumi. Kartes pirkumi ceļojuma datumos (pēc īstā pirkuma datuma) pieder ceļojumam
automātiski; ar roku var pievienot (lidojums, vīza pirms brauciena) vai izņemt. Ceļojuma izdevumi pārskatā
skaitās kategorijā "Ceļojumi". Programma iesaka ceļojumus pēc ārzemju pirkumiem (Swedbank ārvalstu valūta,
Nexo valsts kods)."""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import date, timedelta

from .store import rows

TRIP_CAT = "Ceļojumi"
SWED_DATE = re.compile(r"(?:PIRKUMS|NAUDAS IZSN\.?)\s+\S+\s+(\d\d)\.(\d\d)\.(\d{4}|\d\d)\b")
SWED_FX = re.compile(r"PIRKUMS \S+ (\d\d)\.(\d\d)\.(\d{4}) [\d.]+ ([A-Z]{3}) VALŪTAS KURSS")
NEXO_CC = re.compile(r"\[([A-Z]{3})\]\s*$")

PLACES = {
    # valūtas
    "MKD": "Maķedonija", "PLN": "Polija", "CZK": "Čehija", "TRY": "Turcija", "IDR": "Indonēzija", "GBP": "Lielbritānija",
    "SEK": "Zviedrija", "NOK": "Norvēģija", "DKK": "Dānija", "CHF": "Šveice", "HUF": "Ungārija", "RSD": "Serbija",
    "BGN": "Bulgārija", "RON": "Rumānija", "THB": "Taizeme", "ALL": "Albānija", "GEL": "Gruzija", "AED": "AAE",
    "EGP": "Ēģipte", "JPY": "Japāna", "ISK": "Islande", "BAM": "Bosnija", "MAD": "Maroka", "VND": "Vjetnama",
    # valstu kodi (Nexo)
    "CZE": "Čehija", "POL": "Polija", "TUR": "Turcija", "IDN": "Indonēzija", "DEU": "Vācija", "FRA": "Francija",
    "ITA": "Itālija", "ESP": "Spānija", "LTU": "Lietuva", "EST": "Igaunija", "FIN": "Somija", "SWE": "Zviedrija",
    "GBR": "Lielbritānija", "NLD": "Nīderlande", "AUT": "Austrija", "GRC": "Grieķija", "PRT": "Portugāle",
    "HRV": "Horvātija", "SRB": "Serbija", "BGR": "Bulgārija", "ALB": "Albānija", "GEO": "Gruzija", "THA": "Taizeme",
    "ARE": "AAE", "EGY": "Ēģipte", "DNK": "Dānija", "NOR": "Norvēģija", "CHE": "Šveice", "BEL": "Beļģija",
    "MNE": "Melnkalne", "SVN": "Slovēnija", "SVK": "Slovākija", "ROU": "Rumānija", "CYP": "Kipra", "MLT": "Malta",
}


def _d(s) -> date:
    return date.fromisoformat(str(s)[:10])


def eff_date(t: dict) -> str:
    """Īstais pirkuma datums: Swedbank — no apraksta (grāmatojums ir 1–3 dienas vēlāk), Revolut — sākuma laiks."""
    desc = t.get("description") or ""
    if t.get("source") == "swedbank":
        m = SWED_DATE.search(desc)
        if m:
            y = m.group(3) if len(m.group(3)) == 4 else "20" + m.group(3)
            return f"{y}-{m.group(2)}-{m.group(1)}"
    if t.get("source") == "revolut" and t.get("ref") and re.match(r"\d{4}-\d\d-\d\d", t["ref"]):
        return t["ref"][:10]
    return t["date"][:10]


def is_spending(t: dict) -> bool:
    """Tēriņš, kas var piederēt ceļojumam: izejošs, nav pārskaitījums/maiņa/atmaksa, nav saistības maksājums."""
    if t["amount"] >= 0 or t.get("link_id") or t.get("cat_kind") == "parskaitijums" or t.get("obligation"):
        return False
    src, desc, kind = t.get("source"), (t.get("description") or "").upper(), (t.get("kind_raw") or "").upper()
    if src == "swedbank":
        return desc.startswith("PIRKUMS") or desc.startswith("NAUDAS IZSN")
    if src == "revolut":
        return kind in ("CARD_PAYMENT", "ATM") or "BANKOM" in kind or "KART" in kind
    if src == "nexo":
        return desc.startswith("KARTES")
    return True     # PayPal, manuāli


def _tx_window(con, d_from: str, d_to: str, pad_before=5, pad_after=5) -> list[dict]:
    lo = (_d(d_from) - timedelta(days=pad_before)).isoformat()
    hi = (_d(d_to) + timedelta(days=pad_after)).isoformat()
    return rows(con.execute(
        """SELECT t.id, t.date, t.amount, t.currency, t.counterparty, t.description, t.kind_raw, t.ref, t.eur_rate,
                  t.category_id, c.name AS category, c.kind AS cat_kind, a.name AS account, a.source, a.book_id,
                  (SELECT l.id FROM transfer_links l WHERE l.out_tx=t.id OR l.in_tx=t.id) AS link_id,
                  (SELECT 1 FROM obligation_schedule s WHERE s.transaction_id=t.id) AS obligation
           FROM transactions t JOIN accounts a ON a.id=t.account_id LEFT JOIN categories c ON c.id=t.category_id
           WHERE t.date BETWEEN ? AND ?""", (lo, hi)))


def list_trips(con) -> list[dict]:
    return rows(con.execute("SELECT * FROM trips ORDER BY date_from DESC"))


def members(con, trip: dict) -> list[dict]:
    over = {r["transaction_id"]: r["mode"] for r in con.execute(
        "SELECT transaction_id, mode FROM trip_tx WHERE trip_id=?", (trip["id"],))}
    out = []
    for t in _tx_window(con, trip["date_from"], trip["date_to"]):
        t["eff_date"] = eff_date(t)
        mode = over.get(t["id"])
        if mode == "exclude":
            continue
        auto = trip["date_from"] <= t["eff_date"] <= trip["date_to"] and is_spending(t)
        if auto or mode == "add":
            t["manual"] = mode == "add"
            out.append(t)
    added = [i for i, m in over.items() if m == "add" and i not in {t["id"] for t in out}]
    if added:       # ar roku pievienoti ārpus loga (piem. lidojums pirms 2 mēnešiem)
        for t in rows(con.execute(
                f"""SELECT t.id, t.date, t.amount, t.currency, t.counterparty, t.description, t.kind_raw, t.ref, t.eur_rate,
                           t.category_id, c.name AS category, c.kind AS cat_kind, a.name AS account, a.source, a.book_id
                    FROM transactions t JOIN accounts a ON a.id=t.account_id LEFT JOIN categories c ON c.id=t.category_id
                    WHERE t.id IN ({','.join('?' * len(added))})""", added)):
            t["eff_date"], t["manual"] = eff_date(t), True
            out.append(t)
    return sorted(out, key=lambda t: (t["eff_date"], t["id"]))


def member_map(con) -> dict:
    """{transaction_id: ceļojuma nosaukums} visiem ceļojumiem — pārskatam un darījumu sarakstam."""
    m = {}
    for tr in list_trips(con):
        for t in members(con, tr):
            m.setdefault(t["id"], tr["name"])
    return m


def detail(con, trip_id: int) -> dict:
    from .db import fx_map
    tr = dict(con.execute("SELECT * FROM trips WHERE id=?", (trip_id,)).fetchone())
    fx = fx_map(con)
    lst = members(con, tr)
    by_cat, by_day = defaultdict(float), defaultdict(float)
    total = 0.0
    for t in lst:
        rate = t["eur_rate"] if t["eur_rate"] is not None else fx.get(t["currency"])
        t["eur"] = round(t["amount"] * rate, 2) if rate is not None else None
        if t["eur"] is None:
            continue
        cost = -t["eur"]
        total += cost
        by_cat[t["category"] or "Citi"] += cost
        by_day[t["eff_date"]] += cost
    days = (_d(tr["date_to"]) - _d(tr["date_from"])).days + 1
    return {"trip": tr, "transactions": lst, "total": round(total, 2), "days": days,
            "per_day": round(total / days, 2) if days > 0 else None,
            "by_category": [{"category": k, "total": round(v, 2)} for k, v in sorted(by_cat.items(), key=lambda x: -x[1])],
            "by_day": [{"date": k, "total": round(v, 2)} for k, v in sorted(by_day.items())]}


def summary(con) -> list[dict]:
    out = []
    for tr in list_trips(con):
        d = detail(con, tr["id"])
        out.append(dict(tr, total=d["total"], count=len(d["transactions"]), days=d["days"]))
    return out


def save(con, data: dict, trip_id: int | None = None) -> int:
    name = (data.get("name") or "").strip()
    a, b = data.get("date_from"), data.get("date_to") or data.get("date_from")
    if not name or not a:
        raise ValueError("Norādi nosaukumu un datumus")
    if b < a:
        a, b = b, a
    if trip_id:
        con.execute("UPDATE trips SET name=?, date_from=?, date_to=?, note=? WHERE id=?", (name, a, b, data.get("note"), trip_id))
    else:
        trip_id = con.execute("INSERT INTO trips(name, date_from, date_to, note) VALUES (?,?,?,?)",
                              (name, a, b, data.get("note"))).lastrowid
    con.commit()
    return trip_id


def delete(con, trip_id: int):
    con.execute("DELETE FROM trips WHERE id=?", (trip_id,))
    con.commit()


def set_tx(con, trip_id: int, tx_id: int, mode: str | None):
    """mode: 'add' — pievienot, 'exclude' — izņemt, None — kā noteikts automātiski."""
    con.execute("DELETE FROM trip_tx WHERE trip_id=? AND transaction_id=?", (trip_id, tx_id))
    if mode in ("add", "exclude"):
        con.execute("INSERT INTO trip_tx(trip_id, transaction_id, mode) VALUES (?,?,?)", (trip_id, tx_id, mode))
    con.commit()


def add_candidates(con, trip_id: int, q: str = "") -> list[dict]:
    """Izdevumi 60 dienas pirms ceļojuma līdz 10 dienām pēc, kas vēl nepieder ceļojumam (lidojumi, vīzas …)."""
    tr = dict(con.execute("SELECT * FROM trips WHERE id=?", (trip_id,)).fetchone())
    have = {t["id"] for t in members(con, tr)}
    out = []
    for t in _tx_window(con, tr["date_from"], tr["date_to"], 60, 10):
        if t["id"] in have or t["amount"] >= 0:
            continue
        if q and q.lower() not in f"{t['counterparty']} {t['description']}".lower():
            continue
        t["eff_date"] = eff_date(t)
        out.append(t)
    return sorted(out, key=lambda t: t["eff_date"], reverse=True)[:80]


def suggestions(con) -> list[dict]:
    """Ceļojumu ieteikumi pēc ārzemju pirkumiem; dienas ar ≤ 3 dienu starpību apvieno vienā ceļojumā."""
    sig = []
    for t in rows(con.execute(
            """SELECT t.date, t.description, t.amount, a.source FROM transactions t JOIN accounts a ON a.id=t.account_id
               WHERE t.amount < 0 AND (a.source='swedbank' OR a.source='nexo')""")):
        desc = t["description"] or ""
        if t["source"] == "swedbank":
            m = SWED_FX.search(desc)
            if m and m.group(4) != "EUR":
                sig.append((f"{m.group(3)}-{m.group(2)}-{m.group(1)}", m.group(4)))
        else:
            m = NEXO_CC.search(desc)
            if m and m.group(1) != "LVA":
                sig.append((t["date"][:10], m.group(1)))
    sig.sort()
    clusters, cur = [], []
    for d, code in sig:
        if cur and (_d(d) - _d(cur[-1][0])).days > 3:
            clusters.append(cur)
            cur = []
        cur.append((d, code))
    if cur:
        clusters.append(cur)
    trips = list_trips(con)
    out = []
    for c in clusters:
        if len(c) < 3:
            continue        # viens ārzemju pirkums (piem. interneta abonements) nav ceļojums
        a, b = c[0][0], c[-1][0]
        if any(not (b < t["date_from"] or a > t["date_to"]) for t in trips):
            continue        # jau ir ceļojums šajos datumos
        cnt = defaultdict(int)
        for _, code in c:
            cnt[PLACES.get(code, code)] += 1
        names = [k for k, _ in sorted(cnt.items(), key=lambda x: -x[1])]
        out.append({"name": ", ".join(names), "date_from": a, "date_to": b, "count": len(c)})
    return sorted(out, key=lambda x: x["date_from"], reverse=True)
