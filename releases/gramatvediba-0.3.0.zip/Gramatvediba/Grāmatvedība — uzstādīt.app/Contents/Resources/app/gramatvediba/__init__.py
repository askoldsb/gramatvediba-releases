"""Grāmatvedība — privāta personīgo finanšu uzskaite."""
NAME = "Grāmatvedība"
SLUG = "Gramatvediba"
VERSION = "0.3.0"
PORTS = (47645, 47646, 47647)
