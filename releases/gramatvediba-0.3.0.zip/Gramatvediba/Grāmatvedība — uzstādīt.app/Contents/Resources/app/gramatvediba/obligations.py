"""Saistības: līzingi, nomaksas, kredīti, uzturlīdzekļi u.c. regulāri maksājumi.

Katrai saistībai tiek uzbūvēts maksājumu grafiks. Programma bankas darījumos (tās pašas grāmatvedības kontos)
meklē maksājumus, kas atbilst grafikam pēc teksta, summas un datuma, un atzīmē tos kā samaksātus.
"""
from __future__ import annotations

import calendar
from datetime import date, timedelta

from .store import rows

KINDS = {
    "lizings": "Līzings", "nomaksa": "Nomaksa", "kredits": "Kredīts / aizdevums",
    "uzturlidzekli": "Uzturlīdzekļi", "ire": "Īre", "apdrosinasana": "Apdrošināšana",
    "abonements": "Abonements", "cits": "Cits",
}
FREQ = {"menesis": 1, "ceturksnis": 3, "gads": 12}
FREQ_LABEL = {"menesis": "Katru mēnesi", "ceturksnis": "Reizi ceturksnī", "gads": "Reizi gadā"}
COLS = ["name", "kind", "direction", "counterparty", "start_date", "frequency", "n_payments", "payment_amount",
        "principal", "interest_rate", "residual", "currency", "match_text", "tolerance", "note", "active", "book_id",
        "end_date"]


def add_months(d: date, months: int, day: int) -> date:
    m = d.month - 1 + months
    y = d.year + m // 12
    m = m % 12 + 1
    return date(y, m, min(day, calendar.monthrange(y, m)[1]))


def annuity(principal: float, annual_rate: float, n: int, residual: float = 0.0, periods_per_year=12) -> float:
    r = annual_rate / 100 / periods_per_year
    if r == 0:
        return (principal - residual) / n
    return (principal - residual / (1 + r) ** n) * r / (1 - (1 + r) ** -n)


def build_schedule(ob: dict, today: date | None = None) -> list[dict]:
    today = today or date.today()
    start = date.fromisoformat(ob["start_date"])
    step = FREQ.get(ob.get("frequency") or "menesis", 1)
    ppy = 12 // step
    n = ob.get("n_payments")
    if not n and ob.get("end_date"):    # pēdējā maksājuma datums → maksājumu skaits
        end = date.fromisoformat(ob["end_date"])
        n, months = 0, 0
        while (lambda d: (d.year, d.month))(add_months(start, months, start.day)) <= (end.year, end.month):   # ieskaitot beigu mēnesi
            n += 1
            months += step
        if n == 0:
            raise ValueError("Pēdējais maksājums ir pirms pirmā")
        ob = dict(ob, n_payments=n)
    if not n:   # beztermiņa – grafiks līdz gadam uz priekšu
        n, months, limit = 0, 0, add_months(today, 12, today.day)
        while add_months(start, months, start.day) <= limit:
            n += 1
            months += step
    principal = ob.get("principal")
    rate = ob.get("interest_rate") or 0
    residual = ob.get("residual") or 0
    pmt = ob.get("payment_amount")
    if not pmt:
        if not principal or not ob.get("n_payments"):
            raise ValueError("Norādi maksājuma summu vai pamatsummu un maksājumu skaitu")
        pmt = annuity(principal, rate, n, residual, ppy)
    r = rate / 100 / ppy
    bal = principal
    out = []
    for i in range(n):
        row = {"seq": i + 1, "due_date": add_months(start, i * step, start.day).isoformat(), "amount": round(pmt, 2),
               "principal_part": None, "interest_part": None, "balance_after": None}
        if bal is not None:
            interest = bal * r
            princ = pmt - interest
            if i == n - 1 and not residual:      # noapaļošanas korekcija pēdējā maksājumā
                princ = bal
                row["amount"] = round(princ + interest, 2)
            bal -= princ
            row.update(principal_part=round(princ, 2), interest_part=round(interest, 2),
                       balance_after=round(max(bal, 0), 2))
        out.append(row)
    if residual and out:
        out.append({"seq": n + 1, "due_date": out[-1]["due_date"], "amount": round(residual, 2),
                    "principal_part": round(residual, 2), "interest_part": 0.0, "balance_after": 0.0})
    return out


def save_obligation(con, data: dict, ob_id: int | None = None) -> int:
    build_schedule(data)            # pārbauda datus pirms saglabāšanas
    vals = [data.get(c) for c in COLS]
    if ob_id:
        con.execute(f"UPDATE obligations SET {','.join(c + '=?' for c in COLS)} WHERE id=?", vals + [ob_id])
    else:
        ob_id = con.execute(f"INSERT INTO obligations({','.join(COLS)}) VALUES ({','.join('?' * len(COLS))})",
                            vals).lastrowid
    regenerate_schedule(con, ob_id)
    return ob_id


def get_obligation(con, ob_id: int) -> dict | None:
    r = con.execute("SELECT * FROM obligations WHERE id=?", (ob_id,)).fetchone()
    return dict(r) if r else None


def regenerate_schedule(con, ob_id: int, today: date | None = None):
    """Pārbūvē grafiku, saglabājot jau piesaistītos maksājumus pēc kārtas numura."""
    ob = get_obligation(con, ob_id)
    keep = {r["seq"]: (r["transaction_id"], r["manual_paid"]) for r in con.execute(
        "SELECT seq, transaction_id, manual_paid FROM obligation_schedule WHERE obligation_id=?", (ob_id,))}
    con.execute("DELETE FROM obligation_schedule WHERE obligation_id=?", (ob_id,))
    for r in build_schedule(ob, today):
        tid, manual = keep.get(r["seq"], (None, 0))
        con.execute(
            """INSERT INTO obligation_schedule(obligation_id, seq, due_date, amount, principal_part, interest_part,
               balance_after, transaction_id, manual_paid) VALUES (?,?,?,?,?,?,?,?,?)""",
            (ob_id, r["seq"], r["due_date"], r["amount"], r["principal_part"], r["interest_part"],
             r["balance_after"], tid, manual))
    con.commit()


def regenerate_all(con, today: date | None = None):
    for (oid,) in con.execute("SELECT id FROM obligations WHERE active=1").fetchall():
        regenerate_schedule(con, oid, today)


def delete_obligation(con, ob_id: int):
    con.execute("DELETE FROM obligations WHERE id=?", (ob_id,))
    con.commit()


def set_manual_paid(con, schedule_id: int, paid: bool):
    con.execute("UPDATE obligation_schedule SET manual_paid=? WHERE id=?", (int(bool(paid)), schedule_id))
    con.commit()


def unlink(con, schedule_id: int):
    con.execute("UPDATE obligation_schedule SET transaction_id=NULL WHERE id=?", (schedule_id,))
    con.commit()


def match_payments(con, today: date | None = None, before_days=15, after_days=20) -> int:
    """Automātiski piesaista bankas darījumus neapmaksātajiem grafika maksājumiem."""
    today = today or date.today()
    linked = {r[0] for r in con.execute(
        "SELECT transaction_id FROM obligation_schedule WHERE transaction_id IS NOT NULL")}
    n = 0
    for ob in con.execute("SELECT * FROM obligations WHERE active=1 AND COALESCE(match_text,'')<>''").fetchall():
        words = [w.strip().lower() for w in ob["match_text"].split(";") if w.strip()]
        sign = "<" if ob["direction"] == "maksaju" else ">"
        book_sql, book_p = ("", []) if ob["book_id"] is None else (" AND a.book_id=?", [ob["book_id"]])
        for s in con.execute(
                """SELECT * FROM obligation_schedule WHERE obligation_id=? AND transaction_id IS NULL
                   AND manual_paid=0 AND due_date <= ? ORDER BY seq""",
                (ob["id"], (today + timedelta(days=after_days)).isoformat())).fetchall():
            due = date.fromisoformat(s["due_date"])
            cands = con.execute(
                f"""SELECT t.id, t.date, t.counterparty, t.description FROM transactions t
                    JOIN accounts a ON a.id=t.account_id
                    WHERE t.amount {sign} 0 AND t.date BETWEEN ? AND ? AND ABS(ABS(t.amount) - ?) <= ?{book_sql}""",
                [(due - timedelta(days=before_days)).isoformat(), (due + timedelta(days=after_days)).isoformat(),
                 s["amount"], ob["tolerance"]] + book_p).fetchall()
            cands = [c for c in cands if c["id"] not in linked and
                     any(w in f"{c['counterparty']} {c['description']}".lower() for w in words)]
            if not cands:
                continue
            best = min(cands, key=lambda c: abs((date.fromisoformat(c["date"]) - due).days))
            con.execute("UPDATE obligation_schedule SET transaction_id=? WHERE id=?", (best["id"], s["id"]))
            linked.add(best["id"])
            n += 1
    con.commit()
    return n


def _st(r, today: str) -> str:
    if r["transaction_id"] or r["manual_paid"]:
        return "paid"
    return "late" if r["due_date"] < today else "due"


def schedule(con, ob_id: int, today: date | None = None) -> list[dict]:
    today_s = (today or date.today()).isoformat()
    out = rows(con.execute(
        """SELECT s.id, s.seq, s.due_date, s.amount, s.principal_part, s.interest_part, s.balance_after,
                  s.transaction_id, s.manual_paid, t.date AS paid_date, t.amount AS paid_amount
           FROM obligation_schedule s LEFT JOIN transactions t ON t.id=s.transaction_id
           WHERE s.obligation_id=? ORDER BY s.seq""", (ob_id,)))
    for r in out:
        r["status"] = _st(r, today_s)
    return out


def summary(con, book_id=None, today: date | None = None) -> list[dict]:
    today_s = (today or date.today()).isoformat()
    sql, params = "SELECT * FROM obligations", []
    if book_id is not None:
        sql += " WHERE book_id=?"; params.append(book_id)
    out = []
    for ob in con.execute(sql + " ORDER BY active DESC, name", params).fetchall():
        sch = schedule(con, ob["id"], today)
        paid = [s for s in sch if s["status"] == "paid"]
        left = [s for s in sch if s["status"] != "paid"]
        late = [s for s in sch if s["status"] == "late"]
        nxt = next((s for s in left if s["due_date"] >= today_s), None)
        debt = None
        if ob["principal"]:
            debt = paid[-1]["balance_after"] if paid else ob["principal"]
        out.append({
            "id": ob["id"], "name": ob["name"], "kind": ob["kind"], "kind_label": KINDS.get(ob["kind"], ob["kind"]),
            "direction": ob["direction"], "active": bool(ob["active"]), "book_id": ob["book_id"],
            "payment_amount": ob["payment_amount"], "frequency": ob["frequency"],
            "paid_n": len(paid), "total_n": len(sch) if (ob["n_payments"] or ob["end_date"]) else None,
            "paid_sum": round(sum(s["amount"] for s in paid), 2),
            "left_sum": round(sum(s["amount"] for s in left), 2) if (ob["n_payments"] or ob["end_date"]) else None,
            "left_n": len(left) if (ob["n_payments"] or ob["end_date"]) else None,
            "end_date": sch[-1]["due_date"] if (ob["n_payments"] or ob["end_date"]) and sch else None,
            "debt": debt, "late_n": len(late), "late_sum": round(sum(s["amount"] for s in late), 2),
            "next_date": nxt["due_date"] if nxt else None, "next_amount": nxt["amount"] if nxt else None,
        })
    return out


def upcoming(con, days: int = 30, book_id=None, today: date | None = None) -> list[dict]:
    """Visi gaidāmie un nokavētie maksājumi: saistības + neapmaksātie rēķini."""
    today_d = today or date.today()
    until = (today_d + timedelta(days=days)).isoformat()
    bsql, bp = ("", []) if book_id is None else (" AND o.book_id=?", [book_id])
    a = rows(con.execute(
        f"""SELECT s.due_date, o.name, 'saistiba' AS source, o.id AS ref,
                   CASE o.direction WHEN 'maksaju' THEN -s.amount ELSE s.amount END AS amount
            FROM obligation_schedule s JOIN obligations o ON o.id=s.obligation_id
            WHERE o.active=1 AND s.transaction_id IS NULL AND s.manual_paid=0 AND s.due_date <= ?{bsql}""",
        [until] + bp))
    bsql = bsql.replace("o.", "i.")
    b = rows(con.execute(
        f"""SELECT i.due_date, i.counterparty || COALESCE(' #' || i.number, '') AS name, 'rekins' AS source,
                   i.id AS ref, (CASE i.direction WHEN 'sanemts' THEN -1 ELSE 1 END) *
                   (i.amount - COALESCE((SELECT SUM(p.amount) FROM invoice_payments p WHERE p.invoice_id=i.id),0))
                   AS amount
            FROM invoices i WHERE i.due_date IS NOT NULL AND i.due_date <= ?{bsql}""", [until] + bp))
    b = [r for r in b if abs(r["amount"]) > 0.005]
    out = sorted(a + b, key=lambda r: r["due_date"])
    for r in out:
        r["late"] = r["due_date"] < today_d.isoformat()
        r["amount"] = round(r["amount"], 2)
    return out
