"""Grāmatvedība — privāta personīgo finanšu uzskaite."""
NAME = "Grāmatvedība"
SLUG = "Gramatvediba"
VERSION = "0.2.5"
PORTS = (47645, 47646, 47647)
