// Labojumu vēsture (jaunākā augšā). Katrā versijā papildini.
window.CHANGELOG = [
  {
    v: "0.2.3", date: "2026-11-06",
    lv: ["Pārskatā izcelts “Pieejamais atlikums” (visu kontu kopsumma eiro), un atlikumu tabulā ir rinda “Kopā”.", "“Kavēti maksājumi” tiek rādīti tikai, ja grāmatvedībā ir saistības vai rēķini.", "Brīdinājums par trūkstošu valūtas kursu tikai, ja kontā tiešām ir nauda (tukšie PayPal GBP/USD vairs netraucē)."],
  },
  {
    v: "0.2.2", date: "2026-11-06",
    lv: ["Nexo: kartes pirkumi tiek ieskaitīti pareizi: viens izdevums ar veikala nosaukumu un atsevišķa FX komisija. Nexo iekšējie norēķini (Withdraw Exchanged, Exchange Deposited On) un USD kredītlīnijas ekvivalents vairs netiek skaitīti. EUR un EURX ir viens konts “Nexo EUR”. Lai salabotu, vēlreiz ielādē Nexo failu: vecie ieraksti tiek aizstāti automātiski.", "PayPal: tiek atpazīts arī eksports “Activity download” (Amount / Fees / Total / Exchange Rate). PayPal atlikums tiek ņemts no jaunākā ieraksta.", "Revolut: gaidošie (vēl neapstiprinātie) maksājumi tiek ieskaitīti atlikumā un atzīmēti “gaida”, un nākamais imports tos aizstāj.", "Jaunas kategorizēšanas kārtulas biežākajiem tirgotājiem (DUS, kafejnīcas, restorāni, Drogas, Apotheka, Depo, Senukai, Midjourney, Anthropic u.c.)."],
  },
  {
    v: "0.2.1", date: "2026-11-06",
    lv: ["Atjauninājumi no sava repozitorija askoldsb/gramatvediba-releases."],
  },
  {
    v: "0.2.0", date: "2026-11-06",
    lv: [
      "Pārskaitījumi starp saviem kontiem: programma pati atrod, kur viena un tā pati nauda pāriet no konta uz kontu (PayPal → Revolut/Nexo, Swedbank ↔ Swedbank, Revolut → Swedbank …); tie neskaitās ne ienākumos, ne izdevumos. Jaunā sadaļa “Pārskaitījumi”: pāri, darījumi bez pāra, sasaistīšana un atsaistīšana ar roku.",
      "Valūtas maiņa: PayPal, Revolut un Nexo maiņas abas puses tiek sasaistītas, un ar faktisko kursu tiek novērtēts arī pats ienākums (piem. Shutterstock USD izmaksa — PayPal kurss tajā brīdī).",
      "Pārskatā redzams, cik naudas pārvietots uz / no otras grāmatvedības.",
      "Atjauninājumi tagad nāk no sava repozitorija gramatvediba-releases.",
    ],
  },
  {
    v: "0.1.1", date: "2026-11-06",
    lv: [
      "Revolut: tiek atpazīts arī latviešu valodas eksports (Veids, Produkts, Sākuma datums …) un latviski darījumu veidi un statusi.",
    ],
  },
  {
    v: "0.1.0", date: "2026-11-06",
    lv: [
      "Pirmā versija: imports no Swedbank, Revolut, PayPal un Nexo CSV (formātu atpazīst pati, dublikātus izlaiž).",
      "Divas atsevišķas grāmatvedības: Darbs (Swedbank) un Fotobanks (PayPal, Revolut, Nexo), arī skats “Visas kopā”.",
      "Pārskats, darījumi ar kategorijām un kārtulām, rēķini ar apmaksas piesaisti, saistības (līzingi, nomaksas, uzturlīdzekļi) ar grafiku.",
      "Mac uzstādītājs, automātiska atjaunināšana un dienas rezerves kopijas.",
    ],
  },
];
