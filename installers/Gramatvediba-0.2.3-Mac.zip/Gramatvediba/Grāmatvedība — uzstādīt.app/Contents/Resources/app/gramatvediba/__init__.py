"""Grāmatvedība — privāta personīgo finanšu uzskaite."""
NAME = "Grāmatvedība"
SLUG = "Gramatvediba"
VERSION = "0.2.3"
PORTS = (47645, 47646, 47647)
