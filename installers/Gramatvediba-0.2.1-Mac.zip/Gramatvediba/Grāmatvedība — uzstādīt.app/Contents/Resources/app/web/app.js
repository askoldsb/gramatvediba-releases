"use strict";
/* Grāmatvedība — saskarne (tīrs JavaScript). API: POST /api/<nosaukums> ar X-Token. */

// ------------------------------------------------------------------ palīgi
const $ = (s, r = document) => r.querySelector(s);
const S = { books: [], book: 0, categories: [], page: "overview", from: "", to: "", txFilter: {} };

async function api(name, data = {}) {
  let r;
  try {
    r = await fetch("/api/" + name, { method: "POST", headers: { "Content-Type": "application/json", "X-Token": window.TOKEN },
      body: JSON.stringify(Object.assign({ book: S.book }, data)) });
  } catch (e) { toast("Nav savienojuma ar programmu", true); throw e; }
  const j = await r.json().catch(() => ({ ok: false, error: "Nederīga atbilde" }));
  if (!j.ok) { toast(j.error || "Kļūda", true); throw new Error(j.error); }
  return j;
}

function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === "class") e.className = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (k === "html") e.innerHTML = v;
    else if (k === "value") e.value = v;
    else if (k === "checked") e.checked = !!v;
    else e.setAttribute(k, v === true ? "" : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) e.append(k.nodeType ? k : document.createTextNode(String(k)));
  return e;
}

const nf = new Intl.NumberFormat("lv-LV", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const nf8 = new Intl.NumberFormat("lv-LV", { minimumFractionDigits: 2, maximumFractionDigits: 8 });
function money(v, cur = "EUR") {
  if (v == null || isNaN(v)) return "—";
  const s = (cur === "EUR" || cur === "EURX" || cur === "USD" || cur === "GBP") ? nf.format(v) : nf8.format(v);
  return s + (cur === "EUR" ? " €" : " " + cur);
}
function moneyEl(v, cur, tag = "span") { return h(tag, { class: "num " + (v > 0 ? "in" : v < 0 ? "out" : "") }, money(v, cur)); }
function dmy(iso) { if (!iso) return ""; const [y, m, d] = iso.slice(0, 10).split("-"); return `${d}.${m}.${y}`; }
const todayIso = () => new Date().toISOString().slice(0, 10);
function esc(s) { return String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
function bookName(id) { return (S.books.find(b => b.id === id) || {}).name || "—"; }

function toast(msg, err = false) {
  const t = h("div", { class: "toast" + (err ? " err" : "") }, msg);
  $("#toasts").append(t);
  setTimeout(() => t.remove(), err ? 7000 : 3500);
}

function dialog(title, body, buttons, narrow = false) {
  return new Promise(res => {
    const d = $("#dialog");
    d.className = "dialog" + (narrow ? " narrow" : "");
    d.replaceChildren(h("h2", {}, title), body || "", h("div", { class: "actions" },
      buttons.map(b => h("button", { class: (b.cls || "") , onclick: async () => {
        if (b.action) { try { const r = await b.action(); if (r === false) return; } catch (e) { return; } }
        close(); res(b.value);
      } }, b.label))));
    const ov = $("#overlay");
    ov.hidden = false;
    const close = () => { ov.hidden = true; d.replaceChildren(); };
    ov.onclick = e => { if (e.target === ov) { close(); res(null); } };
    const first = d.querySelector("input,select,textarea");
    if (first) setTimeout(() => first.focus(), 30);
  });
}
const confirmDlg = (title, text, label = "Jā", cls = "danger") =>
  dialog(title, h("p", {}, text), [{ label: "Atcelt", value: false }, { label, value: true, cls }], true);

function promptDlg(title, label, value = "") {
  const inp = h("input", { value, style: "width:100%" });
  return dialog(title, h("label", { class: "small muted" }, label, h("br"), inp),
    [{ label: "Atcelt", value: null }, { label: "Saglabāt", cls: "primary", action: () => { promptDlg.v = inp.value; } }], true)
    .then(r => (r === undefined ? promptDlg.v : null));
}

function catSelect(value, opts = {}) {
  const groups = { ienakumi: "Ienākumi", izdevumi: "Izdevumi", parskaitijums: "Pārskaitījumi (neskaitās)" };
  const sel = h("select", opts, h("option", { value: "" }, opts.placeholder || "— bez kategorijas —"));
  for (const [k, label] of Object.entries(groups)) {
    const g = h("optgroup", { label });
    S.categories.filter(c => c.kind === k).forEach(c => g.append(h("option", { value: c.id }, c.name)));
    sel.append(g);
  }
  sel.value = value ?? "";
  return sel;
}

function bookSelect(value, includeAll = false) {
  const s = h("select", {}, includeAll ? h("option", { value: "" }, "—") : null,
    S.books.map(b => h("option", { value: b.id }, b.name)));
  s.value = value ?? (S.book || (S.books[0] || {}).id || "");
  return s;
}

function field(label, input, cls = "") { return h("label", { class: cls }, label, input); }
function formValues(map) {
  const o = {};
  for (const [k, el] of Object.entries(map)) o[k] = el.type === "checkbox" ? el.checked : el.value;
  return o;
}

// ------------------------------------------------------------------ galvene: grāmatvedības un periods
const PERIODS = [
  ["year", "Šis gads"], ["month", "Šis mēnesis"], ["prevmonth", "Iepriekšējais mēnesis"],
  ["prevyear", "Pagājušais gads"], ["all", "Viss laiks"], ["custom", "Cits periods…"]];

function periodRange(p) {
  const d = new Date(), y = d.getFullYear(), m = d.getMonth();
  const iso = x => new Date(x.getTime() - x.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  switch (p) {
    case "month": return [iso(new Date(y, m, 1)), iso(new Date(y, m + 1, 0))];
    case "prevmonth": return [iso(new Date(y, m - 1, 1)), iso(new Date(y, m, 0))];
    case "prevyear": return [`${y - 1}-01-01`, `${y - 1}-12-31`];
    case "all": return ["", ""];
    case "custom": return [$("#pFrom").value, $("#pTo").value];
    default: return [`${y}-01-01`, `${y}-12-31`];
  }
}

function renderBooks() {
  const box = $("#books");
  box.replaceChildren(...S.books.map(b => h("button", { class: S.book === b.id ? "on" : "", onclick: () => setBook(b.id) }, b.name)),
    h("button", { class: S.book === 0 ? "on" : "", onclick: () => setBook(0) }, "Visas kopā"));
}

async function setBook(id) {
  S.book = id;
  renderBooks();
  api("settings_save", { values: { book: id } }).catch(() => {});
  show(S.page);
}

function initPeriod() {
  const sel = $("#period");
  PERIODS.forEach(([v, l]) => sel.append(h("option", { value: v }, l)));
  const apply = () => {
    $("#customPeriod").hidden = sel.value !== "custom";
    if (sel.value === "custom" && !$("#pFrom").value) {
      [$("#pFrom").value, $("#pTo").value] = periodRange("year");
    }
    [S.from, S.to] = periodRange(sel.value);
    show(S.page);
  };
  sel.onchange = apply;
  $("#pFrom").onchange = $("#pTo").onchange = apply;
  [S.from, S.to] = periodRange("year");
}

// ------------------------------------------------------------------ navigācija
const PAGES = {};
async function show(page) {
  S.page = page;
  document.querySelectorAll("#nav a").forEach(a => a.classList.toggle("on", a.dataset.page === page));
  const main = $("#main");
  try {
    const node = await PAGES[page]();
    main.replaceChildren(node);
  } catch (e) {
    console.error(e);
    main.replaceChildren(h("div", { class: "empty" }, "Neizdevās ielādēt: " + e.message));
  }
}

const bookTitle = () => S.book ? bookName(S.book) : "Visas grāmatvedības kopā";
const periodText = () => S.from || S.to ? `${dmy(S.from) || "…"} – ${dmy(S.to) || "…"}` : "viss laiks";

// ------------------------------------------------------------------ PĀRSKATS
PAGES.overview = async () => {
  const d = await api("overview", { from: S.from, to: S.to });
  const inc = d.months.reduce((a, m) => a + m.income, 0), exp = d.months.reduce((a, m) => a + m.expense, 0);
  const late = d.upcoming.filter(u => u.late);
  const root = h("div", {}, h("h1", {}, "Pārskats — ", bookTitle(), h("span", { class: "muted small" }, "  ", periodText())));
  if (d.missing_fx.length)
    root.append(h("div", { class: "notice" }, `Nav valūtas kursa: ${d.missing_fx.join(", ")} — šie konti netiek ieskaitīti kopsummās. `,
      h("a", { onclick: () => { S.settingsTab = "fx"; show("settings"); } }, "Ievadīt kursus")));
  if (d.uncategorized)
    root.append(h("div", { class: "notice" }, `${d.uncategorized} darījumiem nav kategorijas. `,
      h("a", { onclick: () => { S.txFilter = { category: "none" }; show("tx"); } }, "Parādīt")));
  if (!d.balances.length) {
    root.append(h("div", { class: "panel empty" }, "Vēl nav datu. Sāc ar ", h("a", { onclick: () => show("import") }, "📥 Imports"), "."));
    return root;
  }
  root.append(h("div", { class: "kpis" },
    kpi("Kopējais atlikums", money(d.total_eur)), kpi("Ienākumi", money(inc)), kpi("Izdevumi", money(exp)),
    kpi("Starpība", money(inc - exp), inc - exp < 0), kpi("Kavēti maksājumi", late.length ? `${late.length} · ${money(late.reduce((a, u) => a + u.amount, 0))}` : "0", late.length > 0)));

  const left = h("div", {},
    h("div", { class: "panel" }, h("h2", {}, "Ienākumi un izdevumi pa mēnešiem"), monthChart(d.months),
      h("div", { class: "legend" }, h("span", {}, h("i", { style: "background:var(--in)" }), "ienākumi"),
        h("span", {}, h("i", { style: "background:var(--out)" }), "izdevumi"),
        d.transfers.in || d.transfers.out ? h("span", {}, h("a", { onclick: () => show("transfers") }, `pārskaitījumi starp saviem kontiem (neskaitās): +${nf.format(d.transfers.in)} / −${nf.format(d.transfers.out)} €`)) : null),
      d.cross.length ? h("div", { class: "small muted", style: "margin-top:6px" }, d.cross.map(c =>
        h("span", { style: "margin-right:14px" }, c.dir === "uz" ? `→ uz ${c.book}: ${money(c.eur)}` : `← no ${c.book}: ${money(c.eur)}`))) : null),
    h("div", { class: "panel" }, h("h2", {}, "Ienākumi pa avotiem"), bars(d.incomes, true)),
    h("div", { class: "panel" }, h("h2", {}, "Izdevumi pa kategorijām"), bars(d.expenses, false)));
  const right = h("div", {},
    h("div", { class: "panel" }, h("h2", {}, "Atlikumi"), balancesTable(d.balances)),
    h("div", { class: "panel" }, h("h2", {}, "Gaidāmie maksājumi (30 dienas)"),
      d.upcoming.length ? h("table", {}, h("tbody", {}, d.upcoming.map(u => h("tr", { class: "click",
        onclick: () => show(u.source === "rekins" ? "invoices" : "obligations") },
        h("td", {}, dmy(u.due_date)), h("td", {}, u.name, " ", u.late ? h("span", { class: "chip bad" }, "kavēts") : ""),
        h("td", { class: "num" }, moneyEl(u.amount)))))) : h("div", { class: "muted" }, "Nav gaidāmu maksājumu.")));
  root.append(h("div", { class: "grid g2" }, left, right));
  return root;
};

function kpi(l, v, bad = false) { return h("div", { class: "kpi" + (bad ? " bad" : "") }, h("div", { class: "l" }, l), h("div", { class: "v" }, v)); }

function balancesTable(bal) {
  return h("table", {}, h("thead", {}, h("tr", {}, h("th", {}, "Konts"), S.book ? null : h("th", {}, "Grāmatv."),
    h("th", { class: "num" }, "Atlikums"), h("th", { class: "num" }, "EUR"))),
  h("tbody", {}, bal.map(b => h("tr", { title: b.basis + (b.last_tx ? ", pēdējais darījums " + dmy(b.last_tx) : "") },
    h("td", {}, b.name), S.book ? null : h("td", { class: "muted small" }, bookName(b.book_id)),
    h("td", { class: "num" }, money(b.balance, b.currency)), h("td", { class: "num" }, b.eur == null ? h("span", { class: "muted" }, "nav kursa") : money(b.eur))))));
}

function bars(list, income) {
  if (!list.length) return h("div", { class: "muted" }, "Nav datu šajā periodā.");
  const max = Math.max(...list.map(x => x.total));
  return h("div", { class: "bars" + (income ? " inc" : "") }, list.map(x => h("div", { class: "row" },
    h("div", { class: "name", title: x.category }, x.category),
    h("div", { class: "track" }, h("div", { class: "fill", style: `width:${(x.total / max * 100).toFixed(1)}%` })),
    h("div", { class: "num" }, money(x.total)))));
}

function monthChart(months) {
  if (!months.length) return h("div", { class: "muted" }, "Nav datu.");
  const W = 760, H = 240, P = 36, max = Math.max(1, ...months.map(m => Math.max(m.income, m.expense)));
  const bw = (W - P - 10) / months.length, y = v => H - 22 - (v / max) * (H - 40);
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`); svg.setAttribute("class", "chart");
  const add = (tag, a, text) => { const e = document.createElementNS(ns, tag); for (const k in a) e.setAttribute(k, a[k]); if (text) e.textContent = text; svg.append(e); return e; };
  for (let i = 0; i <= 4; i++) {
    const v = max * i / 4, yy = y(v);
    add("line", { x1: P, x2: W, y1: yy, y2: yy, stroke: "currentColor", "stroke-opacity": .1 });
    add("text", { x: P - 4, y: yy + 4, "text-anchor": "end" }, v >= 1000 ? (v / 1000).toFixed(1) + "k" : Math.round(v));
  }
  const MN = ["jan", "feb", "mar", "apr", "mai", "jūn", "jūl", "aug", "sep", "okt", "nov", "dec"];
  months.forEach((m, i) => {
    const x = P + i * bw, w = Math.min(28, bw * .36);
    const a = add("rect", { x: x + bw / 2 - w - 1, y: y(m.income), width: w, height: H - 22 - y(m.income), fill: "var(--in)", rx: 2 });
    a.append(Object.assign(document.createElementNS(ns, "title"), { textContent: `${m.month} ienākumi ${money(m.income)}` }));
    const b = add("rect", { x: x + bw / 2 + 1, y: y(m.expense), width: w, height: H - 22 - y(m.expense), fill: "var(--out)", rx: 2 });
    b.append(Object.assign(document.createElementNS(ns, "title"), { textContent: `${m.month} izdevumi ${money(m.expense)}` }));
    add("text", { x: x + bw / 2, y: H - 6, "text-anchor": "middle" }, MN[+m.month.slice(5) - 1] + (months.length > 12 ? " " + m.month.slice(2, 4) : ""));
  });
  return svg;
}

// ------------------------------------------------------------------ IMPORTS
PAGES.import = async () => {
  const hist = await api("imports");
  const out = h("div", {});
  const input = h("input", { type: "file", multiple: true, accept: ".csv,.txt", hidden: true, onchange: () => upload(input.files) });
  const drop = h("div", { class: "drop", onclick: () => input.click() },
    h("div", { style: "font-size:28px" }, "📥"), h("div", {}, h("b", {}, "Ievelc CSV failus šeit"), " vai klikšķini, lai izvēlētos"),
    h("div", { class: "small" }, "Swedbank, Revolut, PayPal, Nexo — formātu programma atpazīst pati. Jau ielādētie darījumi otrreiz netiek pievienoti."));
  drop.ondragover = e => { e.preventDefault(); drop.classList.add("over"); };
  drop.ondragleave = () => drop.classList.remove("over");
  drop.ondrop = e => { e.preventDefault(); drop.classList.remove("over"); upload(e.dataTransfer.files); };

  async function upload(files) {
    if (!files.length) return;
    out.replaceChildren(h("div", { class: "muted" }, "Importēju…"));
    const arr = await Promise.all([...files].map(f => new Promise(res => {
      const r = new FileReader();
      r.onload = () => res({ name: f.name, data: r.result.split(",")[1] || "" });
      r.readAsDataURL(f);
    })));
    const r = await api("import", { files: arr });
    out.replaceChildren(...r.results.map(x => x.ok
      ? h("div", { class: "result" }, h("b", {}, x.file), ` (${x.source}): jauni ${x.new}, dublikāti ${x.dup}, izlaisti ${x.skipped}`,
        h("div", { class: "small muted" }, "Konti: " + x.accounts.join(", ")),
        x.warnings.length ? h("div", { class: "small muted" }, "⚠ " + x.warnings.join(" · ")) : null)
      : h("div", { class: "result err" }, h("b", {}, x.file), ": ", x.error)),
    r.linked_obligations || r.linked_invoices ? h("div", { class: "result" }, `Automātiski atrasti maksājumi: saistībām ${r.linked_obligations}, rēķiniem ${r.linked_invoices}.`) : "");
    input.value = "";
    const fresh = await api("imports");
    histBox.replaceChildren(histTable(fresh.imports));
  }

  const histBox = h("div", {}, histTable(hist.imports));
  function histTable(list) {
    if (!list.length) return h("div", { class: "muted" }, "Vēl nekas nav importēts.");
    return h("table", {}, h("thead", {}, h("tr", {}, ["Laiks", "Fails", "Avots", "Jauni", "Dublikāti", ""].map(t => h("th", {}, t)))),
      h("tbody", {}, list.map(i => h("tr", {}, h("td", {}, i.imported_at), h("td", {}, i.filename), h("td", {}, i.source),
        h("td", { class: "num" }, i.rows_new), h("td", { class: "num" }, i.rows_dup),
        h("td", {}, h("button", { class: "link danger", onclick: async () => {
          if (await confirmDlg("Dzēst importu?", `Tiks izdzēsti visi ${i.rows_new} darījumi, kas ielādēti no “${i.filename}”.`, "Dzēst")) {
            await api("import_delete", { id: i.id }); show("import");
          }
        } }, "Dzēst"))))));
  }

  return h("div", {}, h("h1", {}, "Imports"), input, drop, out,
    h("div", { class: "panel", style: "margin-top:16px" }, h("h2", {}, "Importu vēsture"), histBox),
    h("div", { class: "panel" }, h("h2", {}, "Kur ņemt CSV"), h("table", {}, h("tbody", {},
      [["Swedbank", "Internetbanka → Konta izraksts → periods → Eksportēt (CSV)"],
       ["Revolut", "Aplikācija → konts → … → Izraksts → Excel/CSV"],
       ["PayPal", "Darbības → Atskaites → Darbību atskaites → Visi darījumi, CSV"],
       ["Nexo", "Transactions → Export (CSV)"]].map(([a, b]) => h("tr", {}, h("td", {}, h("b", {}, a)), h("td", {}, b)))))));
};

// ------------------------------------------------------------------ DARĪJUMI
PAGES.tx = async () => {
  const f = S.txFilter = Object.assign({ account: "", category: "", direction: "", q: "" }, S.txFilter);
  const d = await api("transactions", Object.assign({ from: S.from, to: S.to }, f));
  const selected = new Set();
  const acc = h("select", { onchange: () => { f.account = acc.value; show("tx"); } }, h("option", { value: "" }, "Visi konti"),
    d.accounts.map(a => h("option", { value: a.id }, a.name)));
  acc.value = f.account;
  const cat = catSelect(f.category, { placeholder: "Visas kategorijas", onchange: () => { f.category = cat.value; show("tx"); } });
  cat.options[0].after(h("option", { value: "none" }, "— bez kategorijas —"));
  cat.value = f.category;
  const dir = h("select", { onchange: () => { f.direction = dir.value; show("tx"); } },
    h("option", { value: "" }, "Ienākumi un izdevumi"), h("option", { value: "in" }, "Tikai ienākumi"), h("option", { value: "out" }, "Tikai izdevumi"));
  dir.value = f.direction;
  let qt;
  const q = h("input", { placeholder: "Meklēt…", value: f.q, oninput: () => { clearTimeout(qt); qt = setTimeout(() => { f.q = q.value; show("tx").then(() => { const n = $("#main input[placeholder='Meklēt…']"); n && (n.focus(), n.setSelectionRange(n.value.length, n.value.length)); }); }, 400); } });
  const bulkCat = catSelect("", { placeholder: "Kategorija atzīmētajiem…" });
  const bulk = h("span", { hidden: true }, bulkCat, " ", h("button", { onclick: async () => {
    await api("tx_update", { ids: [...selected], category_id: bulkCat.value }); toast(`Mainīti ${selected.size} darījumi`); show("tx");
  } }, "Piešķirt"));
  const upd = () => { bulk.hidden = !selected.size; };

  const rows = d.transactions.map(t => {
    const cb = h("input", { type: "checkbox", onchange: () => { cb.checked ? selected.add(t.id) : selected.delete(t.id); upd(); } });
    const cs = catSelect(t.category_id, { onchange: async () => {
      await api("tx_update", { id: t.id, category_id: cs.value }); t.category_id = cs.value; toast("Saglabāts");
    } });
    return h("tr", {},
      h("td", {}, cb), h("td", {}, dmy(t.date)), h("td", { class: "small" }, t.account),
      h("td", { class: "num" }, moneyEl(t.amount, t.currency),
        !["EUR", "EURX"].includes(t.currency) && t.eur != null ? h("div", { class: "small muted", title: t.rate_note || "kurss no Iestatījumi → Valūtu kursi" },
          `≈ ${money(t.eur)}${t.rate_note ? " ✓" : ""}`) : null),
      h("td", { class: "desc", title: `${t.counterparty || ""}\n${t.description || ""}${t.kind_raw ? "\n(" + t.kind_raw + ")" : ""}` },
        h("div", {}, t.counterparty || ""), h("div", { class: "small muted" }, t.description !== t.counterparty ? t.description || "" : "")),
      h("td", {}, cs, t.category_manual === 1 ? h("span", { class: "small muted", title: "Kategorija likta ar roku" }, " ✎") : null,
        t.link_id ? h("div", { class: "small" }, h("a", { title: "Viena un tā pati nauda — skat. Pārskaitījumi", onclick: () => show("transfers") },
          (t.link_kind === "maina" ? "💱 maiņa: " : "🔁 pāris: ") + (t.link_other || ""))) : null),
      h("td", { class: "small" }, h("a", { onclick: async () => {
        const v = await promptDlg("Piezīme", "Piezīme pie darījuma", t.note || "");
        if (v !== null) { await api("tx_update", { id: t.id, note: v }); show("tx"); }
      } }, t.note || "+ piezīme")),
      h("td", {}, h("button", { class: "link", title: "Izveidot kārtulu", onclick: () => ruleDialog(t) }, "⚙"),
        t.kind_raw === "manual" ? h("button", { class: "link danger", onclick: async () => {
          if (await confirmDlg("Dzēst darījumu?", "Manuāli pievienotais darījums tiks izdzēsts.", "Dzēst")) { await api("tx_delete", { id: t.id }); show("tx"); }
        } }, "✕") : null));
  });

  return h("div", {}, h("h1", {}, "Darījumi — ", bookTitle(), h("span", { class: "muted small" }, "  ", periodText())),
    h("div", { class: "toolbar" }, acc, cat, dir, q, h("span", { class: "grow" }),
      h("button", { onclick: () => manualTxDialog() }, "+ Manuāls darījums"),
      h("button", { onclick: () => downloadCsv(d.transactions) }, "⬇ CSV")),
    h("div", { class: "kpis" }, kpi("Darījumi", d.count + (d.count > d.transactions.length ? ` (rāda ${d.transactions.length})` : "")),
      kpi("Ienākumi", money(d.income)), kpi("Izdevumi", money(d.expense))),
    h("div", { class: "toolbar" }, bulk),
    d.transactions.length ? h("div", { class: "tablewrap" }, h("table", {},
      h("thead", {}, h("tr", {}, h("th", {}, h("input", { type: "checkbox", onchange: e => {
        document.querySelectorAll("#main tbody input[type=checkbox]").forEach(c => { c.checked = e.target.checked; c.dispatchEvent(new Event("change")); });
      } })), ["Datums", "Konts", "Summa", "Saņēmējs / apraksts", "Kategorija", "Piezīme", ""].map(t => h("th", { class: t === "Summa" ? "num" : "" }, t)))),
      h("tbody", {}, rows))) : h("div", { class: "panel empty" }, "Nav darījumu ar šiem filtriem."));
};

// ------------------------------------------------------------------ PĀRSKAITĪJUMI
PAGES.transfers = async () => {
  const d = await api("transfers", { from: S.from, to: S.to });
  const own = h("input", { value: d.own_names, placeholder: "piem. Jānis Paraugs", style: "min-width:260px" });
  const side = (acc, amt, cur, date, cp) => h("div", {}, h("div", {}, moneyEl(amt, cur), " ", h("span", { class: "small muted" }, dmy(date))),
    h("div", { class: "small" }, acc), h("div", { class: "small muted desc" }, cp || ""));
  const conv = d.pairs.filter(p => p.kind === "maina"), tr = d.pairs.filter(p => p.kind !== "maina");
  const pairTable = (list, isConv) => list.length ? h("div", { class: "tablewrap" }, h("table", {},
    h("thead", {}, h("tr", {}, ["No", "", "Uz", isConv ? "Kurss" : "Starpība", "", ""].map(t => h("th", {}, t)))),
    h("tbody", {}, list.map(p => h("tr", {},
      h("td", {}, side(p.out_account, p.out_amount, p.out_currency, p.out_date, p.out_cp || p.out_desc)), h("td", {}, "→"),
      h("td", {}, side(p.in_account, p.in_amount, p.in_currency, p.in_date, p.in_cp || p.in_desc)),
      h("td", { class: "small" }, isConv ? `1 ${p.out_currency} = ${nf8.format(p.rate)} ${p.in_currency}` +
        (p.rate ? ` · 1 ${p.in_currency} = ${nf8.format(1 / p.rate)} ${p.out_currency}` : "")
        : (Math.abs(p.out_amount) - p.in_amount > 0.005 ? `komisija ${money(Math.abs(p.out_amount) - p.in_amount, p.out_currency)}` : "")),
      h("td", {}, h("span", { class: "chip" + (p.auto ? "" : " ok") }, p.auto ? "atrasts" : "ar roku"),
        p.out_book !== p.in_book ? h("span", { class: "chip warn", title: "Starp grāmatvedībām" }, ` ${bookName(p.out_book)} → ${bookName(p.in_book)}`) : null),
      h("td", {}, h("button", { class: "link danger", onclick: async () => {
        if (await confirmDlg("Atsaistīt?", "Abi darījumi atkal skaitīsies atsevišķi (programma šo pāri vairs neveidos pati).", "Atsaistīt")) {
          await api("transfer_unlink", { id: p.id }); show("transfers");
        } } }, "Atsaistīt"))))))) : h("div", { class: "muted" }, "Nav.");
  return h("div", {}, h("h1", {}, "Pārskaitījumi — ", bookTitle(), h("span", { class: "muted small" }, "  ", periodText())),
    h("p", { class: "muted" }, "Viena un tā pati nauda starp taviem kontiem (PayPal → Revolut, Revolut → Nexo, Swedbank ↔ Swedbank …). Programma pāros atrod pēc summas, datuma un teksta. Šie darījumi neskaitās ne ienākumos, ne izdevumos. Valūtas maiņas kurss tiek izmantots arī ienākuma novērtēšanai eiro (piem. Shutterstock USD izmaksa PayPal)."),
    h("div", { class: "panel" }, h("div", { class: "toolbar" },
      h("label", { class: "small" }, "Tavs vārds bankas maksājumos (palīdz atrast Swedbank pārskaitījumus sev): ", own),
      h("button", { class: "primary", onclick: async () => {
        const r = await api("transfers_match", { own_names: own.value });
        toast(`Atrasti: ${r.transfers} pārskaitījumi, ${r.conversions} maiņas, ${r.rates} kursi`); show("transfers");
      } }, "🔄 Meklēt pārus"))),
    h("div", { class: "panel" }, h("h2", {}, `Bez pāra (${d.unmatched.length})`),
      h("p", { class: "small muted" }, "Darījumi ar pārskaitījuma kategoriju, kuriem nav atrasta otra puse. Iespējams, otrs konts nav importēts, vai arī tas nav pārskaitījums (tad nomaini kategoriju sadaļā Darījumi)."),
      d.unmatched.length ? h("div", { class: "tablewrap", style: "max-height:40vh" }, h("table", {}, h("tbody", {}, d.unmatched.map(t => h("tr", {},
        h("td", {}, dmy(t.date)), h("td", { class: "small" }, t.account), h("td", { class: "num" }, moneyEl(t.amount, t.currency)),
        h("td", { class: "desc" }, `${t.counterparty || ""} · ${t.description || ""}`),
        h("td", {}, h("button", { onclick: () => pairDialog(t) }, "Atrast pāri…"))))))) : h("div", { class: "muted" }, "Visi pārskaitījumi sapāroti ✓")),
    h("div", { class: "panel" }, h("h2", {}, `Pārskaitījumi starp kontiem (${tr.length})`), pairTable(tr, false)),
    h("div", { class: "panel" }, h("h2", {}, `Valūtas maiņa (${conv.length})`), pairTable(conv, true)));
};

async function pairDialog(t) {
  const d = await api("transfer_candidates", { id: t.id });
  const list = d.candidates.length ? h("table", {}, h("tbody", {}, d.candidates.map(c => h("tr", {},
    h("td", {}, dmy(c.date)), h("td", { class: "small" }, c.account), h("td", { class: "num" }, moneyEl(c.amount, c.currency)),
    h("td", { class: "desc" }, `${c.counterparty || ""} · ${c.description || ""}`),
    h("td", {}, h("button", { class: "primary", onclick: async () => {
      await api("transfer_link", { a: t.id, b: c.id }); $("#overlay").hidden = true; toast("Sasaistīts"); show("transfers");
    } }, "Sasaistīt")))))) : h("p", { class: "muted" }, "±10 dienu laikā citos kontos nav piemērota darījuma.");
  return dialog(`Pāris: ${money(t.amount, t.currency)} · ${t.account} · ${dmy(t.date)}`, list, [{ label: "Aizvērt" }]);
}

function ruleDialog(t) {
  const pat = h("input", { value: (t.counterparty || t.description || "").toLowerCase().slice(0, 40) });
  const cat = catSelect(t.category_id);
  const dir = h("select", {}, h("option", { value: "abi" }, "Ienākumi un izdevumi"),
    h("option", { value: "ienakums" }, "Tikai ienākumi"), h("option", { value: "izdevums" }, "Tikai izdevumi"));
  dir.value = t.amount > 0 ? "ienakums" : "izdevums";
  return dialog("Jauna kategorizēšanas kārtula", h("div", { class: "form" },
    field("Teksts saņēmējā vai aprakstā", pat, "wide"), field("Kategorija", cat), field("Virziens", dir),
    h("div", { class: "hint wide" }, "Visi darījumi ar šo tekstu (izņemot tos, kam kategorija likta ar roku vai to noteica banka) saņems šo kategoriju — arī nākotnes importos.")),
  [{ label: "Atcelt" }, { label: "Saglabāt", cls: "primary", action: async () => {
    const r = await api("rule_save", { pattern: pat.value, category_id: cat.value, direction: dir.value, priority: 30 });
    toast(`Kārtula saglabāta, pārkategorizēti ${r.changed} darījumi`); show(S.page);
  } }]);
}

function manualTxDialog() {
  const m = { account: h("input", { value: "Skaidra nauda" }), date: h("input", { type: "date", value: todayIso() }),
    amount: h("input", { placeholder: "-12,50" }), currency: h("input", { value: "EUR" }),
    counterparty: h("input", {}), description: h("input", {}) };
  const bk = bookSelect(S.book);
  return dialog("Manuāls darījums", h("div", { class: "form" },
    field("Konts", m.account), field("Datums", m.date), field("Summa (− izdevums)", m.amount),
    field("Valūta", m.currency), field("Saņēmējs / maksātājs", m.counterparty), field("Apraksts", m.description),
    field("Grāmatvedība (jaunam kontam)", bk)),
  [{ label: "Atcelt" }, { label: "Pievienot", cls: "primary", action: async () => {
    await api("tx_add", Object.assign(formValues(m), { book: +bk.value })); toast("Pievienots"); show("tx");
  } }]);
}

function downloadCsv(list) {
  const cols = ["date", "account", "amount", "currency", "eur", "counterparty", "description", "category", "note"];
  const lines = [cols.join(";")].concat(list.map(t => cols.map(c => {
    let v = t[c] ?? ""; if (typeof v === "number") v = String(v).replace(".", ",");
    return /[;"\n]/.test(v) ? `"${String(v).replace(/"/g, '""')}"` : v;
  }).join(";")));
  const a = h("a", { href: URL.createObjectURL(new Blob(["﻿" + lines.join("\n")], { type: "text/csv" })), download: "darijumi.csv" });
  document.body.append(a); a.click(); a.remove();
}

// ------------------------------------------------------------------ RĒĶINI
const INV_CHIP = { "Apmaksāts": "ok", "Kavēts": "bad", "Daļēji, kavēts": "bad", "Daļēji apmaksāts": "warn", "Neapmaksāts": "" };

PAGES.invoices = async () => {
  const d = await api("invoices");
  S.invFilter = S.invFilter || "open";
  const list = d.invoices.filter(i => S.invFilter === "all" || (S.invFilter === "open" ? i.status !== "Apmaksāts" : i.status === "Apmaksāts"));
  const pay = d.invoices.filter(i => i.direction === "sanemts").reduce((a, i) => a + Math.max(0, i.left), 0);
  const get = d.invoices.filter(i => i.direction === "izrakstits").reduce((a, i) => a + Math.max(0, i.left), 0);
  const late = d.invoices.filter(i => i.status.includes("avēts")).length;
  const detail = h("div", {});
  const fsel = h("select", { onchange: () => { S.invFilter = fsel.value; show("invoices"); } },
    h("option", { value: "open" }, "Neapmaksātie"), h("option", { value: "paid" }, "Apmaksātie"), h("option", { value: "all" }, "Visi"));
  fsel.value = S.invFilter;
  return h("div", {}, h("h1", {}, "Rēķini — ", bookTitle()),
    h("div", { class: "kpis" }, kpi("Man jāmaksā", money(pay)), kpi("Man jāsaņem", money(get)), kpi("Kavēti", late, late > 0)),
    h("div", { class: "toolbar" }, fsel, h("span", { class: "grow" }), h("button", { class: "primary", onclick: () => invoiceDialog() }, "+ Jauns rēķins")),
    list.length ? h("div", { class: "panel" }, h("table", {},
      h("thead", {}, h("tr", {}, ["Veids", "Partneris", "Nr.", "Izrakstīts", "Termiņš", "Summa", "Atlikums", "Statuss", S.book ? null : "Grāmatv."].filter(Boolean).map(t => h("th", { class: ["Summa", "Atlikums"].includes(t) ? "num" : "" }, t)))),
      h("tbody", {}, list.map(i => {
        const tr = h("tr", { class: "click", onclick: () => { document.querySelectorAll("#main tr.sel").forEach(x => x.classList.remove("sel")); tr.classList.add("sel"); invoiceDetail(i, detail); } },
          h("td", {}, i.direction === "sanemts" ? "Saņemts" : "Izrakstīts"), h("td", {}, i.counterparty), h("td", {}, i.number || ""),
          h("td", {}, dmy(i.issue_date)), h("td", {}, dmy(i.due_date)), h("td", { class: "num" }, money(i.amount, i.currency)),
          h("td", { class: "num" }, money(i.left, i.currency)), h("td", {}, h("span", { class: "chip " + (INV_CHIP[i.status] || "") }, i.status)),
          S.book ? null : h("td", { class: "small muted" }, bookName(i.book_id)));
        return tr;
      })))) : h("div", { class: "panel empty" }, "Nav rēķinu."),
    detail);
};

async function invoiceDetail(inv, box) {
  const d = await api("invoice_detail", { id: inv.id });
  const tbl = (list, btn) => h("table", {}, h("tbody", {}, list.map(t => h("tr", {}, h("td", {}, dmy(t.date)), h("td", { class: "small" }, t.account),
    h("td", { class: "num" }, moneyEl(t.amount)), h("td", { class: "desc" }, `${t.counterparty || ""} · ${t.description || ""}`), h("td", {}, btn(t))))));
  box.replaceChildren(h("div", { class: "panel" },
    h("div", { class: "toolbar" }, h("h2", { style: "margin:0" }, `${inv.counterparty} ${inv.number ? "#" + inv.number : ""} — ${money(inv.amount, inv.currency)}`),
      h("span", { class: "grow" }), h("button", { onclick: () => invoiceDialog(inv) }, "Labot"),
      h("button", { class: "danger", onclick: async () => {
        if (await confirmDlg("Dzēst rēķinu?", `${inv.counterparty} ${inv.number || ""}`, "Dzēst")) { await api("invoice_delete", { id: inv.id }); show("invoices"); }
      } }, "Dzēst")),
    inv.note ? h("p", { class: "muted" }, inv.note) : null,
    h("h2", {}, "Piesaistītie maksājumi"),
    d.payments.length ? tbl(d.payments, t => h("button", { class: "link", onclick: async () => { await api("invoice_unlink", { id: inv.id, tx: t.id }); show("invoices"); } }, "Atsaistīt"))
      : h("div", { class: "muted" }, "Nav."),
    h("h2", { style: "margin-top:14px" }, "Ieteiktie darījumi"),
    d.suggestions.length ? tbl(d.suggestions, t => h("button", { onclick: async () => { await api("invoice_link", { id: inv.id, tx: t.id }); toast("Piesaistīts"); show("invoices"); } }, "Piesaistīt"))
      : h("div", { class: "muted" }, "Atbilstoši darījumi nav atrasti. Pārbaudi atpazīšanas tekstu vai importē jaunākus izrakstus.")));
  box.scrollIntoView({ behavior: "smooth", block: "start" });
}

function invoiceDialog(inv = {}) {
  const due = new Date(Date.now() + 14 * 864e5).toISOString().slice(0, 10);
  const m = {
    direction: h("select", {}, h("option", { value: "sanemts" }, "Saņemts (man jāmaksā)"), h("option", { value: "izrakstits" }, "Izrakstīts (man jāsaņem)")),
    counterparty: h("input", { value: inv.counterparty || "" }), number: h("input", { value: inv.number || "" }),
    issue_date: h("input", { type: "date", value: inv.issue_date || todayIso() }), due_date: h("input", { type: "date", value: inv.due_date || due }),
    amount: h("input", { value: inv.amount ?? "" }), currency: h("input", { value: inv.currency || "EUR" }),
    category_id: catSelect(inv.category_id), match_text: h("input", { value: inv.match_text || "" }),
    note: h("input", { value: inv.note || "" }), book_id: bookSelect(inv.book_id),
  };
  m.direction.value = inv.direction || "sanemts";
  return dialog(inv.id ? "Labot rēķinu" : "Jauns rēķins", h("div", { class: "form" },
    field("Veids", m.direction), field("Partneris *", m.counterparty), field("Rēķina nr.", m.number),
    field("Izrakstīts", m.issue_date), field("Apmaksas termiņš", m.due_date), field("Summa *", m.amount),
    field("Valūta", m.currency), field("Kategorija", m.category_id), field("Grāmatvedība", m.book_id),
    field("Atpazīšanas teksts bankā", m.match_text, "wide"), h("div", { class: "hint wide" }, "Ja tukšs — meklē pēc partnera nosaukuma un rēķina numura."),
    field("Piezīme", m.note, "wide")),
  [{ label: "Atcelt" }, { label: "Saglabāt", cls: "primary", action: async () => {
    await api("invoice_save", Object.assign(formValues(m), { id: inv.id })); toast("Saglabāts"); show("invoices");
  } }]);
}

// ------------------------------------------------------------------ SAISTĪBAS
const ST_CHIP = { paid: ["ok", "Samaksāts"], late: ["bad", "Kavēts"], due: ["", "Gaidāms"] };
let OB_META = { kinds: {}, freq: {} };

PAGES.obligations = async () => {
  const d = await api("obligations");
  OB_META = { kinds: d.kinds, freq: d.freq };
  const act = d.obligations.filter(o => o.active);
  const monthly = act.filter(o => o.direction === "maksaju" && o.frequency === "menesis").reduce((a, o) => a + (o.payment_amount || 0), 0);
  const debt = act.reduce((a, o) => a + (o.debt || 0), 0);
  const lateN = act.reduce((a, o) => a + o.late_n, 0), lateS = act.reduce((a, o) => a + o.late_sum, 0);
  const detail = h("div", {});
  const root = h("div", {}, h("h1", {}, "Saistības — ", bookTitle()),
    h("p", { class: "muted" }, "Līzingi, nomaksas, kredīti, uzturlīdzekļi, īre un citi regulāri maksājumi. Samaksātos maksājumus programma atrod bankas datos pēc atpazīšanas teksta un summas."),
    h("div", { class: "kpis" }, kpi("Mēnesī jāmaksā", money(monthly)), kpi("Atlikušais parāds", money(debt)),
      kpi("Kavēti maksājumi", lateN ? `${lateN} · ${money(lateS)}` : "0", lateN > 0)),
    h("div", { class: "toolbar" }, h("button", { onclick: async () => { const r = await api("obligations_match"); toast(`Atrasti ${r.linked} maksājumi`); show("obligations"); } }, "🔄 Meklēt maksājumus"),
      h("span", { class: "grow" }), h("button", { class: "primary", onclick: () => obligationDialog() }, "+ Jauna saistība")));
  if (!d.obligations.length) { root.append(h("div", { class: "panel empty" }, "Vēl nav saistību.")); return root; }
  root.append(h("div", { class: "panel" }, h("table", {},
    h("thead", {}, h("tr", {}, ["Nosaukums", "Veids", "Samaksāti", "Samaksāts", "Atlicis", "Parāds", "Kavēti", "Nākamais", S.book ? null : "Grāmatv."].filter(Boolean)
      .map(t => h("th", { class: ["Samaksāts", "Atlicis", "Parāds"].includes(t) ? "num" : "" }, t)))),
    h("tbody", {}, d.obligations.map(o => {
      const tr = h("tr", { class: "click" + (o.active ? "" : " muted"), onclick: () => { document.querySelectorAll("#main tr.sel").forEach(x => x.classList.remove("sel")); tr.classList.add("sel"); obligationDetail(o.id, detail); } },
        h("td", {}, h("b", {}, o.name), o.direction === "sanemu" ? h("span", { class: "chip" }, " saņemu") : "", o.active ? "" : h("span", { class: "chip" }, "neaktīva")),
        h("td", {}, o.kind_label), h("td", {}, o.total_n ? `${o.paid_n} / ${o.total_n}` : o.paid_n),
        h("td", { class: "num" }, money(o.paid_sum)), h("td", { class: "num" }, o.left_sum == null ? "∞" : money(o.left_sum)),
        h("td", { class: "num" }, o.debt == null ? "" : money(o.debt)),
        h("td", {}, o.late_n ? h("span", { class: "chip bad" }, `${o.late_n} · ${money(o.late_sum)}`) : h("span", { class: "chip ok" }, "nav")),
        h("td", {}, o.next_date ? `${dmy(o.next_date)} · ${money(o.next_amount)}` : "—"),
        S.book ? null : h("td", { class: "small muted" }, bookName(o.book_id)));
      return tr;
    })))), detail);
  return root;
};

async function obligationDetail(id, box) {
  const d = await api("obligation_get", { id });
  const o = d.obligation;
  const hasP = d.schedule.some(s => s.principal_part != null);
  box.replaceChildren(h("div", { class: "panel" },
    h("div", { class: "toolbar" }, h("h2", { style: "margin:0" }, o.name), h("span", { class: "muted" }, o.counterparty || ""),
      h("span", { class: "grow" }), h("button", { onclick: () => obligationDialog(o) }, "Labot"),
      h("button", { class: "danger", onclick: async () => {
        if (await confirmDlg("Dzēst saistību?", `“${o.name}” un tās grafiks tiks izdzēsti. Bankas darījumi paliek.`, "Dzēst")) { await api("obligation_delete", { id }); show("obligations"); }
      } }, "Dzēst")),
    o.note ? h("p", { class: "muted" }, o.note) : null,
    o.match_text ? null : h("div", { class: "notice" }, "Nav atpazīšanas teksta — maksājumi netiek meklēti automātiski. Atzīmē tos ar roku vai papildini saistību."),
    h("div", { class: "tablewrap" }, h("table", {},
      h("thead", {}, h("tr", {}, ["Nr.", "Termiņš", "Summa", hasP ? "Pamatsumma" : null, hasP ? "Procenti" : null, hasP ? "Atlikums pēc" : null, "Statuss", "Samaksāts", "Ar roku"].filter(Boolean).map(t => h("th", {}, t)))),
      h("tbody", {}, d.schedule.map(s => h("tr", {},
        h("td", {}, s.seq), h("td", {}, dmy(s.due_date)), h("td", { class: "num" }, money(s.amount, o.currency)),
        hasP ? h("td", { class: "num" }, money(s.principal_part)) : null, hasP ? h("td", { class: "num" }, money(s.interest_part)) : null,
        hasP ? h("td", { class: "num" }, money(s.balance_after)) : null,
        h("td", {}, h("span", { class: "chip " + ST_CHIP[s.status][0] }, ST_CHIP[s.status][1])),
        h("td", { class: "small" }, s.paid_date ? `${dmy(s.paid_date)} · ${money(Math.abs(s.paid_amount))} ` : "",
          s.transaction_id ? h("button", { class: "link", onclick: async () => { await api("schedule_mark", { id, sid: s.id, paid: false, unlink: true }); obligationDetail(id, box); } }, "atsaistīt") : null),
        h("td", {}, h("input", { type: "checkbox", checked: !!s.manual_paid, title: "Samaksāts no konta, kura dati nav importēti",
          onchange: async e => { await api("schedule_mark", { id, sid: s.id, paid: e.target.checked }); obligationDetail(id, box); } })))))))));
  box.scrollIntoView({ behavior: "smooth", block: "start" });
}

function obligationDialog(o = {}) {
  const kinds = OB_META.kinds, freq = OB_META.freq;
  const sel = (map, v) => { const s = h("select", {}, Object.entries(map).map(([k, l]) => h("option", { value: k }, l))); s.value = v; return s; };
  const m = {
    name: h("input", { value: o.name || "" }), kind: sel(kinds, o.kind || "lizings"),
    direction: sel({ maksaju: "Es maksāju", sanemu: "Es saņemu" }, o.direction || "maksaju"),
    counterparty: h("input", { value: o.counterparty || "" }), start_date: h("input", { type: "date", value: o.start_date || todayIso() }),
    frequency: sel(freq, o.frequency || "menesis"), n_payments: h("input", { type: "number", min: 0, value: o.n_payments || "" }),
    payment_amount: h("input", { value: o.payment_amount ?? "" }), currency: h("input", { value: o.currency || "EUR" }),
    principal: h("input", { value: o.principal ?? "" }), interest_rate: h("input", { value: o.interest_rate ?? "" }),
    residual: h("input", { value: o.residual || "" }), match_text: h("input", { value: o.match_text || "" }),
    tolerance: h("input", { value: o.tolerance ?? 1 }), note: h("input", { value: o.note || "" }),
    active: h("input", { type: "checkbox", checked: o.active ?? true }), book_id: bookSelect(o.book_id),
  };
  return dialog(o.id ? "Labot saistību" : "Jauna saistība", h("div", { class: "form" },
    field("Nosaukums *", m.name), field("Veids", m.kind), field("Virziens", m.direction),
    field("Partneris", m.counterparty), field("Pirmā maksājuma datums *", m.start_date), field("Biežums", m.frequency),
    field("Maksājumu skaits", m.n_payments), field("Maksājuma summa", m.payment_amount), field("Valūta", m.currency),
    h("div", { class: "hint wide" }, "Maksājumu skaits tukšs — beztermiņa (piem. uzturlīdzekļi, īre). Summa tukša — aprēķina no pamatsummas un procentiem."),
    h("h3", {}, "Līzingam / kredītam (neobligāti — lai redzētu atlikušo parādu un procentus)"),
    field("Pamatsumma", m.principal), field("Gada procenti %", m.interest_rate), field("Izpirkuma maksa beigās", m.residual),
    h("h3", {}, "Automātiskā atpazīšana bankas datos"),
    field("Atpazīšanas teksts", m.match_text, "wide"),
    h("div", { class: "hint wide" }, "Vārdi no saņēmēja vai maksājuma apraksta, atdalīti ar semikolu, piem. “auto līzings; lig. 123”."),
    field("Summas pielaide €", m.tolerance), field("Grāmatvedība", m.book_id), h("label", { class: "row" }, m.active, "Aktīva"),
    field("Piezīme", m.note, "wide")),
  [{ label: "Atcelt" }, { label: "Saglabāt", cls: "primary", action: async () => {
    const r = await api("obligation_save", Object.assign(formValues(m), { id: o.id }));
    toast(`Saglabāts${r.linked ? `, atrasti ${r.linked} maksājumi` : ""}`); show("obligations");
  } }]);
}

// ------------------------------------------------------------------ IESTATĪJUMI
const TABS = [["books", "Grāmatvedības"], ["accounts", "Konti"], ["categories", "Kategorijas"], ["rules", "Kārtulas"],
  ["fx", "Valūtu kursi"], ["backups", "Rezerves kopijas"], ["update", "Atjauninājumi"]];

PAGES.settings = async () => {
  S.settingsTab = S.settingsTab || "books";
  const body = await SETTINGS[S.settingsTab]();
  return h("div", {}, h("h1", {}, "Iestatījumi"),
    h("div", { class: "tabs" }, TABS.map(([k, l]) => h("button", { class: S.settingsTab === k ? "on" : "", onclick: () => { S.settingsTab = k; show("settings"); } }, l))),
    body);
};

async function reloadMeta() {
  const i = await api("init");
  S.books = i.books; S.categories = i.categories;
  if (S.book && !S.books.find(b => b.id === S.book)) S.book = 0;
  renderBooks();
}

const SETTINGS = {
  async books() {
    const d = await api("books");
    const row = b => {
      const n = h("input", { value: b.name || "" }), s = h("input", { value: b.sources || "", placeholder: "swedbank" });
      return h("tr", {}, h("td", {}, n), h("td", {}, s), h("td", {},
        h("button", { onclick: async () => { await api("book_save", { id: b.id, name: n.value, sources: s.value }); await reloadMeta(); toast("Saglabāts"); show("settings"); } }, "Saglabāt"),
        b.id ? h("button", { class: "link danger", onclick: async () => {
          if (await confirmDlg("Dzēst grāmatvedību?", `“${b.name}”`, "Dzēst")) { await api("book_delete", { id: b.id }); await reloadMeta(); show("settings"); }
        } }, "Dzēst") : null));
    };
    return h("div", { class: "panel" }, h("p", { class: "muted" }, "Katrai grāmatvedībai ir savi konti, rēķini un saistības. “Avoti” nosaka, kurā grāmatvedībā nonāk jauni konti no importa (swedbank, revolut, paypal, nexo, manual). Esošu kontu var pārvietot cilnē “Konti”."),
      h("table", {}, h("thead", {}, h("tr", {}, h("th", {}, "Nosaukums"), h("th", {}, "Avoti (ar komatu)"), h("th", {}, ""))),
        h("tbody", {}, d.books.map(row), row({}))));
  },
  async accounts() {
    const d = await api("accounts");
    return h("div", { class: "panel" }, h("table", {},
      h("thead", {}, h("tr", {}, ["Nosaukums", "Avots", "Valūta", "Darījumi", "Grāmatvedība", "Rādīt", ""].map(t => h("th", {}, t)))),
      h("tbody", {}, d.accounts.map(a => {
        const n = h("input", { value: a.name, style: "width:100%" }), b = bookSelect(a.book_id), act = h("input", { type: "checkbox", checked: !!a.active });
        return h("tr", {}, h("td", {}, n), h("td", {}, a.source), h("td", {}, a.currency), h("td", { class: "num" }, a.n), h("td", {}, b), h("td", {}, act),
          h("td", {}, h("button", { onclick: async () => { await api("account_save", { id: a.id, name: n.value, book_id: b.value, active: act.checked }); toast("Saglabāts"); } }, "Saglabāt"),
            h("button", { class: "link", onclick: () => balanceDialog(a) }, "Atlikums…")));
      }))));
  },
  async categories() {
    const d = await api("categories");
    const KIND = { ienakumi: "Ienākumi", izdevumi: "Izdevumi", parskaitijums: "Pārskaitījums (neskaitās)" };
    const row = c => {
      const n = h("input", { value: c.name || "", style: "width:100%" });
      const k = h("select", {}, Object.entries(KIND).map(([v, l]) => h("option", { value: v }, l))); k.value = c.kind || "izdevumi";
      return h("tr", {}, h("td", {}, n), h("td", {}, k), h("td", { class: "num" }, c.n ?? ""), h("td", {},
        h("button", { onclick: async () => { await api("category_save", { id: c.id, name: n.value, kind: k.value }); await reloadMeta(); toast("Saglabāts"); show("settings"); } }, c.id ? "Saglabāt" : "Pievienot"),
        c.id ? h("button", { class: "link danger", onclick: async () => {
          if (await confirmDlg("Dzēst kategoriju?", `“${c.name}” — ${c.n} darījumi paliks bez kategorijas.`, "Dzēst")) { await api("category_delete", { id: c.id }); await reloadMeta(); show("settings"); }
        } }, "Dzēst") : null));
    };
    return h("div", { class: "panel" }, h("p", { class: "muted" }, "“Pārskaitījums” — naudas pārvietošana starp saviem kontiem vai valūtas maiņa; netiek skaitīta ne ienākumos, ne izdevumos."),
      h("table", {}, h("thead", {}, h("tr", {}, ["Nosaukums", "Veids", "Darījumi", ""].map(t => h("th", {}, t)))), h("tbody", {}, row({}), d.categories.map(row))));
  },
  async rules() {
    const d = await api("rules");
    const DIR = { abi: "Abi", ienakums: "Ienākumi", izdevums: "Izdevumi" };
    const row = r => {
      const p = h("input", { value: r.pattern || "" }), c = catSelect(r.category_id);
      const dr = h("select", {}, Object.entries(DIR).map(([v, l]) => h("option", { value: v }, l))); dr.value = r.direction || "abi";
      const pr = h("input", { type: "number", value: r.priority ?? 50, style: "width:70px" });
      return h("tr", {}, h("td", {}, p), h("td", {}, c), h("td", {}, dr), h("td", {}, pr), h("td", {},
        h("button", { onclick: async () => { const x = await api("rule_save", { id: r.id, pattern: p.value, category_id: c.value, direction: dr.value, priority: pr.value }); toast(`Saglabāts, pārkategorizēti ${x.changed}`); show("settings"); } }, r.id ? "Saglabāt" : "Pievienot"),
        r.id ? h("button", { class: "link danger", onclick: async () => { await api("rule_delete", { id: r.id }); show("settings"); } }, "Dzēst") : null));
    };
    return h("div", { class: "panel" }, h("p", { class: "muted" }, "Ja saņēmēja vai apraksta tekstā ir šie vārdi, darījums saņem kategoriju. Mazāka prioritāte = pārbauda vispirms. Virziens ļauj, piem., “adobe” ienākumu likt pie Adobe Stock, bet izdevumu — pie programmatūras."),
      h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["Teksts", "Kategorija", "Virziens", "Prioritāte", ""].map(t => h("th", {}, t)))),
        h("tbody", {}, row({}), d.rules.map(row)))));
  },
  async fx() {
    const d = await api("fx");
    const row = r => {
      const c = h("input", { value: r.currency || "", style: "width:90px" }), v = h("input", { value: r.eur_per_unit ?? "" });
      return h("tr", {}, h("td", {}, c), h("td", {}, v), h("td", {}, h("button", { onclick: async () => { await api("fx_save", { currency: c.value, rate: v.value }); toast("Saglabāts"); show("settings"); } }, "Saglabāt")));
    };
    return h("div", { class: "panel" }, h("p", { class: "muted" }, "Cik eiro ir 1 vienība (piem. USD 0,92; BTC — aktuālā cena eiro). Programma kursus internetā neņem — atjauno tos pats, kad vajag."),
      h("table", {}, h("thead", {}, h("tr", {}, h("th", {}, "Valūta"), h("th", {}, "EUR par 1 vienību"), h("th", {}, ""))),
        h("tbody", {}, d.missing.map(m => row({ currency: m })), d.rates.map(row), row({}))));
  },
  async backups() {
    const d = await api("backups");
    return h("div", { class: "panel" }, h("p", { class: "muted" }, "Programma pati katru dienu un pirms katras atjaunināšanas saglabā datubāzes kopiju (paturēt pēdējās 20). Mape: ", d.dir),
      h("div", { class: "toolbar" }, h("button", { class: "primary", onclick: async () => { await api("backup_now"); toast("Kopija saglabāta"); show("settings"); } }, "Saglabāt kopiju tagad"),
        h("button", { onclick: () => api("reveal", { what: "backups" }) }, "Atvērt mapi"), h("button", { onclick: () => api("reveal", {}) }, "Atvērt datu mapi")),
      h("table", {}, h("tbody", {}, d.backups.map(b => h("tr", {}, h("td", {}, b.name), h("td", {}, b.time), h("td", { class: "num" }, (b.size / 1024).toFixed(0) + " KB"),
        h("td", {}, h("button", { class: "link danger", onclick: async () => {
          if (await confirmDlg("Atjaunot datus no kopijas?", `Pašreizējie dati tiks aizstāti ar “${b.name}” (pirms tam tiks saglabāta to kopija).`, "Atjaunot")) {
            await api("backup_restore", { name: b.name }); toast("Dati atjaunoti"); location.reload();
          }
        } }, "Atjaunot")))))));
  },
  async update() {
    const st = (await api("init")).settings;
    const ch = h("select", { onchange: () => api("settings_save", { values: { update_channel: ch.value } }).then(() => toast("Saglabāts")) },
      h("option", { value: "auto" }, "Automātiski"), h("option", { value: "stable" }, "Tikai gatavās versijas"),
      h("option", { value: "test" }, "Arī testa versijas"), h("option", { value: "off" }, "Nepārbaudīt"));
    ch.value = st.update_channel || "auto";
    const res = h("div", {});
    return h("div", { class: "panel" }, h("p", {}, "Versija ", h("b", {}, window.APP_VERSION)),
      h("div", { class: "form" }, field("Atjauninājumu kanāls", ch)),
      h("div", { class: "toolbar", style: "margin-top:12px" }, h("button", { onclick: async () => {
        res.replaceChildren("Pārbaudu…");
        const r = await api("update_check", { force: true });
        res.replaceChildren(r.error ? `Neizdevās pārbaudīt: ${r.error}` : r.available ? updateOffer(r) : `Tev ir jaunākā versija (${r.current}).`);
      } }, "Pārbaudīt tagad")), res,
      h("h2", { style: "margin-top:16px" }, "Labojumu vēsture"),
      (window.CHANGELOG || []).map(c => h("div", {}, h("b", {}, c.v), h("span", { class: "muted" }, " " + dmy(c.date)), h("ul", {}, c.lv.map(x => h("li", {}, x))))));
  },
};

function balanceDialog(a) {
  const dt = h("input", { type: "date", value: todayIso() }), v = h("input", {});
  return dialog(`Atlikums: ${a.name}`, h("div", { class: "form" }, field("Datums", dt), field(`Faktiskais atlikums (${a.currency})`, v),
    h("div", { class: "hint wide" }, "Programma rēķinās atlikumu no šī datuma uz priekšu (piem., ja daļa vēstures nav importēta).")),
  [{ label: "Atcelt" }, { label: "Saglabāt", cls: "primary", action: async () => { await api("balance_set", { account_id: a.id, date: dt.value, balance: v.value }); toast("Saglabāts"); } }], true);
}

// ------------------------------------------------------------------ atjauninājumi un "Kas jauns"
function updateOffer(r) {
  const l = r.latest;
  const btn = h("button", { class: "primary", onclick: () => installUpdate(btn) }, `Uzstādīt ${l.version}`);
  return h("div", {}, h("p", {}, `Pieejama versija ${l.version} (${dmy(l.date)}).`),
    h("ul", {}, ((l.notes || {}).lv || []).map(x => h("li", {}, x))),
    r.can_install ? btn : h("p", { class: "muted" }, r.why === "dev" ? "Šī ir izstrādes kopija — atjauno ar git pull." : "Šeit uzstādīt nevar."));
}

async function installUpdate(btn) {
  btn.disabled = true;
  await api("update_install");
  const tick = async () => {
    const s = await api("update_status").catch(() => ({ status: "restart" }));
    btn.textContent = s.status === "download" ? `Lejupielādēju… ${s.pct}%` : s.status === "install" ? "Uzstādu…" : s.status === "restart" ? "Palaižu no jauna…" : btn.textContent;
    if (s.status === "error") { toast("Atjaunināt neizdevās: " + s.msg, true); btn.disabled = false; return; }
    if (s.status === "restart") return waitRestart();
    setTimeout(tick, 700);
  };
  tick();
}

function waitRestart() {
  setTimeout(async function again() {
    try { const r = await fetch("/index.html", { cache: "no-store" }); if (r.ok) { const t = await r.text(); const m = t.match(/APP_VERSION = "([^"]+)"/); if (m && m[1] !== window.APP_VERSION) return location.reload(); } } catch (e) { /* vēl palaižas */ }
    setTimeout(again, 1500);
  }, 2500);
}

async function checkUpdates() {
  try {
    const r = await api("update_check");
    if (!r.available || !r.can_install) return;
    const bar = $("#updateBar");
    const btn = h("button", { class: "primary", onclick: () => installUpdate(btn) }, "Uzstādīt");
    bar.replaceChildren(h("span", {}, `Pieejama versija ${r.latest.version}`), h("span", { class: "muted small" }, ((r.latest.notes || {}).lv || []).slice(0, 2).join(" · ")),
      h("span", { class: "grow", style: "flex:1" }), btn, h("button", { class: "link", onclick: () => { bar.hidden = true; } }, "Vēlāk"));
    bar.hidden = false;
  } catch (e) { /* nav interneta */ }
}

async function whatsNew() {
  try {
    const w = await api("whats_new");
    if (!w.show) return;
    const local = (window.CHANGELOG || []).filter(c => !w.entries.find(e => e.version === c.v)).map(c => ({ version: c.v, notes: { lv: c.lv } }))
      .filter(e => e.version !== w.from);
    const entries = w.entries.length ? w.entries : local;
    const box = $("#whatsNew");
    const close = () => { box.hidden = true; api("whats_new_seen"); };
    box.replaceChildren(h("span", { class: "x" }, "×"), h("h3", {}, `Kas jauns — ${w.to}`),
      entries.slice(0, 6).map(e => h("div", {}, h("b", {}, e.version), h("ul", {}, ((e.notes || {}).lv || []).map(x => h("li", {}, x))))));
    box.onclick = close; box.hidden = false;
    setTimeout(close, 20000);
  } catch (e) { /* */ }
}

// ------------------------------------------------------------------ sākums
async function boot() {
  $("#ver").textContent = "v" + window.APP_VERSION;
  document.querySelectorAll("#nav a").forEach(a => a.onclick = () => show(a.dataset.page));
  const i = await api("init", { book: 0 });
  S.books = i.books; S.categories = i.categories;
  S.book = S.books.find(b => b.id === i.settings.book) ? i.settings.book : 0;
  renderBooks();
  initPeriod();
  await show("overview");
  setInterval(() => fetch("/api/ping", { method: "POST", headers: { "X-Token": window.TOKEN }, body: "{}" }).catch(() => {}), 30000);
  whatsNew();
  setTimeout(checkUpdates, 1500);
}
boot();
